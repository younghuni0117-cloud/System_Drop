from pathlib import Path
import numpy as np
import pytest
from system_drop.output_schedule import decimal_text,frame_count,times,configure_output,select_frame_indices
from system_drop.playlist import from_result_file
from system_drop.model import ROOT


def test_decimal_times_and_nondivisible_last_frame():
    assert decimal_text(1.e-7)=='0.0000001'
    assert decimal_text(1.e-12)=='0.000000000001'
    assert frame_count(.00006,.000001)==60
    assert frame_count(.0000605,.000001)==61
    assert float(times(.0000605,.000001)[-1])==.0000605
    assert frame_count(.00006,0) is None


def test_time_based_output_does_not_force_integration_step():
    deck='*STEP\n*DYNAMIC, EXPLICIT=2\n0.0000001,0.00006,0.000000000001,0.000001\n*NODE FILE,FREQUENCY=5\nU,V\n*END STEP\n'
    result=configure_output(deck,'calculix',.00006,.000001)
    assert 'TARGET_FRAMES=60' in result and 'FREQUENCY=10' in result
    assert 'TIME POINTS' not in result
    assert '0.0000001,0.00006,0.000000000001,0.000001' in result
    assert configure_output(result,'calculix',.00006,.000001)==result
    result=configure_output('*OUTPUT, FIELD, NUMBER INTERVAL=20\nU,V\n','abaqus',.00006,.000001)
    assert '*OUTPUT, FIELD, TIME INTERVAL=0.000001' in result


def test_sixty_frames_are_selected_from_actual_finer_steps_without_interpolation():
    raw=np.linspace(.0000002,.00006,300)
    indices,target=select_frame_indices(raw,.00006,.000001)
    assert len(indices)==len(set(indices))==60 and indices[-1]==299
    assert np.all(raw[indices]>=np.asarray(target)-1e-12)
    assert np.max(np.abs(raw[indices]-target))<.000001
    with pytest.raises(ValueError):select_frame_indices(raw[::10],.00006,.000001)
    indices,targets=select_frame_indices(np.round(17+raw,5),.00006,.000001,offset=17.)
    assert len(indices)==len(set(indices))==60


def test_result_files_can_be_selected_in_arbitrary_drop_only_order(tmp_path):
    root=ROOT/'examples/three_body'
    second=from_result_file(root/'drop_02/results/frames.json')
    first=from_result_file(root/'drop_01/results/frames.json')
    assert second['number']==2 and first['number']==1
    assert second['phase']==first['phase']=='drop'
    assert all(Path(r['file']).is_absolute() for r in first['records'])
    single=from_result_file(first['records'][0]['file'])
    assert len(single['records'])==1
    stage=tmp_path/'drop_01';(stage/'results').mkdir(parents=True)
    (stage/'job.frd').write_text('not parsed; use already converted results')
    with pytest.raises(ValueError):from_result_file(stage/'job.frd')


def test_rounded_cumulative_dat_times_do_not_mix_stresses_between_frames(tmp_path):
    from system_drop.element_results import read_element_stress
    dat=tmp_path/'job.dat'
    dat.write_text(' stresses (elem, integ.pnt.,sxx,syy,szz,sxy,sxz,syz) for set BODY and time 0.1700012E+02\n'
                   '1 1 10 0 0 0 0 0\n\n'
                   ' stresses (elem, integ.pnt.,sxx,syy,szz,sxy,sxz,syz) for set BODY and time 0.1700012E+02\n'
                   '1 1 20 0 0 0 0 0\n')
    frames=read_element_stress(dat,ordered=True)
    assert len(frames)==2 and frames[0][0]==frames[1][0]
    assert frames[0][1][1][0][0]==10 and frames[1][1][1][0][0]==20
