from dataclasses import replace
import json
import pytest
from system_drop.model import Settings,ROOT
from system_drop.engine import Engine
from system_drop.solver import setup_drop
from system_drop.deck import expanded_lines
from system_drop.split_input import calculix_model_input
from system_drop.input_settings import verify_calculix_settings
from system_drop.template_adapter import set_dynamic_times
from system_drop.abaqus_audit import audit_abaqus
from system_drop.restart_recovery import dynamic_period


@pytest.mark.parametrize('maximum,period',[(.00001,.001),(.000003,.007),(0,.02)])
def test_calc_main_is_the_executed_input_and_reflects_gui(tmp_path,maximum,period):
    s=Settings(directions=[1],output_root=str(tmp_path),drop_max_dt=maximum,drop_time=period)
    original=(ROOT/'template_calculix/calculix_main.inp').read_bytes()
    e=Engine(s);e.initialize();folder=setup_drop(s,e.run,0,e.log)
    assert calculix_model_input(folder).name=='calculix_main.inp'
    assert '*INCLUDE, INPUT=calculix_main.inp' in (folder/'job.inp').read_text()
    assert '*DYNAMIC, EXPLICIT=2' in (folder/'calculix_main.inp').read_text()
    report=json.loads((folder/'input_settings.json').read_text())
    assert report['passed'] and report['actual']['maximum_increment_s']==maximum
    assert report['actual']['period_s']==period
    assert dynamic_period(folder/'job.inp')==period
    assert (ROOT/'template_calculix/calculix_main.inp').read_bytes()==original
    # The raw data line has four Calc fields, not the Abaqus scale-factor layout.
    assert report['actual']['initial_increment_s']==.0000001
    assert report['actual']['minimum_increment_s']==.000000000001
    with pytest.raises(ValueError,match='불일치'):
        verify_calculix_settings(folder,replace(s,drop_time=period*2))


def test_solver_specific_dynamic_options_are_not_interchangeable(tmp_path):
    with pytest.raises(ValueError,match='EXPLICIT=2'):
        set_dynamic_times('*DYNAMIC, EXPLICIT=2\n1e-7,.02,1e-12,1e-6\n',', .02, , .000001',solver='abaqus')
    with pytest.raises(ValueError,match='Abaqus 전용'):
        set_dynamic_times('*DYNAMIC, EXPLICIT, ELEMENT BY ELEMENT\n,.02,,.000001\n','0.0000001,.02,.000000000001,.000001',solver='calculix')
    with pytest.raises(ValueError,match='DIRECT'):
        set_dynamic_times('*DYNAMIC, EXPLICIT=2, DIRECT\n1e-7,.02,1e-12,1e-6\n','1e-7,.02,1e-12,1e-6',solver='calculix')
    path=tmp_path/'bad_abaqus.inp';path.write_text('*STEP\n*DYNAMIC, EXPLICIT=2\n,.02,,.000001\n*END STEP\n')
    assert not audit_abaqus(path)['passed']


def test_execution_refreshes_and_checks_time_values_before_starting_ccx(tmp_path,monkeypatch):
    s=Settings(directions=[1],output_root=str(tmp_path))
    e=Engine(s);e.execute(automatic=False)
    s.drop_time=.001;s.drop_max_dt=.00001
    def stop(*args):raise RuntimeError('test stopped before solver launch')
    monkeypatch.setattr('system_drop.engine.resolve_solver_command',stop)
    e.execute(automatic=False)
    folder=e.run/'drop_01';report=json.loads((folder/'input_settings.json').read_text())
    assert report['passed'] and report['actual']['period_s']==.001
    assert report['actual']['maximum_increment_s']==.00001
    assert '0.0000001, 0.001, 0.000000000001, 0.00001' in (folder/'calculix_main.inp').read_text()
    assert not (folder/'solver.log').exists()
