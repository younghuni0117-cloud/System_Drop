import json,os
from pathlib import Path
import pytest
from system_drop.solver_cache import record_completion,reusable_completion
from system_drop.engine import Engine
from system_drop.model import Settings


@pytest.fixture
def completed(tmp_path):
    folder=tmp_path/'drop_01';folder.mkdir()
    (folder/'job.inp').write_text('*STEP\n*END STEP\n')
    (folder/'calculix_mesh.inp').write_text('mesh')
    (folder/'job.frd').write_bytes(b'original results')
    (folder/'job.rout').write_bytes(b'original native material state')
    (folder/'solver.log').write_text('Job finished\nTotal CalculiX Time: 788.703608\n')
    return folder


def test_legacy_completion_is_adopted_and_then_checked_by_digests(completed):
    assert reusable_completion(completed)
    assert json.loads((completed/'solver_completed.json').read_text())['adopted_legacy_completion']
    assert reusable_completion(completed)
    (completed/'calculix_mesh.inp').write_text('changed mesh')
    assert not reusable_completion(completed)


@pytest.mark.parametrize('change',['missing_restart','failed_log','new_input','modified_output'])
def test_changed_incomplete_or_failed_solver_output_cannot_be_reused(completed,change):
    if change=='missing_restart':(completed/'job.rout').unlink()
    elif change=='failed_log':(completed/'solver.log').write_text('*ERROR\nJob finished\n')
    elif change=='new_input':
        future=(completed/'solver.log').stat().st_mtime+10
        os.utime(completed/'job.inp',(future,future))
    elif change=='modified_output':
        record_completion(completed);(completed/'job.frd').write_bytes(b'tampered')
    assert not reusable_completion(completed)


def test_retry_of_postprocessing_failure_never_starts_solver_or_archives_outputs(completed,monkeypatch):
    e=Engine(Settings(directions=[1]));e.run=completed.parent
    e.records[0]={'setup':'done','drop':'failed','release':'pending'}
    calls=[]
    def no_solver(*args,**kwargs):raise AssertionError('completed solver must not restart')
    monkeypatch.setattr('system_drop.engine.resolve_solver_command',no_solver)
    monkeypatch.setattr('system_drop.engine.popen',no_solver)
    monkeypatch.setattr(e,'convert_results',lambda i,s,f:calls.append((i,s,f)))
    e.execute(automatic=False)
    assert calls==[(0,'drop',completed)]
    assert e.records[0]['drop']=='done' and e.next_stage()==(0,'release')
    assert not list(completed.glob('previous_attempt_*'))
    assert (completed/'job.rout').read_bytes()==b'original native material state'


def test_postprocessing_error_keeps_completed_native_files_and_traceback(completed,monkeypatch):
    e=Engine(Settings(directions=[1]));e.run=completed.parent
    def fail(*args):raise ValueError('malformed FRD test')
    monkeypatch.setattr(e,'convert_results',fail)
    with pytest.raises(RuntimeError,match='계산은 정상 완료'):
        e.postprocess(0,'drop',completed)
    assert 'malformed FRD test' in (completed/'conversion_error.txt').read_text()
    assert (completed/'job.rout').exists() and (completed/'job.frd').exists()


def test_stabilization_cache_rejects_changed_upstream_drop(completed,tmp_path):
    upstream=tmp_path/'drop_native.rout';upstream.write_bytes(b'previous drop')
    release=tmp_path/'release_01';completed.rename(release)
    (release/'job.rin').write_bytes(upstream.read_bytes())
    record_completion(release,upstream=upstream)
    assert reusable_completion(release,upstream=upstream)
    upstream.write_bytes(b'changed drop material history')
    assert not reusable_completion(release,upstream=upstream)


def test_completed_include_entry_is_reused_without_migrating_or_rewriting(completed,monkeypatch):
    from system_drop.split_input import publish_calculix_input
    publish_calculix_input(completed);record_completion(completed)
    original={p.name:p.read_bytes() for p in completed.glob('*.inp')}
    e=Engine(Settings(directions=[1]));e.run=completed.parent
    calls=[]
    monkeypatch.setattr(e,'convert_results',lambda *args:calls.append(args))
    def no_solver(*args):raise AssertionError('Completed include-based solver must not restart')
    monkeypatch.setattr('system_drop.engine.resolve_solver_command',no_solver)
    e.run_stage(0,'drop')
    assert calls and original=={p.name:p.read_bytes() for p in completed.glob('*.inp')}
    assert reusable_completion(completed)
