"""System Drop workbench. Solver output is never substituted with demo data."""
__version__ = "0.12.9"
