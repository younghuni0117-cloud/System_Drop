from __future__ import annotations

from pathlib import Path
import json
import math
import re
import numpy as np

from .deck import Mesh,VTK_TYPES


def grid_from_mesh(mesh: Mesh, coordinates=None):
    import pyvista as pv
    nodes = coordinates if coordinates is not None else mesh.product_nodes
    labels = sorted(nodes)
    lookup = {n:i for i,n in enumerate(labels)}
    cells, types, element_ids = [], [], []
    for label, (kind, conn) in mesh.product_elements.items():
        if any(n not in lookup for n in conn):
            raise ValueError(f"결과에 요소 {label}의 노드가 없습니다.")
        cells.extend([len(conn), *(lookup[n] for n in conn)])
        types.append(VTK_TYPES[kind])
        element_ids.append(label)
    grid = pv.UnstructuredGrid(cells, np.array(types,dtype=np.uint8), np.array([nodes[n] for n in labels]))
    grid.point_data["Node ID"] = labels
    grid.cell_data["Element ID"] = element_ids
    from .parts import mesh_parts
    names,groups=mesh_parts(mesh)
    grid.cell_data['Part ID']=np.array([groups[e] for e in element_ids],dtype=np.int32)
    grid.field_data['Part Names']=np.array(names)
    return grid


def numbers(line):
    return [float(x.replace("D", "E")) for x in re.findall(r"[-+]?\d*\.?\d+(?:[EeDd][-+]?\d+)?", line)]


_SCIENTIFIC = {
    digits: re.compile(r"[-+]?\d+\.\d+[EeDd][-+]?\d{"+str(digits)+r"}")
    for digits in (2,3)
}


def frd_values(payload,expected,context):
    """C printf on legacy Windows uses 3 exponent digits, overflowing %12.5E
    for negative values. Never split a node ID with a numeric fallback regex.
    Require full consumption and the declared component count.
    """
    values=None
    if len(payload)%12==0:
        try:
            candidate=[float(payload[i:i+12].replace('D','E').replace('d','e'))
                       for i in range(0,len(payload),12) if payload[i:i+12].strip()]
            if len(candidate)==expected:values=candidate
        except ValueError:pass
    if values is None:
        for digits in (3,2):
            pos=0;candidate=[]
            while pos<len(payload):
                if payload[pos].isspace():pos+=1;continue
                match=_SCIENTIFIC[digits].match(payload,pos)
                if not match:break
                candidate.append(float(match[0].replace('D','E').replace('d','e')));pos=match.end()
            if pos==len(payload) and len(candidate)==expected:
                values=candidate;break
    if values is None:
        # Very large/small C values can mix two- and three-digit exponents.
        def parse(pos,count):
            while pos<len(payload) and payload[pos].isspace():pos+=1
            if count==0:return [] if pos==len(payload) else None
            for digits in (3,2):
                match=_SCIENTIFIC[digits].match(payload,pos)
                if match:
                    tail=parse(match.end(),count-1)
                    if tail is not None:return [float(match[0].replace('D','E').replace('d','e')),*tail]
            return None
        values=parse(0,expected)
    if values is None or len(values)!=expected:
        raise ValueError(f'FRD 숫자 형식/성분 개수 오류 ({context}): {expected}개 성분이 필요합니다. 행={payload!r}')
    if not all(math.isfinite(x) for x in values):
        raise ValueError(f'FRD 비유한 결과 값 ({context}). 원본 결과를 확인하세요.')
    return values


def read_frd(path: Path, mesh: Mesh):
    """ASCII FRD reader for Linux/Windows C numeric output and continuation rows.

    Visualization only; constitutive history always comes from native restart.
    """
    frames=[];product=mesh.product_nodes;datasets=[];current_time=0.
    name=None;data={};declared=0;components=0;last_label=None
    with Path(path).open(errors='replace') as stream:
        for lineno,raw in enumerate(stream,1):
            line=raw.rstrip('\r\n')
            if line.startswith('  100C'):
                try:current_time=float(line[12:24].replace('D','E'))
                except ValueError:
                    raise ValueError(f'FRD 시간 형식 오류: {path}:{lineno}')
            elif line.startswith(' -4'):
                parts=line.split();name=parts[1];declared=int(parts[2])
                data={};components=0;last_label=None
            elif line.startswith(' -5') and name:
                parts=line.split()
                # FRD IEXIST=1 is a viewer-derived component (e.g. ALL magnitude).
                if len(parts)<7 or not parts[6].startswith('1'):components+=1
            elif line.startswith(' -1') and name:
                try:label=int(line[3:13])
                except ValueError:raise ValueError(f'FRD 노드 번호 오류: {path}:{lineno}')
                count=components or declared
                values=frd_values(line[13:],min(6,count),f'{name}, node {label}, line {lineno}')
                last_label=label
                data[label]=values
            elif line.startswith(' -2') and name:
                if last_label is None:raise ValueError(f'FRD 연속 행에 이전 노드가 없습니다: {path}:{lineno}')
                remaining=(components or declared)-len(data[last_label])
                if remaining<=0:raise ValueError(f'FRD 초과 연속 행: {name}, node {last_label}')
                data[last_label]+=frd_values(line[3:],min(6,remaining),f'{name}, node {last_label}, line {lineno}')
            elif line.startswith(' -3') and name:
                count=components or declared
                for label,values in data.items():
                    if len(values)!=count:
                        raise ValueError(f'FRD 성분 누락: {name}, node {label}: {len(values)}/{count}')
                datasets.append((current_time,name,{n:v for n,v in data.items() if n in product}))
                name=None;data={};last_label=None
    if name is not None:raise ValueError(f'FRD 결과 블록이 끝나기 전에 파일이 종료됐습니다: {name}')
    groups=[]
    for time,name,data in datasets:
        # FRD uses only five mantissa decimals. In late cumulative steps several
        # different frames can have the same printed time: retain output order.
        if not groups or groups[-1][0]!=time or name in groups[-1][1]:groups.append((time,{}))
        groups[-1][1][name]=data
    for time,fields in groups:
        displacement=fields.get('DISP',{})
        if not displacement:continue
        missing=set(product)-set(displacement)
        if missing:raise ValueError(f'FRD 변위에서 제품 노드 {len(missing)}개가 누락됐습니다.')
        if any(len(v)!=3 for v in displacement.values()):raise ValueError('FRD DISP에는 XYZ 세 성분이 필요합니다.')
        coords={n:(np.asarray(p)+np.asarray(displacement[n])).tolist() for n,p in product.items()}
        grid=grid_from_mesh(mesh,coords);labels=sorted(product)
        for name,data in fields.items():
            if set(labels).issubset(data):
                counts={len(data[n]) for n in labels}
                if len(counts)!=1:raise ValueError(f'FRD {name} 노드별 성분 개수가 일치하지 않습니다: {sorted(counts)}')
                values=np.asarray([data[n] for n in labels],dtype=float)
                grid.point_data[name]=values[:,0] if values.shape[1]==1 else values
                if name=='STRESS' and values.shape[1]>=6:
                    xx,yy,zz,xy,yz,zx=values[:,:6].T
                    grid.point_data['S Mises (MPa)']=np.sqrt(.5*((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)+3*(xy**2+yz**2+zx**2))
        frames.append((time,grid,coords,fields))
    if not frames:raise ValueError('FRD에서 원래 제품 노드의 변위 프레임을 읽지 못했습니다.')
    return frames


def convert_frd(path, mesh, folder,output_schedule=None,progress=None):
    """Validate/index raw files with bounded memory, then save selected frames."""
    from .stream_results import index_frd,index_dat,load_frd_frame,load_dat_frame
    from .element_results import attach_element_stress
    from .output_schedule import reconcile_frame_times,select_frame_indices
    path=Path(path);dat=path.with_suffix('.dat');folder=Path(folder);folder.mkdir(exist_ok=True)
    frd_bytes=path.stat().st_size;dat_bytes=dat.stat().st_size if dat.exists() else 0
    raw_bytes=max(1,frd_bytes+dat_bytes)
    def notify(phase,done,total,percent):
        if progress:progress({'phase':phase,'completed':done,'total':total,'percent':max(0.,min(100.,percent))})
    notify('FRD 검사',0,frd_bytes,0.)
    frames=index_frd(path,mesh,lambda done,total:notify('FRD 검사',done,total,80*done/raw_bytes))
    notify('DAT 검사',0,dat_bytes,80*frd_bytes/raw_bytes)
    stress_frames=index_dat(dat,lambda done,total:notify('DAT 검사',done,total,80*(frd_bytes+done)/raw_bytes))
    notify('시간 검증',1,1,80.)
    actual_times=[];time_digits=[]
    for i,frame in enumerate(frames):
        time=frame['time'];digits=6
        if len(stress_frames)==len(frames):
            exact=stress_frames[i]['time']
            precision=.51*10**(int(math.floor(math.log10(abs(time))))-5) if time else 0.000000000001
            if abs(exact-time)<=max(precision,0.000000000001):time=exact;digits=7
        actual_times.append(time);time_digits.append(digits)
    reported_times=list(actual_times)
    parameters=dict(output_schedule or {});end_time=parameters.pop('end_time',None)
    actual_times,time_audit=reconcile_frame_times(reported_times,time_digits,offset=parameters.get('offset'),end_time=end_time)
    (folder/'time_reconciliation.json').write_text(json.dumps(time_audit,indent=2),encoding='utf-8')
    indices=range(len(frames));targets=None
    if output_schedule:indices,targets=select_frame_indices(actual_times,**parameters)
    # Legacy files can contain several set outputs per timestamp. Preserve the
    # old nearest-time/last-group fallback without retaining all stress arrays.
    stress_by_time={f['time']:f for f in stress_frames}
    records=[]
    for i,source in enumerate(indices):
        reading=lambda *_:notify('프레임 읽기/저장',i,len(indices),80+20*i/max(1,len(indices)))
        notify('프레임 읽기/저장',i,len(indices),80+20*i/max(1,len(indices)))
        _,grid,coords,fields=load_frd_frame(path,mesh,frames[source],reading);time=actual_times[source]
        stress_index=(stress_frames[source] if len(stress_frames)==len(frames) else
                      stress_by_time[min(stress_by_time,key=lambda t:abs(t-time))] if stress_by_time else None)
        if stress_index is not None:
            aligned=len(stress_frames)==len(frames)
            stress_time=time if aligned else stress_index['time']
            if abs(stress_time-time)<=max(1e-12,abs(time)*2e-6):
                attach_element_stress(grid,time,{stress_time:load_dat_frame(dat,stress_index,reading)})
        target=folder/f'frame_{i:04d}.vtu';grid.save(target)
        record={'time':time,'reported_time':reported_times[source],'time_significant_digits':time_digits[source],'file':target.name}
        if targets is not None:record.update(requested_time=targets[i],source_frame_index=source)
        records.append(record)
        notify('프레임 읽기/저장',i+1,len(indices),80+20*(i+1)/max(1,len(indices)))
        # VTK arrays and per-node/per-element dictionaries are released as the
        # next frame is loaded. Only offsets/times and final state are retained.
        del grid
    if targets is not None:
        report={'raw_frames':len(frames),'selected_frames':len(records),
                'method':'Actual recorded frames selected by target time. Duplicate selections omitted for sparse output; no interpolation or synthetic frames. Raw files retained.' if parameters.get('allow_sparse') else 'Actual solved frames selected by target time; output-order selection when printed time resolution is insufficient. No interpolation; raw FRD retained.',
                'timing_resolution_limited':len(set(actual_times))<len(actual_times),
                'timestamp_reconciliation':time_audit,'schedule':output_schedule,'max_time_difference_s':max(abs(r['time']-r['requested_time']) for r in records)}
        (folder/'frame_selection.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    state={'solver':'calculix','time':records[-1]['time'],'coordinates':coords,
           'velocities':fields.get('VELO',fields.get('VELOCITY',{})),'material_history':'native_restart_required'}
    (folder/'state.json').write_text(json.dumps(state),encoding='utf-8')
    (folder/'frames.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    (folder/'conversion_mode.json').write_text(json.dumps({'mode':'streamed_index_then_selected_frames',
        'raw_frames':len(frames),'dat_frames':len(stress_frames),'saved_frames':len(records),
        'frd_bytes':frd_bytes,'dat_bytes':dat_bytes,'all_raw_values_validated':True},indent=2),encoding='utf-8')
    return folder/'state.json'


def read_state(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    data["coordinates"] = {int(k):v for k,v in data["coordinates"].items()}
    data["velocities"] = {int(k):v for k,v in data.get("velocities",{}).items()}
    return data


def validate_physical_state(state,mesh):
    expected=set(mesh.product_nodes)
    if set(state['coordinates'])!=expected:
        raise ValueError('결과의 제품 노드가 템플릿과 일치하지 않습니다.')
    if set(state.get('velocities',{}))!=expected:
        raise ValueError('상태 전달에 필요한 제품 노드별 속도가 누락됐습니다.')
    for name in ('coordinates','velocities'):
        for label,values in state[name].items():
            if len(values)<3 or any(not math.isfinite(v) for v in values):
                raise ValueError(f'결과 {name}, 노드 {label}에 누락 또는 비유한 값이 있습니다.')


def validate_preview_fields(folder):
    import pyvista as pv
    folder=Path(folder)
    records=json.loads((folder/'frames.json').read_text())
    grid=pv.read(folder/records[-1]['file'])
    for data in (grid.point_data,grid.cell_data):
        for name in ('DISP','VELO','STRESS','S Mises (MPa)','PE','PEEQ'):
            if name in data and not np.isfinite(data[name]).all():
                raise ValueError(f'최종 결과 {name}에 비유한 값이 있습니다.')
