"""Bound result recording independently of integration; keep native state intact."""
import json,re
from decimal import Decimal,ROUND_FLOOR
from .output_schedule import frame_count,decimal_text


def output_plan(settings,stage):
    period=settings.drop_time if stage=='drop' else settings.release_time
    requested=settings.drop_max_dt if stage=='drop' else settings.release_max_dt
    reference=settings.drop_dt if stage=='drop' else settings.release_dt
    # This is an output budget, not a bound on adaptive solver increments.
    # The initial explicit increment is only a reference for choosing a stride.
    interval=max(requested,period/settings.ccx_max_frames)
    target=min(settings.ccx_max_frames,frame_count(period,interval))
    frequency=settings.ccx_output_frequency
    if not frequency:
        ratio=Decimal(str(interval))/Decimal(str(reference))
        frequency=min(100000000,max(1,int(ratio.to_integral_value(rounding=ROUND_FLOOR))))
    return {'version':1,'stage':stage,'period':period,'interval':interval,
            'requested_interval':requested,'target_frames':target,
            'max_saved_frames':settings.ccx_max_frames,'frequency':frequency,
            'mode':'manual' if settings.ccx_output_frequency else 'automatic',
            'reference_increment':reference,'allow_sparse':True,
            'note':'Increment-based CCX recording; actual frame count/spacing depends on adaptive integration. Native restart retains full final material state.'}


def configure_calculix_output(text,settings,stage,folder=None,log=None):
    plan=output_plan(settings,stage)
    from .deck import logical_lines,tokens
    lines=[]
    for line in logical_lines(text.splitlines()):
        if re.match(r'^\s*\*(?:NODE FILE|EL FILE|NODE PRINT|EL PRINT)\b',line,re.I):
            kept=[t for t in tokens(line)[1:] if t.split('=')[0].strip().upper()
                  not in ('FREQUENCY','FREQUENCYF','TIME POINTS','TIMEPOINTS')]
            line=', '.join([line.split(',')[0].strip(),*kept,'FREQUENCY='+str(plan['frequency'])])
        if not line.startswith('** SYSTEM_DROP_OUTPUT_INTERVAL='):lines.append(line)
    note=f"** SYSTEM_DROP_OUTPUT_INTERVAL={decimal_text(plan['interval'])}; TARGET_FRAMES={plan['target_frames']}; SPARSE_OUTPUT=YES"
    if folder is not None:
        (folder/'output_plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
    if log:
        log('출력',f"CalculiX: {plan['frequency']:,}증분마다 FRD·DAT 기록 / 변환 최대 {plan['max_saved_frames']:,}프레임. 실제 기록 간격은 자동 증분에 따라 달라집니다. 누적 상태는 native restart 유지.")
    return note+'\n'+'\n'.join(lines)+'\n'
