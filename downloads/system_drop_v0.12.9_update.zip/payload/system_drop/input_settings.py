"""Read back solver-specific execution decks without invoking a solver."""
from pathlib import Path
import json,math
from .deck import logical_lines,keyword,expanded_lines
from .split_input import execution_input
from .template_adapter import dynamic_data_index


def verify_abaqus_settings(folder,settings):
    folder=Path(folder);actual=execution_input(folder,'abaqus');lines=list(logical_lines(expanded_lines(actual)))
    cards=[keyword(l) for l in lines if l.strip().startswith('*') and not l.strip().startswith('**')]
    dynamic=[p for name,p in cards if name=='*DYNAMIC' and 'EXPLICIT' in p]
    if len(dynamic)!=1:raise ValueError('최종 실행 입력에는 낙하 Explicit 절차가 정확히 한 개 있어야 합니다.')
    values=lines[dynamic_data_index(lines)].split(',');values+=['']*(4-len(values))
    period=float(values[1]);maximum=float(values[3] or 0.)
    outputs=[p for name,p in cards if name=='*OUTPUT' and ('FIELD' in p or 'HISTORY' in p)]
    equal=lambda a,b:math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-15)
    errors=[]
    if dynamic[0].get('EXPLICIT') is not True:errors.append('Abaqus는 EXPLICIT=2가 아닌 EXPLICIT 플래그를 사용합니다.')
    if values[0].strip():errors.append('Abaqus 자동 Explicit의 첫 번째 시간 필드는 공란이어야 합니다.')
    if not equal(period,settings.drop_time):errors.append('종료 시간 불일치')
    if not equal(maximum,settings.drop_max_dt):errors.append('최대 증분 불일치')
    if settings.drop_max_dt>0:
        for mode in ('FIELD','HISTORY'):
            requests=[p for p in outputs if mode in p]
            if not requests or any(not equal(float(p.get('TIME INTERVAL',0)),settings.drop_max_dt) for p in requests):errors.append(mode+' 출력 간격 불일치')
    report={'passed':not errors,'actual_input':actual.name,'includes':['abaqus_material.inp','abaqus_mesh.inp'],
            'expected':{'period_s':settings.drop_time,'maximum_increment_s':settings.drop_max_dt},
            'actual':{'period_s':period,'maximum_increment_s':maximum,'output_requests':outputs},'errors':errors,
            'time_field_meanings':['blank for automatic Explicit','step period','time increment scale factor','maximum increment']} 
    (folder/'input_settings.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'README_INPUT.txt').write_text('실제 실행 입력은 '+actual.name+'입니다.\nmaterial / mesh는 main의 INCLUDE로 연결합니다.\nGUI 반영값은 input_settings.json에서 확인하세요.\n',encoding='utf-8-sig')
    if errors:raise ValueError('Abaqus 입력 설정 검증 실패: '+'; '.join(errors))
    return report


def verify_calculix_settings(folder,settings,stage='drop'):
    """Validate the expanded execution input, never infer settings from results."""
    from .split_input import calculix_model_input
    folder=Path(folder);entry=folder/'job.inp';main=calculix_model_input(folder)
    lines=list(logical_lines(expanded_lines(entry)))
    cards=[keyword(l) for l in lines if l.strip().startswith('*') and not l.strip().startswith('**')]
    dynamics=[p for name,p in cards if name=='*DYNAMIC'];errors=[]
    if len(dynamics)!=1:raise ValueError('CalculiX 실행 입력에는 DYNAMIC 절차가 정확히 한 개 필요합니다.')
    params=dynamics[0];explicit='EXPLICIT' in params
    if explicit!=(stage=='drop'):errors.append('낙하는 Explicit, 안정화는 Implicit 절차여야 합니다.')
    if explicit and params['EXPLICIT'] not in (True,'2'):errors.append('CalculiX EXPLICIT 값은 2여야 합니다.')
    foreign={'APPLICATION','ELEMENT BY ELEMENT','IMPROVED DT METHOD','SCALE FACTOR','DIRECT USER CONTROL','FIXED TIME INCREMENTATION'}
    if foreign.intersection(params):errors.append('CalculiX DYNAMIC에 Abaqus 전용 옵션이 포함됐습니다.')
    if any(name in ('*OUTPUT','*IMPORT') for name,_ in cards):errors.append('CalculiX 입력에 Abaqus OUTPUT/IMPORT 키워드가 포함됐습니다.')
    if explicit and params.get('DIRECT') not in (None,'NO'):errors.append('Manager CalculiX 낙하는 DIRECT 고정 증분을 사용하지 않습니다.')
    values=[v.strip() for v in lines[dynamic_data_index(lines)].split(',')]
    if len(values)!=4:raise ValueError('CalculiX DYNAMIC은 초기 증분, 종료 시간, 최소 증분, 최대 증분의 4개 필드가 필요합니다.')
    try:actual=[float(v or 0) for v in values]
    except ValueError:raise ValueError('CalculiX 시간 데이터가 숫자가 아닙니다.') from None
    expected=([settings.drop_dt,settings.drop_time,.000000000001,settings.drop_max_dt] if stage=='drop' else
              [settings.release_dt,settings.release_time,.0000000001,settings.release_max_dt])
    names=['initial_increment_s','period_s','minimum_increment_s','maximum_increment_s']
    for name,a,b in zip(names,actual,expected):
        if not math.isfinite(a) or not math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-15):errors.append(name+' 불일치')
    requests=[p for name,p in cards if name in ('*NODE FILE','*EL FILE','*NODE PRINT','*EL PRINT')]
    plan_path=folder/'output_plan.json'
    if plan_path.exists():
        plan=json.loads(plan_path.read_text())
        if not requests or any(str(p.get('FREQUENCY'))!=str(plan['frequency']) for p in requests):errors.append('결과 기록 주기 불일치')
    report={'passed':not errors,'solver':'calculix','stage':stage,'actual_input':entry.name,'model_input':main.name,
            'expected':dict(zip(names,expected)),'actual':dict(zip(names,actual)),
            'procedure':params,'output_requests':requests,'errors':errors,
            'time_field_meanings':['initial increment (Explicit auto ignores this reference)' if explicit else 'initial increment','step period','minimum increment','maximum increment'],
            'note':'Actual increments depend on the solver automatic procedure. Viewer frame spacing and cumulative time are not these input settings.'}
    (folder/'input_settings.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'README_INPUT.txt').write_text('실제 CalculiX 명령: ccx -i job\njob.inp → '+main.name+'\nGUI 조건은 calculix_main.inp의 DYNAMIC 데이터 및 input_settings.json에서 확인하세요.\nNative 재시작 단계는 job.rin의 변형·재료 상태를 읽습니다. 원본 템플릿/mesh/material 사본의 시간값은 실행 조건이 아닙니다.\n',encoding='utf-8-sig')
    if errors:raise ValueError('CalculiX 입력 설정 검증 실패: '+'; '.join(errors))
    return report
