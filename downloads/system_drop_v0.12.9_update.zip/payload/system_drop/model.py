from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import json
import math

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
NAMES = [
    "Top Face", "Bottom Face", "Right Face", "Left Face", "Front Face", "Back Face",
    "Front-Right Corner", "Back-Right Corner", "Back-Left Corner", "Front-Left Corner",
    "Top-Left Edge", "Top-Right Edge", "Bottom-Left Edge", "Bottom-Right Edge",
    "Top-Back Edge", "Top-Front Edge", "Bottom-Back Edge", "Bottom-Front Edge",
]
SCENARIOS = {
    "18-Side Drop Sequence 1": list(range(1, 19)),
    "18-Side Drop Sequence 2": list(range(7, 19)) + list(range(1, 7)),
    "18-Side Drop Sequence 3": list(range(11, 19)) + list(range(1, 11)),
    "Custom": [1],
}
STAGES = ("setup", "drop", "release")
STAGE_LABELS = {"setup": "방향 셋업", "drop": "드랍해석", "release": "안정화해석"}


def bundled_calculix():
    return ROOT/"solvers/calculix/bin/ccx_MT.exe"


def default_calculix_command():
    return '"{solver}" -i {job}'


@dataclass
class Settings:
    solver: str = "calculix"
    scenario: str = "18-Side Drop Sequence 1"
    directions: list[int] = field(default_factory=lambda: list(range(1, 19)))
    template: str = str(ROOT / "template_calculix")
    output_root: str = str(ROOT / "runs")
    height: float = 1000.0
    gap: float = 0.001
    drop_time: float = 0.000060
    drop_dt: float = 1e-7
    drop_max_dt: float = 1e-6
    edge_angle: float = 30.0
    release_dt: float = 0.01
    release_max_dt: float = 0.01
    release_time: float = 1.0
    release_damping: float = 20.0
    ccx_output_frequency: int = 0
    ccx_max_frames: int = 1000
    cpus: int = 4
    calculix_command: str = field(default_factory=default_calculix_command)
    calculix_path: str = ""
    abaqus_command: str = "abaqus job={job} input={input} cpus={cpus} {oldjob} interactive"
    viewer: str = "PyVista"
    viewer_command: str = "abaqus viewer database={odb}"
    abaqus_python: str = "abaqus python {script} {odb} {output}"

    def validate(self):
        vals = (self.height, self.gap, self.drop_time, self.release_dt,
                self.release_max_dt, self.release_time,self.drop_dt,self.drop_max_dt,self.edge_angle,self.release_damping)
        if not all(math.isfinite(v) for v in vals):
            raise ValueError("모든 수치는 유한한 값이어야 합니다.")
        if not 0 <= self.gap <= self.height or self.height <= 0:
            raise ValueError("높이는 양수이며 0 ≤ 초기 간격 ≤ 높이여야 합니다.")
        if not 0 < self.release_dt <= self.release_max_dt <= self.release_time:
            raise ValueError("0 < 초기 증분 ≤ 최대 증분 ≤ 릴리즈 종료 시간이어야 합니다.")
        if not isinstance(self.ccx_output_frequency,int) or not 0<=self.ccx_output_frequency<=100000000:
            raise ValueError("CalculiX 기록 주기는 0(자동)부터 100000000 사이 정수여야 합니다.")
        if not isinstance(self.ccx_max_frames,int) or not 1<=self.ccx_max_frames<=100000:
            raise ValueError("CalculiX 최대 저장 프레임은 1~100000 사이 정수여야 합니다.")
        if self.release_damping<0:raise ValueError("안정화 감쇠 계수는 0 이상이어야 합니다.")
        if self.drop_time <= 0 or self.cpus < 1:
            raise ValueError("낙하 시간과 CPU 수는 양수여야 합니다.")
        if not 0<self.edge_angle<90:
            raise ValueError("Edge 각도는 0도 초과 90도 미만이어야 합니다.")
        if self.drop_dt<0 or self.drop_max_dt<0 or (self.drop_max_dt and self.drop_dt>self.drop_max_dt):
            raise ValueError("드랍 증분은 음수가 아니며 초기 증분 ≤ 최대 증분이어야 합니다.")
        if self.solver=="calculix" and self.drop_dt<=0:
            raise ValueError("CalculiX 드랍의 초기 증분은 양수여야 합니다.")
        if self.solver not in ("abaqus", "calculix"):
            raise ValueError("지원하지 않는 Solver입니다.")
        if not self.directions or any(d not in range(1, 19) for d in self.directions):
            raise ValueError("방향 목록은 01–18의 순서 있는 목록이어야 합니다.")
        template = Path(self.template)
        if Path(self.output_root).resolve().is_relative_to(template.resolve()):
            raise ValueError("결과 폴더는 템플릿 폴더 밖에 지정하세요.")
        for part in ("main", "mesh", "material"):
            if not (template / f"{self.solver}_{part}.inp").is_file():
                raise ValueError(f"템플릿 파일 없음: {self.solver}_{part}.inp")

    def save(self, path: Path):
        path.write_text(json.dumps(asdict(self), indent=2, ensure_ascii=False), encoding="utf-8")

    def validate_runtime_scope(self,automatic,workflow):
        # Per-step native restart compatibility is checked by the state adapter.
        self.validate()

    @classmethod
    def read(cls, path: Path):
        data=json.loads(path.read_text(encoding="utf-8"))
        if data.get("calculix_command") in ("ccx -i {job}",'"ccx" -i {job}'):
            data["calculix_command"]=default_calculix_command()
        return cls(**data)


def unit(v):
    v = np.asarray(v, dtype=float)
    length = np.linalg.norm(v)
    if not np.isfinite(length) or length < 1e-10:
        raise ValueError("좌표계 기준점이 겹치거나 일직선입니다.")
    return v / length


def frame(origin, xpoint, ypoint):
    """Columns map product right/top/front components into global XYZ."""
    right = unit(np.asarray(xpoint) - origin)
    toward_back = np.asarray(ypoint) - origin
    back = unit(toward_back - np.dot(toward_back, right) * right)
    top = unit(np.cross(right, back))
    return np.column_stack((right, top, -back))


def drop_direction(direction: int, rotation=None, width=304.0, depth=212.0,edge_angle=30):
    # Components are right, top, front; corner diagonals use actual model dimensions.
    faces = [(0, 1, 0), (0, -1, 0), (1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1)]
    corners = [(width, 0, depth), (width, 0, -depth), (-width, 0, -depth), (-width, 0, depth)]
    c, s = math.cos(math.radians(edge_angle)), math.sin(math.radians(edge_angle))
    edges = [(-s, c, 0), (s, c, 0), (-s, -c, 0), (s, -c, 0),
             (0, c, -s), (0, c, s), (0, -c, -s), (0, -c, s)]
    if direction not in range(1, 19):
        raise ValueError("방향 ID는 1–18입니다.")
    local = unit((faces + corners + edges)[direction - 1])
    return unit((np.eye(3) if rotation is None else rotation) @ local)


def impact_velocity(height, gap, direction):
    if height <= 0 or not 0 <= gap <= height:
        raise ValueError("초기 간격과 낙하 높이를 확인하세요.")
    return math.sqrt(2 * 9810.0 * (height - gap)) * unit(direction)


def floor_geometry(points, direction, gap, shell_allowance=0.0):
    d = unit(direction)
    points = np.asarray(points)
    center = points.mean(axis=0)
    center += d * (np.max(points @ d + np.asarray(shell_allowance)) + gap - center @ d)
    helper = np.eye(3)[np.argmin(np.abs(d))]
    u = unit(np.cross(d, helper))
    v = unit(np.cross(-d, u))  # winding normal points toward the product
    span = max(np.ptp(points @ u), np.ptp(points @ v)) * 0.8 + 40.0
    surface = np.array([center - span*u - span*v, center + span*u - span*v,
                        center + span*u + span*v, center - span*u + span*v])
    return surface


def new_run(output_root: Path, solver: str):
    output_root.mkdir(parents=True, exist_ok=True)
    try:
        date = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%y%m%d")
    except ZoneInfoNotFoundError:
        from datetime import timezone, timedelta
        date = datetime.now(timezone(timedelta(hours=9))).strftime("%y%m%d")
    for number in range(1, 100000):
        folder = output_root / f"doe_{solver}_{date}_r{number:02d}"
        try:
            folder.mkdir()
            return folder
        except FileExistsError:
            continue
    raise RuntimeError("실행 폴더 번호를 할당할 수 없습니다.")
