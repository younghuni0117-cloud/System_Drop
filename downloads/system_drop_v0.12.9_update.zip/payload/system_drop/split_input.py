"""Keep Abaqus run decks as main/material/mesh includes; retain old-run support."""
from pathlib import Path
from .assembly import blocks,card
from .inp_format import format_inp
from .deck import keyword,id_lines


def product_sets(text,mesh):
    """Reuse complete template sets; repair only generated working-deck sets."""
    required={"*NSET":("PRODUCT_NODES",mesh.nsets,mesh.product_nodes),
              "*ELSET":("PRODUCT_ELEMENTS",mesh.elsets,mesh.product_elements)}
    repair={c for c,(name,existing,labels) in required.items()
            if set(existing.get(name,())) != set(labels)}
    result=[]
    for b in blocks(text.splitlines()):
        c=card(b)
        if c in required:
            name=keyword(b[0])[1].get(c[1:])
            canonical=required[c][0]
            if name == "AUTO_"+canonical or (c in repair and name==canonical):continue
        result.extend(b)
    for c in repair:
        name,_,labels=required[c]
        result.extend([f"{c}, {c[1:]}={name}",id_lines(labels)])
    return "\n".join(result)+"\n"



def execution_input(folder,solver):
    folder=Path(folder)
    if solver=='abaqus' and not (folder/'job.inp').exists() and (folder/'abaqus_main.inp').exists():return folder/'abaqus_main.inp'
    return folder/'job.inp'


def publish_abaqus_input(folder):
    folder=Path(folder);staging=folder/'job.inp';text=staging.read_text(encoding='utf-8-sig')
    if any(card(b)=='*IMPORT' for b in blocks(text.splitlines())):
        mesh=[];main=[];in_step=False
        geometry={'*IMPORT','*NODE','*ELEMENT','*NSET','*ELSET','*SURFACE'}
        for block in blocks(text.splitlines()):
            c=card(block)
            if c=='*STEP':in_step=True
            (mesh if not in_step and c in geometry else main).extend(block)
        # Material/section state belongs to the imported native model. Do not
        # redefine it, or redefine imported nodes/elements in the mesh include.
        (folder/'abaqus_material.inp').write_text('** Material and section history retained by *IMPORT, STATE=YES.\n** No material redefinition is required for this continuation.\n',encoding='utf-8')
        (folder/'abaqus_mesh.inp').write_text(format_inp('\n'.join(mesh)+'\n'),encoding='utf-8')
        # Keep HEADING and its data first; include import/sets before main model properties.
        head=next((i for i,l in enumerate(main) if l.strip().startswith('*') and not l.strip().startswith('**') and l.strip().upper()!='*HEADING'),len(main))
        main[head:head]=['*INCLUDE, INPUT=abaqus_material.inp','*INCLUDE, INPUT=abaqus_mesh.inp']
        text='\n'.join(main)+'\n'
    (folder/'abaqus_main.inp').write_text(format_inp(text),encoding='utf-8')
    staging.unlink()
    return folder/'abaqus_main.inp'


CALCULIX_ENTRY='** SYSTEM_DROP_ENTRY=calculix_main.inp'


def calculix_model_input(folder):
    """Only our explicit entry marker selects the managed main; legacy stays job."""
    folder=Path(folder);job=folder/'job.inp'
    if CALCULIX_ENTRY in job.read_text(encoding='utf-8-sig'):
        return folder/'calculix_main.inp'
    return job


def publish_calculix_input(folder):
    folder=Path(folder);job=folder/'job.inp'
    if calculix_model_input(folder)!=job:return folder/'calculix_main.inp'
    text=job.read_text(encoding='utf-8-sig')
    main=folder/'calculix_main.inp'
    main.write_text(format_inp(text),encoding='utf-8')
    # Keep the native job.rin/rout and result base names unchanged.
    job.write_text(CALCULIX_ENTRY+'\n** Solver entry: ccx -i job; model and time settings are in the included main.\n*INCLUDE, INPUT=calculix_main.inp\n',encoding='utf-8')
    return main
