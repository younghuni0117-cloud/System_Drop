"""Bounded-memory indexing of ASCII FRD and DAT; validate all raw values.

The index retains times/byte offsets, not per-node/per-element histories. Selected
frames are read from the original file without interpolation or frame reordering.
"""
from pathlib import Path
import re,math
import numpy as np
from .results import frd_values,grid_from_mesh


def _lines(path,start=0,stop=None,progress=None):
    total=Path(path).stat().st_size;offset=start;last=start
    with Path(path).open('rb') as stream:
        stream.seek(start)
        while stop is None or offset<stop:
            raw=stream.readline()
            if not raw:break
            begin=offset;offset+=len(raw)
            if progress and offset-last>=1024*1024:progress(offset,total);last=offset
            yield begin,raw.decode('ascii',errors='replace').rstrip('\r\n')
    if progress:progress(min(offset,total),total)


def frd_groups(path,product,start=0,stop=None,initial_time=0.,progress=None):
    current_time=initial_time;frame_time=None;begin=None;fields={}
    name=None;data={};declared=0;components=0;last_label=None
    for offset,line in _lines(path,start,stop,progress):
        if line.startswith('  100C'):
            try:current_time=float(line[12:24].replace('D','E'))
            except ValueError:raise ValueError(f'FRD 시간 형식 오류: {path}: byte {offset}')
            if not math.isfinite(current_time):raise ValueError('FRD 비유한 결과 시간')
        elif line.startswith(' -4'):
            if name is not None:raise ValueError(f'FRD 결과 블록이 끝나기 전에 다음 블록이 시작됐습니다: {name}')
            parts=line.split();next_name=parts[1]
            if fields and (current_time!=frame_time or next_name in fields):
                yield {'time':frame_time,'fields':fields,'start':begin,'stop':offset}
                fields={}
            if not fields:frame_time=current_time;begin=offset
            name=next_name;declared=int(parts[2]);data={};components=0;last_label=None
        elif line.startswith(' -5') and name:
            parts=line.split()
            if len(parts)<7 or not parts[6].startswith('1'):components+=1
        elif line.startswith(' -1') and name:
            try:label=int(line[3:13])
            except ValueError:raise ValueError(f'FRD 노드 번호 오류: {path}: byte {offset}')
            data[label]=frd_values(line[13:],min(6,components or declared),f'{name}, node {label}, byte {offset}')
            last_label=label
        elif line.startswith(' -2') and name:
            if last_label is None:raise ValueError('FRD 연속 행에 이전 노드가 없습니다.')
            remaining=(components or declared)-len(data[last_label])
            if remaining<=0:raise ValueError(f'FRD 초과 연속 행: {name}, node {last_label}')
            data[last_label]+=frd_values(line[3:],min(6,remaining),f'{name}, node {last_label}, byte {offset}')
        elif line.startswith(' -3') and name:
            for label,values in data.items():
                if len(values)!=(components or declared):raise ValueError(f'FRD 성분 누락: {name}, node {label}')
            fields[name]={n:v for n,v in data.items() if n in product}
            name=None;data={};last_label=None
    if name is not None:raise ValueError(f'FRD 결과 블록이 끝나기 전에 파일이 종료됐습니다: {name}')
    if fields:yield {'time':frame_time,'fields':fields,'start':begin,'stop':stop if stop is not None else Path(path).stat().st_size}


def check_displacements(fields,product):
    displacement=fields.get('DISP',{})
    if not displacement:return False
    missing=set(product)-set(displacement)
    if missing:raise ValueError(f'FRD 변위에서 제품 노드 {len(missing)}개가 누락됐습니다.')
    if any(len(v)!=3 for v in displacement.values()):raise ValueError('FRD DISP에는 XYZ 세 성분이 필요합니다.')
    return True


def index_frd(path,mesh,progress=None):
    indices=[]
    for group in frd_groups(path,mesh.product_nodes,progress=progress):
        if check_displacements(group['fields'],mesh.product_nodes):
            indices.append({k:group[k] for k in ('time','start','stop')})
    if not indices:raise ValueError('FRD에서 원래 제품 노드의 변위 프레임을 읽지 못했습니다.')
    return indices


def load_frd_frame(path,mesh,index,progress=None):
    reader=frd_groups(path,mesh.product_nodes,index['start'],index['stop'],index['time'],progress)
    try:group=next(reader)
    finally:reader.close()
    fields=group['fields'];check_displacements(fields,mesh.product_nodes)
    coords={n:(np.asarray(p)+np.asarray(fields['DISP'][n])).tolist() for n,p in mesh.product_nodes.items()}
    grid=grid_from_mesh(mesh,coords);labels=sorted(mesh.product_nodes)
    for name,data in fields.items():
        if set(labels).issubset(data):
            counts={len(data[n]) for n in labels}
            if len(counts)!=1:raise ValueError(f'FRD {name} 노드별 성분 개수가 일치하지 않습니다.')
            values=np.asarray([data[n] for n in labels],dtype=float)
            grid.point_data[name]=values[:,0] if values.shape[1]==1 else values
            if name=='STRESS' and values.shape[1]>=6:
                xx,yy,zz,xy,yz,zx=values[:,:6].T
                grid.point_data['S Mises (MPa)']=np.sqrt(.5*((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)+3*(xy**2+yz**2+zx**2))
    return group['time'],grid,coords,fields


def dat_groups(path,start=0,stop=None,progress=None,index_only=False):
    if not Path(path).exists():return
    time=None;active=False;data={};begin=None
    def summarized():return {e:(v[0]/v[1],v[2]) for e,v in data.items()}
    for offset,line in _lines(path,start,stop,progress):
        if 'stresses (elem, integ.pnt.' in line.lower() and 'time' in line.lower():
            if time is not None:yield {'time':time,'data':summarized(),'start':begin,'stop':offset}
            match=re.search(r'\btime\s+([-+0-9.eEdD]+)',line,re.I)
            time=float(match[1].replace('D','E')) if match else None
            if time is not None and not math.isfinite(time):raise ValueError('CalculiX DAT stress time is nonfinite.')
            active=time is not None;data={};begin=offset;continue
        if active:
            pieces=line.split()
            if pieces and pieces[0].isdigit():
                if not (len(pieces)==8 or (len(pieces)==9 and pieces[8].startswith('_shell_'))):raise ValueError(f'CalculiX DAT stress row needs element, IP and six stresses: {line.strip()}')
                def value(token):
                    token=token.replace('D','E').replace('d','e')
                    if 'E' not in token.upper():token=re.sub(r'([0-9.])([+-]\d{3})$',r'\1E\2',token)
                    return float(token)
                vals=[value(p) for p in pieces[:8]]
                if not all(math.isfinite(v) for v in vals):raise ValueError('CalculiX DAT stress contains nonfinite values.')
                if index_only:continue
                tensor=np.array([vals[i] for i in (2,3,4,5,7,6)])
                element=int(vals[0])
                if element not in data:data[element]=[np.zeros(6),0,0.]
                entry=data[element];entry[0]+=tensor;entry[1]+=1
                xx,yy,zz,xy,yz,zx=tensor
                entry[2]=max(entry[2],float(np.sqrt(.5*((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)+3*(xy*xy+yz*yz+zx*zx))))
            elif line.strip():active=False
    if time is not None:yield {'time':time,'data':summarized(),'start':begin,'stop':stop if stop is not None else Path(path).stat().st_size}


def index_dat(path,progress=None):
    return [{k:g[k] for k in ('time','start','stop')} for g in dat_groups(path,progress=progress,index_only=True)]


def load_dat_frame(path,index,progress=None):
    reader=dat_groups(path,index['start'],index['stop'],progress)
    try:return next(reader)['data']
    finally:reader.close()
