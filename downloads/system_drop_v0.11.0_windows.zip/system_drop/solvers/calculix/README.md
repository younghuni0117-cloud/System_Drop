# Bundled CalculiX 2.23 for Windows x64

The application uses `bin/ccx_MT.exe` by default, directly through Python subprocess.
There is no requirement to add it to the system PATH or install CalculiX separately.
Keep the DLL files next to the executable. An external solver can be selected in
the application's detailed settings. No solver download occurs during application startup.

Unmodified binaries from:
https://github.com/calculix/CalculiX-Windows/blob/60c9a10b350ec813f4d493098f47f7a8b96cd276/releases/CalculiX-2.23.0-win-x64.zip

The archive checksum, executable/DLL checksums and source checksums are recorded
in `manifest.json`. `bin/buildInfo.log` records the upstream compiler versions.

The original GPL license is in `bin/LICENSE.txt`. Original notices are preserved
in `UPSTREAM_OSS_NOTICE.pdf` and `UPSTREAM_README.txt`. The latter belongs to the
upstream full CCX/CGX package; this application only uses the CCX solver directly.
Gnuplot, ImageMagick, CGX, shell environment scripts and file associations are not needed.

Corresponding CCX 2.23 source, ARPACK, SPOOLES, pthreads source archives, Windows
patches, Makefiles and build scripts are included under `sources/windows-build/src`.
The `downloads` subfolder contains the original source archives. GCC runtime license
and GCC Runtime Library Exception are preserved under `sources/`.
The GUI and CCX source are separate components. The executable has not been rebuilt
or modified by this project.

Validation: PE x64 executable and recursive non-system DLL dependencies checked.
Short Explicit→Implicit checks were run with Linux CalculiX 2.23.
This development workspace is Linux; execution on native Windows has not been verified here.
