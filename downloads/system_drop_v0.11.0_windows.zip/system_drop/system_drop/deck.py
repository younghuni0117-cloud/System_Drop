"""Small, deliberately strict reader for flat HyperMesh-style C3D8/S4 decks."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
import re
import numpy as np


ELEMENT_NODES={'C3D8':8,'C3D8R':8,'C3D4':4,'C3D6':6,'C3D10':10,'C3D20':20,'C3D20R':20,'S3':3,'S4':4,'S4R':4,'S8R':8}
VTK_TYPES={'C3D8':12,'C3D8R':12,'C3D4':10,'C3D6':13,'C3D10':24,'C3D20':25,'C3D20R':25,'S3':5,'S4':9,'S4R':9,'S8R':23}
SHELL_TYPES={'S3','S4','S4R','S8R'}


def tokens(line):
    result=[];part='';quote=None
    for ch in line.strip():
        if ch in ('"',"'"):
            if quote==ch:quote=None
            elif quote is None:quote=ch
            part+=ch
        elif ch==',' and quote is None:result.append(part.strip());part=''
        else:part+=ch
    result.append(part.strip());return result


def keyword(line):
    parts=tokens(line);name='*'+' '.join(parts[0].lstrip('*').upper().split());params={}
    for token in parts[1:]:
        if '=' in token:
            key,value=token.split('=',1);params[' '.join(key.upper().split())]=value.strip().strip('"'+"'")
        elif token:params[token.upper()]=True
    return name,params


def logical_lines(lines):
    pending=None
    for raw in (row for item in lines for row in str(item).splitlines()):
        line=raw.strip()
        if pending is not None:
            if not line or line.startswith('**'):continue
            if line.startswith('*'):yield pending;pending=None
            else:
                flag=tokens(line)[0].upper()
                continuation='=' in line or flag in ('EXPLICIT','DIRECT','FIELD','HISTORY','GENERATE','UNSORTED','ALL EXTERIOR','SMALL SLIDING','FIXED')
                if not continuation:
                    yield pending;pending=None
                else:
                    pending+=line
                    if not pending.endswith(','):yield pending;pending=None
                    continue
        if line.startswith('*') and not line.startswith('**') and line.endswith(','):pending=line
        else:yield raw
    if pending is not None:yield pending


def include_path(parent,name):
    path=Path(parent)/name.replace('\\','/')
    if path.exists():return path.resolve()
    # Windows inputs are case insensitive; match uniquely on development hosts.
    if not path.is_absolute():path=path.absolute()
    current=Path(path.anchor)
    for part in path.parts[1:]:
        if part=='..':current=current.parent;continue
        direct=current/part
        if direct.exists():current=direct;continue
        matches=[p for p in current.iterdir() if p.name.lower()==part.lower()] if current.is_dir() else []
        if len(matches)!=1:raise FileNotFoundError('INCLUDE 파일을 찾을 수 없습니다: '+str(path))
        current=matches[0]
    return current.resolve()


def expanded_lines(path,stack=()):
    path=Path(path).resolve()
    if path in stack:raise ValueError('순환 INCLUDE: '+' -> '.join(map(str,(*stack,path))))
    for line in logical_lines(path.read_text(encoding='utf-8-sig').splitlines()):
        if line.lstrip().upper().startswith('*INCLUDE,'):
            _,params=keyword(line)
            if 'INPUT' not in params:raise ValueError('INCLUDE INPUT 누락: '+str(path))
            yield from expanded_lines(include_path(path.parent,str(params['INPUT'])),(*stack,path))
        else:yield line


@dataclass
class Mesh:
    nodes: dict[int, list[float]] = field(default_factory=dict)
    elements: dict[int, tuple[str, list[int]]] = field(default_factory=dict)
    nsets: dict[str, list[int]] = field(default_factory=dict)
    element_groups: dict[int,str] = field(default_factory=dict)
    elsets: dict[str, list[int]] = field(default_factory=dict)

    @property
    def product_elements(self):
        floor = set(self.elsets.get("FLOOR_ELEMENTS", []))
        return {k: v for k, v in self.elements.items() if k not in floor}

    @property
    def product_nodes(self):
        labels = {n for _, conn in self.product_elements.values() for n in conn}
        return {k: self.nodes[k] for k in sorted(labels)}

    def reference_points(self, coordinates=None):
        coordinates = coordinates or self.product_nodes
        result = []
        for name in ("FRAME_ORIGIN", "FRAME_X", "FRAME_Y"):
            labels = self.nsets.get(name, [])
            if len(labels) != 1 or labels[0] not in coordinates:
                raise ValueError(f"{name}에는 제품 노드 한 개가 필요합니다.")
            result.append(np.array(coordinates[labels[0]], dtype=float))
        return result


def read_mesh(path,require_frames=True):
    lines=list(expanded_lines(path))
    if any(keyword(line)[0] in ('*PART','*ASSEMBLY') for line in lines if line.strip().startswith('*') and not line.strip().startswith('**')):
        from .assembly import flatten_assembly
        lines=flatten_assembly(lines)
    return mesh_from_lines(lines,require_frames)


def mesh_from_lines(lines,require_frames=True,allow_empty_product=False):
    mesh = Mesh()
    card, params = "", {}
    raw_sets = {"*NSET": {}, "*ELSET": {}}
    pending_element=None
    for line in logical_lines(lines):
        line = line.strip()
        if not line or line.startswith("**"):
            continue
        if line.startswith("*"):
            if pending_element:raise ValueError(f"요소 {pending_element[0]} 연결 행이 끝나지 않았습니다.")
            card, params = keyword(line)
            if card in ("*PART", "*ASSEMBLY", "*INSTANCE"):
                raise ValueError("현재 버전은 flat 모델을 지원합니다. Part/Assembly 입력은 변환이 필요합니다.")
            continue
        data = [x.strip().strip('"\'') for x in tokens(line) if x.strip()]
        if card == "*NODE":
            if int(data[0]) in mesh.nodes:raise ValueError("중복 노드 번호: "+data[0])
            mesh.nodes[int(data[0])] = [float(x.replace("D", "E").replace("d","e")) for x in data[1:4]]
            if "NSET" in params:
                raw_sets["*NSET"].setdefault(str(params["NSET"]).upper(), []).append(data[0])
        elif card == "*ELEMENT":
            kind = str(params["TYPE"]).upper()
            if pending_element:
                label,conn=pending_element;conn.extend(int(x) for x in data)
            else:label=int(data[0]);conn=[int(x) for x in data[1:]]
            expected=ELEMENT_NODES.get(kind,{'R3D4':4,'MASS':1,'ROTARYI':1}.get(kind,len(conn)))
            if len(conn)<expected:pending_element=(label,conn);continue
            if len(conn)!=expected:raise ValueError(f'요소 {label} 연결 개수: {len(conn)} != {expected}')
            if label in mesh.elements:raise ValueError(f'중복 요소 번호: {label}')
            mesh.elements[label]=(kind,conn);pending_element=None
            if 'ELSET' in params:
                mesh.element_groups[label]=str(params['ELSET']).upper()
                raw_sets['*ELSET'].setdefault(str(params['ELSET']).upper(),[]).append(str(label))
        elif card in raw_sets:
            key = "NSET" if card == "*NSET" else "ELSET"
            name = str(params[key]).upper()
            target = raw_sets[card].setdefault(name, [])
            if "GENERATE" in params:
                nums = [int(x) for x in data]
                target.extend(str(x) for x in range(nums[0], nums[1] + 1, nums[2] if len(nums) > 2 else 1))
            else:
                target.extend(x.upper() for x in data)
    if pending_element:raise ValueError("마지막 요소 연결 행이 끝나지 않았습니다.")
    def resolve(name, source, chain=()):
        if name in chain:
            raise ValueError(f"집합 순환 참조: {name}")
        values = []
        for entry in source[name]:
            if entry.isdigit():
                values.append(int(entry))
            elif entry in source:
                values.extend(resolve(entry, source, (*chain, name)))
            else:
                raise ValueError(f"정의되지 않은 집합: {entry}")
        return sorted(set(values))
    for card, dest in (("*NSET", mesh.nsets), ("*ELSET", mesh.elsets)):
        for name in raw_sets[card]:
            dest[name] = resolve(name, raw_sets[card])
    for label, (kind, conn) in mesh.product_elements.items():
        if kind not in ELEMENT_NODES or len(conn)!=ELEMENT_NODES[kind]:
            raise ValueError(f"제품 요소 {label}: 지원 요소: C3D8/C3D8R/C3D4/C3D6/C3D10/C3D20/S3/S4/S4R/S8R ({kind}).")
        if any(n not in mesh.nodes for n in conn):
            raise ValueError(f"요소 {label}의 노드가 없습니다.")
    if not mesh.product_elements and not allow_empty_product:
        raise ValueError("제품 요소가 없습니다.")
    if require_frames:mesh.reference_points()
    return mesh


def block(text, name, replacement):
    pattern = rf"(?ms)^\*\* AUTO:BEGIN {re.escape(name)}\s*\n.*?^\*\* AUTO:END {re.escape(name)}\s*$"
    result, count = re.subn(pattern, lambda _: f"** AUTO:BEGIN {name}\n{replacement.rstrip()}\n** AUTO:END {name}", text)
    if count != 1:
        raise ValueError(f"자동화 블록 {name}: 정확히 한 개 필요합니다 ({count}개).")
    return result


def template_defaults(path):
    """Read the explicit step period, not an unrelated numeric line."""
    lines = list(expanded_lines(path))
    gap=None
    for line in lines:
        match=re.match(r'^\s*\*\*\s*SYSTEM_DROP_DEFAULT_GAP\s*=\s*([0-9.eE+-]+)',line)
        if match:gap=float(match.group(1))
    for index, line in enumerate(lines):
        if line.strip().upper().startswith("*DYNAMIC"):
            _, params = keyword(line)
            if "EXPLICIT" not in params:
                continue
            for data in lines[index+1:]:
                if data.strip() and not data.strip().startswith("**"):
                    nums = [x.strip() for x in data.split(",")]
                    nums += [""]*(4-len(nums))
                    values={"drop_time":float(nums[1]),"drop_dt":float(nums[0] or 0),"drop_max_dt":float(nums[3] or 0)}
                    if gap is not None:values['gap']=gap
                    return values
    raise ValueError("템플릿에서 Explicit Step 종료 시간을 읽지 못했습니다.")


def id_lines(labels):
    labels = list(labels)
    return "\n".join(", ".join(str(n) for n in labels[i:i+16]) for i in range(0, len(labels), 16))


def contact_allowances(mesh,coordinates,main,direction):
    """Project each shell half-thickness; solids get no artificial offset."""
    thickness={}
    card,params="",{}
    for line in expanded_lines(main):
        line=line.strip()
        if not line or line.startswith("**"): continue
        if line.startswith("*"):
            card,params=keyword(line); continue
        if card=="*SHELL SECTION":
            if "OFFSET" in params and float(params["OFFSET"])!=0:
                raise ValueError("Shell OFFSET이 0이 아닙니다. 자동 바닥 간격의 기준을 검토하고 midsurface 모델로 준비하세요.")
            thick=float(line.split(",")[0])
            if thick<=0: raise ValueError("Shell 두께는 양수여야 합니다.")
            for element in mesh.elsets.get(str(params["ELSET"]).upper(),[]): thickness[element]=thick
            card=""
    allowances={n:0.0 for n in coordinates}
    for element,(kind,conn) in mesh.product_elements.items():
        if kind not in SHELL_TYPES: continue
        if element not in thickness: raise ValueError(f"Shell 요소 {element}의 section 두께가 없습니다.")
        p=np.array([coordinates[n] for n in conn])
        normal=np.cross(p[1]-p[0],p[3]-p[0]); size=np.linalg.norm(normal)
        if size<1e-12: raise ValueError("Shell 요소가 퇴화했습니다.")
        offset=.5*thickness[element]*abs(np.dot(normal/size,direction))
        for n in conn: allowances[n]=max(allowances[n],offset)
    return [allowances[n] for n in coordinates]
