"""Sequential state machine; GUI/viewers never own or block the solver process."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import os
import shutil
import signal
import threading
import time

from .deck import read_mesh
from .model import Settings, STAGES, STAGE_LABELS, new_run,bundled_calculix
from .results import convert_frd, grid_from_mesh, read_state,validate_physical_state,validate_preview_fields
from .monitor import SolverMonitor, observation_line
from .output_schedule import decimal_text
from .solver import (stage_folder, snapshot_template, setup_drop, prepare_release,
                     command_args, popen, completed_successfully, progress_from_sta, resolve_solver_command,observation_output)


class Cancelled(Exception):
    pass


class Engine:
    def __init__(self,settings: Settings,workflow=False,emit=None):
        self.settings=settings
        self.workflow=workflow
        self.emit=emit or (lambda *args:None)
        self.run=None
        self.records=[{"setup":"pending","drop":"pending","release":"pending"} for _ in settings.directions]
        self.fractions={}
        self.durations={};self.started_times={}
        self.stop_after=threading.Event()
        self.cancel_now=threading.Event()
        self.process=None
        self.lock=threading.RLock()

    def initialize(self):
        self.settings.validate()
        self.run=new_run(Path(self.settings.output_root).resolve(),self.settings.solver)
        self.settings.save(self.run/"settings.json")
        snapshot=snapshot_template(self.settings,self.run)
        from .template_adapter import validate_contract
        report=validate_contract(snapshot,self.settings.solver)
        (self.run/'template_check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        self.save()
        self.log("자동화",f"실행 폴더: {self.run}")
        if self.workflow:
            self.log("자동화","워크플로 테스트: 실제 Solver를 실행하지 않으며 응력/소성 결과를 생성하지 않습니다.")

    def save(self):
        if self.run:
            data={"workflow":self.workflow,"records":self.records,
                  "durations":{f"{i}:{s}":v for (i,s),v in self.durations.items()},
                  "fractions":{f"{i}:{s}":v for (i,s),v in self.fractions.items()}}
            target=self.run/"checkpoint.json"
            tmp=target.with_suffix(".tmp")
            tmp.write_text(json.dumps(data,indent=2),encoding="utf-8")
            tmp.replace(target)

    @classmethod
    def restore(cls,folder,emit=None):
        folder=Path(folder)
        settings=Settings.read(folder/"settings.json")
        # A cumulative run is self-contained: its frozen template, not an old
        # installation path, is the authoritative model when it is reopened.
        if (folder/'template_snapshot').is_dir():
            settings.template=str((folder/'template_snapshot').resolve())
            settings.output_root=str(folder.parent.resolve())
        old_solver=settings.calculix_path
        normalized=old_solver.replace('\\','/').lower()
        if (old_solver and not Path(old_solver).is_file() and '/system_drop/solvers/calculix/bin/' in normalized
                and bundled_calculix().is_file()):
            settings.calculix_path=str(bundled_calculix())
        saved=json.loads((folder/"checkpoint.json").read_text(encoding="utf-8"))
        engine=cls(settings,saved["workflow"],emit)
        engine.run=folder
        engine.records=saved["records"]
        for k,v in saved.get("fractions",{}).items():
            i,s=k.split(":"); engine.fractions[(int(i),s)]=v
        for k,v in saved.get('durations',{}).items():
            i,s=k.split(':');engine.durations[(int(i),s)]=v
        for i,row in enumerate(engine.records):
            for stage,status in row.items():
                if status=="running":
                    row[stage]="interrupted"; engine.fractions[(i,stage)]=0
        return engine

    def next_stage(self):
        for i,row in enumerate(self.records):
            for stage in STAGES:
                if row[stage]!="done": return i,stage
        return None

    def log(self,channel,message):
        line=f"{datetime.now().astimezone().strftime('%H:%M:%S')} [{channel}] {message}"
        if self.run:
            with (self.run/"automation.log").open("a",encoding="utf-8") as file:
                file.write(line+"\n")
        self.emit("log",{"channel":channel,"text":line})

    def progress(self,index,stage,percent):
        self.fractions[(index,stage)]=max(0,min(100,percent))
        total=sum(self.fractions.get((i,s),100 if row[s]=="done" else 0)
                  for i,row in enumerate(self.records) for s in STAGES)/(3*len(self.records))
        elapsed=time.monotonic()-self.started_times[(index,stage)] if (index,stage) in self.started_times else self.durations.get((index,stage))
        self.emit("progress",{"index":index,"stage":stage,"current":percent,"overall":total,'elapsed':elapsed})

    def execute(self,automatic=True):
        self.stop_after.clear(); self.cancel_now.clear()
        try:
            self.settings.validate_runtime_scope(automatic,self.workflow)
            if not self.run: self.initialize()
            while self.next_stage():
                i,stage=self.next_stage()
                self.records[i][stage]="running"
                self.started_times[(i,stage)]=time.monotonic()
                self.progress(i,stage,0)
                self.emit("status",{"index":i,"stage":stage,"status":"running"})
                self.save()
                self.log("자동화",f"Drop {i+1:02d} / {STAGE_LABELS[stage]} 시작")
                try:
                    self.run_stage(i,stage)
                    if self.cancel_now.is_set(): raise Cancelled("사용자가 즉시 종료했습니다.")
                    self.records[i][stage]="done"
                    self.durations[(i,stage)]=time.monotonic()-self.started_times.pop((i,stage))
                    self.progress(i,stage,100)
                    self.emit("status",{"index":i,"stage":stage,"status":"done"})
                    self.log("자동화",f"Drop {i+1:02d} / {STAGE_LABELS[stage]} 완료")
                    self.save()
                except Exception as exc:
                    self.started_times.pop((i,stage),None)
                    state="interrupted" if isinstance(exc,Cancelled) else "failed"
                    self.records[i][stage]=state
                    self.fractions[(i,stage)]=0
                    self.progress(i,stage,0)
                    self.emit("status",{"index":i,"stage":stage,"status":state})
                    self.save()
                    raise
                if not automatic or self.stop_after.is_set():
                    self.log("자동화","단계 경계에서 정지했습니다. 다음 단계는 수동 실행 또는 재개할 수 있습니다.")
                    break
            if self.next_stage() is None:
                self.log("자동화","모든 단계 완료"+(" (워크플로 테스트 — 물리 해석 아님)" if self.workflow else ""))
        except Exception as exc:
            self.log("오류",str(exc))
            self.emit("error",{"text":str(exc)})
        finally:
            self.emit("idle",{})

    def run_stage(self,index,stage):
        settings=self.settings
        if stage=="setup":
            setup_drop(settings,self.run,index,self.log,self.workflow)
            return
        if self.workflow:
            self.workflow_stage(index,stage)
            return
        folder=stage_folder(self.run,index,stage)
        upstream=(stage_folder(self.run,index,'drop')/'job.rout' if stage=='release' else
                  stage_folder(self.run,index-1,'release')/'job.rout' if index else None)
        if settings.solver=='calculix':
            from .solver_cache import reusable_completion,record_completion
            from .restart_recovery import recover_overlay_error
            recovery=recover_overlay_error(folder,upstream)
            if recovery:
                record_completion(folder,legacy=True,upstream=upstream,recovery=recovery)
                self.log('자동화',f'Windows OVERLAY 오류 복구: native step {recovery["step"]}, t={recovery["total_time"]:.12g} 검증 완료. 원본 로그/재료 이력 보존.')
            if reusable_completion(folder,upstream=upstream):
                self.log('자동화','기존 솔버 정상 종료 결과 확인: 재계산 없이 결과 변환/검증부터 재시도합니다.')
                self.postprocess(index,stage,folder)
                return
            if (folder/'conversion_error.txt').exists():
                raise RuntimeError('기존 솔버 계산은 완료됐지만 완료 결과의 해시/이전 단계 검사를 통과하지 못했습니다. 자동 재계산을 중단했습니다. doe 폴더 전체와 원본 inp/FRD/native/solver_completed.json을 확인하세요.')
        if stage=="release": folder=prepare_release(settings,self.run,index,self.log)
        if settings.solver=='calculix':
            if (folder/'job.rin').is_file():
                from .restart import disable_restart_overlay
                if disable_restart_overlay(folder/'job.rin'):self.log('자동화','Native 재시작의 OVERLAY 출력 플래그 해제. 변형/재료 이력은 그대로 유지합니다.')
            path=folder/'job.inp';original=path.read_text(encoding='utf-8-sig')
            from .restart_recovery import without_overlay
            observed=observation_output(without_overlay(original))
            if observed!=original:path.write_text(observed,encoding='utf-8')
        template=settings.calculix_command if settings.solver=="calculix" else settings.abaqus_command
        previous=stage_folder(self.run,index,"drop")/"job" if stage=="release" else (
            stage_folder(self.run,index-1,"release")/"job" if index else "")
        args=command_args(template,job="job",input="job.inp",cpus=settings.cpus,
                          previous_job=previous,oldjob="",solver=settings.calculix_path or str(bundled_calculix()))
        if settings.solver=='abaqus':
            from .abaqus_audit import audit_abaqus
            report=audit_abaqus(folder/'job.inp')
            (folder/'keyword_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
            if not report['passed']:raise ValueError('Abaqus 키워드 점검 실패: '+ '; '.join(report['errors']))
            if previous and not any(arg.lower().startswith('oldjob=') for arg in args):args.append('oldjob='+str(previous))
        args=resolve_solver_command(args,settings.solver)
        self.log("솔버",f"작업 폴더 {folder}\n명령 인수 {args}")
        duration=settings.drop_time if stage=="drop" else settings.release_time
        time_offset=0.0
        if settings.solver=='calculix' and (folder/'job.rin').is_file():
            from .restart import NativeRestart
            time_offset=float(NativeRestart.read(folder/'job.rin').doubles('ttime')[0])
        env=os.environ.copy(); env["OMP_NUM_THREADS"]=str(settings.cpus)
        env["NUMBER_OF_CPUS"]=str(settings.cpus)
        env["GFORTRAN_UNBUFFERED_ALL"]="1"
        env["PATH"]=str(Path(args[0]).parent)+os.pathsep+env.get("PATH","")
        capture=folder/"solver.log"
        # Preserve previous attempts, but never report their stale simulation time.
        old=[folder/name for name in ('solver.log','job.dat','job.frd','job.sta','job.cvg','job.msg','job.rout','temporaryrestartfile') if (folder/name).exists()]
        if old:
            archive=folder/('previous_attempt_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
            archive.mkdir()
            for path in old:shutil.move(str(path),archive/path.name)
        offsets={}
        try:
            with capture.open("wb") as stream:
                self.process=popen(args,folder,stream,env)
                monitor=SolverMonitor(self.process.pid,folder,settings.solver)
                heartbeat=0;last_log=0;reported_dt=None
                while self.process.poll() is None:
                    if self.cancel_now.is_set():
                        self.terminate()
                        raise Cancelled("사용자가 솔버를 즉시 종료했습니다.")
                    self.tail(folder,offsets)
                    now=time.monotonic()
                    if now-heartbeat>=2:
                        heartbeat=now
                        data=monitor.sample(duration,time_offset)
                        self.emit("telemetry",data)
                        if data['percent'] is not None:self.progress(index,stage,data['percent'])
                        if data['dt'] and data['dt']!=reported_dt:
                            reported_dt=data['dt']
                            self.log('자동화',f"실제 안정 증분 약 {decimal_text(data['dt'])} s / 현재 증분 기준 필요 횟수 약 {data['estimated_increments']:,}회. 초기 입력 증분과 다를 수 있습니다.")
                        if now-last_log>=5:
                            last_log=now
                            self.log('관찰',observation_line(data,duration))
                    sta=folder/"job.sta"
                    if sta.exists() and settings.solver!='calculix':
                        percent=progress_from_sta(sta.read_text(errors="replace"),settings.solver,duration,stage)
                        if percent is not None: self.progress(index,stage,percent)
                    time.sleep(.2)
                returncode=self.process.wait()
            self.tail(folder,offsets)
        finally:
            if self.process is not None and self.process.poll() is None:
                self.terminate()
            self.process=None
        text=capture.read_text(errors="replace")
        recovered=None
        if settings.solver=='calculix' and returncode==0 and not completed_successfully(folder,settings.solver,text):
            from .restart_recovery import recover_overlay_error
            recovered=recover_overlay_error(folder,upstream)
        if returncode or (not recovered and not completed_successfully(folder,settings.solver,text)):
            raise RuntimeError(f"Solver가 정상 완료되지 않았습니다 (종료 코드 {returncode}). {capture}")
        if settings.solver=='calculix':
            from .solver_cache import record_completion
            record_completion(folder,upstream=upstream,recovery=recovered)
        self.postprocess(index,stage,folder)

    def postprocess(self,index,stage,folder):
        try:
            self.convert_results(index,stage,folder)
        except Cancelled:
            raise
        except Exception as exc:
            import traceback
            (folder/'conversion_error.txt').write_text(traceback.format_exc(),encoding='utf-8')
            raise RuntimeError(
                f'솔버 계산은 정상 완료됐지만 결과 변환/검증에서 실패했습니다: {exc}\n'
                '원본 FRD/native restart는 보존했습니다. 수정 버전에서 이 실행 폴더를 열고 재개하면 '
                '완료된 CalculiX 계산을 재실행하지 않고 변환부터 재시도합니다.\n'
                f'상세 오류: {folder / "conversion_error.txt"}') from exc

    def convert_results(self,index,stage,folder):
        settings=self.settings
        self.log("자동화","솔버 종료 확인; 결과 변환 및 제품 상태 확인")
        self.emit('processing',{'index':index,'stage':stage})
        main=Path(self.run)/"template_snapshot"/f"{settings.solver}_mesh.inp"
        mesh=read_mesh(main)
        if settings.solver=="calculix":
            schedule=None
            if stage=='drop' and settings.drop_max_dt>0 and 'SYSTEM_DROP_OUTPUT_INTERVAL=' in (folder/'job.inp').read_text():
                from .restart import NativeRestart
                incoming=folder/'job.rin';offset=float(NativeRestart.read(incoming).doubles('ttime')[0]) if incoming.exists() else 0.
                schedule={'period':settings.drop_time,'interval':settings.drop_max_dt,'offset':offset,
                          'end_time':float(NativeRestart.read(folder/'job.rout').doubles('ttime')[0])}
            convert_frd(folder/"job.frd",mesh,folder/"results",output_schedule=schedule)
            audit=json.loads((folder/'results/time_reconciliation.json').read_text())
            if audit['corrected_frames']:
                self.log('자동화',f"시간 표기 정리: {audit['corrected_frames']}프레임, 최대 {decimal_text(audit['max_correction_s'])} s. 출력 반올림 범위 내 보정; 프레임 순서/응력/변위 유지.")
        else:
            from .parts import mesh_parts
            names,groups=mesh_parts(mesh)
            (folder/'results').mkdir(exist_ok=True)
            (folder/'results/part_index.json').write_text(json.dumps({'names':names,'elements':groups}),encoding='utf-8')
            script=Path(__file__).resolve().parents[1]/"tools"/"export_odb.py"
            args=command_args(settings.abaqus_python,script=str(script),odb=str(folder/"job.odb"),output=str(folder/"results"))
            with (folder/"conversion.log").open("wb") as stream:
                self.process=popen(args,folder,stream)
                while self.process.poll() is None:
                    if self.cancel_now.is_set():
                        self.terminate(); raise Cancelled("결과 변환을 중지했습니다.")
                    time.sleep(.1)
                code=self.process.wait()
                self.process=None
            if code or not (folder/"results"/"state.json").exists():
                raise RuntimeError("ODB 변환 실패. conversion.log를 확인하세요.")
        state=read_state(folder/"results"/"state.json")
        validate_physical_state(state,mesh)
        validate_preview_fields(folder/'results')
        if stage=="release":
            if settings.solver=='calculix':
                from .stabilization import assess_native_release
                quality=assess_native_release(folder/'job.rout',mesh)
                (folder/'stabilization_quality.json').write_text(json.dumps(quality,indent=2),encoding='utf-8')
                self.log('자동화',f'안정화 종료: 전체 운동에너지 {quality["kinetic_before_Nmm"]:.6g} / 내부 진동 운동에너지 {quality["kinetic_after_Nmm"]:.6g} N mm, 최대 절점 속도 {quality["max_nodal_speed_mm_s"]:.6g} mm/s')
            self.log("자동화","안정화 종료 시간만으로 수렴을 보증하지 않습니다. 응력·속도 이력을 확인하세요.")

    def tail(self,folder,offsets):
        for name,channel in (("solver.log","솔버"),("job.sta",".sta"),("job.msg","솔버")):
            path=folder/name
            if not path.exists(): continue
            offset=offsets.get(name,0)
            if path.stat().st_size<offset: offset=0
            with path.open("rb") as file:
                file.seek(offset)
                data=file.read(65536)
                offsets[name]=file.tell()
            if data: self.log(channel,data.decode(errors="replace").rstrip())

    def workflow_stage(self,index,stage):
        """Only exercises scheduling/viewers; geometry unchanged, NO fake stress."""
        folder=stage_folder(self.run,index,stage)
        folder.mkdir(exist_ok=True)
        for p in range(0,100,5):
            if self.cancel_now.is_set(): raise Cancelled("워크플로 테스트 중지")
            self.progress(index,stage,p)
            time.sleep(.025)
        mesh=read_mesh(Path(self.run)/"template_snapshot"/f"{self.settings.solver}_mesh.inp")
        coords=mesh.product_nodes
        if index:
            coords=read_state(stage_folder(self.run,index-1,"release")/"results"/"state.json")["coordinates"]
        result=folder/"results"
        result.mkdir(exist_ok=True)
        grid_from_mesh(mesh,coords).save(result/"frame_0000.vtu")
        (result/"frames.json").write_text(json.dumps([{"time":0.,"file":"frame_0000.vtu"}]),encoding="utf-8")
        (result/"state.json").write_text(json.dumps({"coordinates":coords,"velocities":{},"workflow_only":True}),encoding="utf-8")
        self.log("자동화","워크플로 확인용 형상 저장 — 실제 낙하 / 응력 결과가 아닙니다.")

    def terminate(self):
        proc=self.process
        if proc is None or proc.poll() is not None: return
        if os.name=="nt":
            subprocess=__import__("subprocess")
            subprocess.run(["taskkill","/PID",str(proc.pid),"/T","/F"],capture_output=True,timeout=15)
        else:
            try: os.killpg(proc.pid,signal.SIGTERM)
            except ProcessLookupError: pass
        try: proc.wait(timeout=5)
        except __import__("subprocess").TimeoutExpired:
            if os.name!="nt":
                try: os.killpg(proc.pid,signal.SIGKILL)
                except ProcessLookupError: pass
            else: proc.kill()
            proc.wait(timeout=5)
