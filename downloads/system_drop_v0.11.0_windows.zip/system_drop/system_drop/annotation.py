"""One native VTK text/leader pair; no QWidget overlays on OpenGL."""
from PySide6 import QtCore
import numpy as np


class MaxAnnotation(QtCore.QObject):
    def __init__(self,parent,plotter):
        super().__init__(parent)
        from vtkmodules.vtkRenderingCore import vtkActor2D,vtkPolyDataMapper2D,vtkTextActor
        from vtkmodules.vtkCommonDataModel import vtkPolyData,vtkCellArray
        from vtkmodules.vtkCommonCore import vtkPoints
        self.plotter=plotter;self.viewport=parent;self.world=None;self.custom=False;self.drag=None;self.label=self
        self.position=QtCore.QPoint(0,65);self.screen_rect=QtCore.QRect()
        self.text=vtkTextActor();prop=self.text.GetTextProperty();prop.SetFontSize(10);prop.SetColor(.31,.35,.38)
        prop.SetBackgroundColor(1,1,1);prop.SetBackgroundOpacity(.9);prop.FrameOn();prop.SetFrameColor(.65,.68,.71)
        self.points=vtkPoints();self.points.SetNumberOfPoints(4);lines=vtkCellArray()
        for pair in ((0,1),(1,2),(1,3)):
            lines.InsertNextCell(2)
            for point in pair:lines.InsertCellPoint(point)
        data=vtkPolyData();data.SetPoints(self.points);data.SetLines(lines)
        mapper=vtkPolyDataMapper2D();mapper.SetInputData(data);self.leader=vtkActor2D();self.leader.SetMapper(mapper)
        self.leader.GetProperty().SetColor(.52,.55,.58);self.leader.GetProperty().SetLineWidth(1.)
        self.text.SetVisibility(False);self.leader.SetVisibility(False);parent.installEventFilter(self)
    def isVisible(self):return self.world is not None
    def pos(self):return QtCore.QPoint(self.position)
    def setGeometry(self,*args):pass
    def set_result(self,position,text):
        self.world=None if position is None else np.asarray(position,dtype=float)
        self.text.SetInput(text);self.update()
    def update(self):
        renderer=self.plotter.renderer
        for actor in (self.text,self.leader):
            if not renderer.HasViewProp(actor):renderer.AddViewProp(actor)
            actor.SetVisibility(self.world is not None)
        if self.world is None:return
        w,h=self.plotter.render_window.GetSize();qw=max(1,self.viewport.width());qh=max(1,self.viewport.height())
        sx,sy=w/qw,h/qh
        bounds=[0.,0.,0.,0.];self.text.GetBoundingBox(renderer,bounds)
        tw=max(20.,bounds[1]-bounds[0]+8);th=max(20.,bounds[3]-bounds[2]+6)
        if not self.custom:self.position=QtCore.QPoint(max(8,int(qw-tw/sx-25)),65)
        x=max(0,min(self.position.x(),int(qw-tw/sx)));y=max(0,min(self.position.y(),int(qh-th/sy)))
        self.position=QtCore.QPoint(x,y);self.screen_rect=QtCore.QRect(x,y,int(tw/sx)+8,int(th/sy)+8)
        self.text.SetDisplayPosition(round(x*sx),round(h-(y+th/sy)*sy))
        renderer.SetWorldPoint(*self.world,1);renderer.WorldToDisplay();tx,ty,_=renderer.GetDisplayPoint()
        origin=np.array([(x+tw/sx*.5)*sx,h-(y+th/sy*.5)*sy]);target=np.array([tx,ty]);delta=origin-target
        unit=delta/max(np.linalg.norm(delta),1.);normal=np.array([-unit[1],unit[0]])
        for i,p in enumerate((origin,target,target+7*unit+3*normal,target+7*unit-3*normal)):
            self.points.SetPoint(i,float(p[0]),float(p[1]),0.)
        self.points.Modified()
    def eventFilter(self,obj,event):
        if event.type()==QtCore.QEvent.Type.Resize:self.update()
        if self.world is not None and hasattr(event,'position'):
            point=event.position().toPoint()
            if event.type()==QtCore.QEvent.Type.MouseButtonPress and event.button()==QtCore.Qt.MouseButton.LeftButton and self.screen_rect.contains(point):
                self.drag=point-self.position;return True
            if event.type()==QtCore.QEvent.Type.MouseMove and self.drag is not None:
                self.position=point-self.drag;self.custom=True;self.update();self.plotter.render();return True
            if event.type()==QtCore.QEvent.Type.MouseButtonRelease and self.drag is not None:
                self.drag=None;return True
        return super().eventFilter(obj,event)
    def paint_on(self,image):return image  # Native VTK screenshot already contains annotation.
