"""Element-based display averaging. Never reconstruct unaveraged FRD stresses."""
import numpy as np


def mises(t):
    t=np.asarray(t);xx,yy,zz,xy,yz,zx=t.T
    return np.sqrt(.5*((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)+3*(xy*xy+yz*yz+zx*zx))


def stress_value(t,name):
    if name=='S Mises (MPa)':return mises(t)
    return np.asarray(t)[:,{'S11':0,'S22':1,'S33':2,'S12':3,'S23':4,'S13':5}[name]]


def contour_grid(grid,name,mode='Source',threshold=75):
    """None: per-element IP mean; Simple: tensor average at shared nodes;
    Advanced: element-nodal display limited by part, type and stress difference.
    These explicitly described algorithms do not claim HyperView equivalence.
    """
    grid=grid.copy(deep=True)
    stress=name.startswith('S') and name in ('S Mises (MPa)','S11','S22','S33','S12','S23','S13')
    if stress and 'Stress IP mean' in grid.cell_data and mode!='Source':
        tensor=np.asarray(grid.cell_data['Stress IP mean'])
        if mode=='None':
            grid.cell_data['Contour']=stress_value(tensor,name)
            return grid,'cell','요소별 IP 산술평균 · 요소 간 평균 없음'
        neighbors=[[] for _ in range(grid.n_points)]
        for i in range(grid.n_cells):
            for n in grid.get_cell(i).point_ids:neighbors[n].append(i)
        if mode=='Simple':
            avg=np.array([np.mean(tensor[ids],axis=0) for ids in neighbors])
            grid.point_data['Contour']=stress_value(avg,name)
            return grid,'point','파트 내 공유 절점에서 응력 텐서 산술평균'
        import pyvista as pv
        ids=[];cells=[];types=[];values=[];indices=[]
        equivalent=mises(tensor)
        for i in range(grid.n_cells):
            nodes=grid.get_cell(i).point_ids;offset=len(ids)
            cells.extend([len(nodes),*range(offset,offset+len(nodes))]);ids.extend(nodes);types.append(grid.celltypes[i])
            for n in nodes:
                candidates=[j for j in neighbors[n] if grid.celltypes[j]==grid.celltypes[i]]
                scale=max(float(np.max(np.abs(equivalent[candidates]))),1e-12)
                candidates=[j for j in candidates if abs(equivalent[j]-equivalent[i])/scale<=threshold/100]
                values.append(np.mean(tensor[candidates],axis=0))
            indices.append(i)
        result=pv.UnstructuredGrid(cells,np.array(types,dtype=np.uint8),grid.points[ids])
        for key,array in grid.point_data.items():result.point_data[key]=array[ids]
        for key,array in grid.cell_data.items():result.cell_data[key]=array[indices]
        for key,array in grid.field_data.items():result.field_data[key]=array
        result.point_data['Contour']=stress_value(values,name)
        return result,'point',f'요소-절점 표시 · 파트/요소종류 경계 보존 · Mises 차이 {threshold:g}%'
    # Original output is available even for legacy FRD files with no element S.
    if name in grid.point_data:
        value=np.asarray(grid.point_data[name]);association='point'
    elif name in grid.cell_data:
        value=np.asarray(grid.cell_data[name]);association='cell'
    elif stress and 'Stress IP mean' in grid.cell_data:
        value=stress_value(grid.cell_data['Stress IP mean'],name);association='cell'
    elif stress and 'STRESS' in grid.point_data:
        value=stress_value(grid.point_data['STRESS'],name);association='point'
    elif name=='PEEQ' and 'PE' in grid.point_data:value=grid.point_data['PE'];association='point'
    else:raise ValueError(f'결과 변수 없음: {name}')
    if value.ndim>1:value=np.linalg.norm(value,axis=1)
    (grid.point_data if association=='point' else grid.cell_data)['Contour']=value
    return grid,association,'원본 결과값 · FRD 절점 응력은 솔버에서 이미 평균되었을 수 있음'
