"""Fixed-floor thumbnails; the solver still uses the product's current pose."""
import numpy as np
from PySide6 import QtCore,QtGui
from .model import drop_direction


def schematic_geometry(direction,angle=30):
    d=drop_direction(direction,edge_angle=angle)
    down=np.array([0.,-1.,0.]);c=float(np.dot(d,down))
    if c<-1+1e-10:r=np.diag([1.,-1.,-1.])
    elif c>1-1e-10:r=np.eye(3)
    else:
        v=np.cross(d,down)
        k=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
        r=np.eye(3)+k+k@k/(1+c)
    body=np.array([[x,y,z] for y in (-.10,.10) for z in (-.65,.65) for x in (-1,1)])@r.T
    shift=np.array([0.,-.50-float(body[:,1].min()),0.])
    body+=shift
    floor=np.array([[-1.25,-.72,-.95],[1.25,-.72,-.95],[1.25,-.72,.95],[-1.25,-.72,.95]])
    logo=r@np.array([0.,.11,0.])+shift
    return body,floor,logo,r


def direction_icon(direction,angle=30):
    pix=QtGui.QPixmap(96,64);pix.fill(QtCore.Qt.GlobalColor.transparent)
    p=QtGui.QPainter(pix);p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
    body,floor,logo,r=schematic_geometry(direction,angle)
    def project(v):
        x,y,z=v
        return QtCore.QPointF(48+18*(.8*x-.65*z),31+18*(-.85*y+.28*x+.35*z))
    plane=QtGui.QPolygonF([project(x) for x in floor])
    p.setPen(QtGui.QPen(QtGui.QColor('#ae8544'),1.2));p.setBrush(QtGui.QColor('#e0ba78'));p.drawPolygon(plane)
    faces=[([0,1,3,2],'#b4c9da'),([4,5,7,6],'#e4edf5'),([0,1,5,4],'#a6bfd3'),
           ([2,3,7,6],'#b8cddd'),([0,2,6,4],'#9fb8cd'),([1,3,7,5],'#a9c0d3')]
    camera=np.array([1.,1.4,1.])
    faces.sort(key=lambda fc:float(body[fc[0]].mean(axis=0)@camera))
    for face,color in faces:
        p.setBrush(QtGui.QColor(color));p.setPen(QtGui.QPen(QtGui.QColor('#526d84'),1.2))
        p.drawPolygon(QtGui.QPolygonF([project(body[i]) for i in face]))
    if float(r[:,1]@camera)>0:
        p.setPen(QtCore.Qt.PenStyle.NoPen);p.setBrush(QtGui.QColor('#6185a7'));p.drawEllipse(project(logo),2.5,1.4)
    p.save();p.setOpacity(.25);p.setPen(QtGui.QPen(QtGui.QColor('#a77f3c'),1));p.setBrush(QtGui.QColor('#d5a856'));p.drawPolygon(plane);p.restore()
    center=body.mean(axis=0)
    a=project(center+[0,.45,0]);b=project(center+[0,-.35,0])
    p.setPen(QtGui.QPen(QtGui.QColor('#c25249'),2.6));p.drawLine(a,b)
    p.setBrush(QtGui.QColor('#c25249'));p.drawPolygon(QtGui.QPolygonF([b,QtCore.QPointF(b.x()-3,b.y()-7),QtCore.QPointF(b.x()+3,b.y()-7)]))
    p.end();return QtGui.QIcon(pix)
