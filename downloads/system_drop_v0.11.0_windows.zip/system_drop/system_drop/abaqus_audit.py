"""Focused Abaqus 2025 keyword lint; this is not a licensed Abaqus datacheck."""
from .deck import expanded_lines,keyword


def audit_abaqus(path):
    errors=[];inside=False;explicit=False;steps=0;imports=[];pending=None
    for number,line in enumerate(expanded_lines(path),1):
        line=line.strip()
        if not line or line.startswith('**'):continue
        if len(line)>256:errors.append(f'line {number}: input exceeds 256 characters')
        if line.startswith('*'):
            card,params=keyword(line)
            if card=='*STEP':
                if inside:errors.append(f'line {number}: nested STEP')
                inside=True;explicit=False;steps+=1
            elif card=='*END STEP':
                if not inside:errors.append(f'line {number}: END STEP without STEP')
                inside=False
            elif card=='*DYNAMIC':
                if not inside:errors.append(f'line {number}: DYNAMIC outside STEP')
                explicit='EXPLICIT' in params;pending='explicit' if explicit else 'implicit'
            elif card=='*CONTACT PAIR' and (not inside or not explicit):
                errors.append(f'line {number}: Explicit CONTACT PAIR must follow DYNAMIC inside STEP')
            elif card=='*IMPORT':
                if inside:errors.append(f'line {number}: IMPORT is model data')
                if params.get('STATE')!='YES' or params.get('UPDATE')!='YES':errors.append('IMPORT must retain STATE and update geometry')
                pending='import'
            elif card=='*MODEL CHANGE' and steps==1:errors.append('MODEL CHANGE is not used in the first Standard import step')
            else:pending=None
        elif pending=='explicit':
            values=[v.strip() for v in line.split(',')]+['']*4
            if values[0] or values[2]:errors.append('Explicit automatic DYNAMIC fields 1 and 3 must be blank')
            try:
                if float(values[1])<=0 or (values[3] and float(values[3])<=0):errors.append('Nonpositive explicit time')
            except ValueError:errors.append('Invalid explicit DYNAMIC time line')
            pending=None
        elif pending=='import':imports.extend(v.strip() for v in line.split(',') if v.strip())
    if inside:errors.append('Missing END STEP')
    if not steps:errors.append('No analysis STEP')
    return {'passed':not errors,'scope':'Focused keyword lint against Abaqus 2025 documentation; NOT solver datacheck',
            'steps':steps,'import_sets':imports,'errors':errors}
