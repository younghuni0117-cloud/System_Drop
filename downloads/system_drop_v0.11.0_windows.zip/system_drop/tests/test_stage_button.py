import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import numpy as np
import pytest
from PySide6.QtWidgets import QApplication
from system_drop.stage_button import duration_text,percent_text,StageButton
from system_drop.schematic import schematic_geometry
from system_drop.model import drop_direction


def test_duration_units_and_percentage_are_not_fabricated():
    assert duration_text(5)=='5s'
    assert duration_text(300)=='5min'
    assert duration_text(7200)=='2h'
    assert duration_text(.35)=='0.35s'
    assert duration_text(None)=='시간 없음'
    assert percent_text(99.9)=='99.9'


def test_clickable_wave_button_uses_solver_percent_and_completed_time():
    app=QApplication.instance() or QApplication([])
    button=StageButton();button.resize(180,22)
    button.set_stage('running',43)
    assert button.text()=='해석 중(43%)' and button.timer.isActive()
    assert not button.grab().isNull()
    button.set_stage('done',100,300)
    assert button.text()=='완료(5min)' and not button.timer.isActive()
    button.close()


@pytest.mark.parametrize('direction',range(1,19))
def test_thumbnail_floor_stays_fixed_and_product_rotates(direction):
    body,floor,logo,r=schematic_geometry(direction)
    assert np.allclose(floor,schematic_geometry(1)[1])
    assert np.allclose(r@drop_direction(direction),[0,-1,0])
    assert body[:,1].min()>floor[:,1].max()
