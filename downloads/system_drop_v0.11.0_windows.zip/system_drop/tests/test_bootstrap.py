from pathlib import Path
from types import SimpleNamespace
import pytest
import bootstrap_windows as boot


def test_no_missing_packages_never_calls_pip():
    def fail(*args,**kwargs): raise AssertionError("pip must not run")
    assert boot.ensure_requirements(Path("python.exe"),[],run=fail)==0


def test_install_only_missing_packages_without_upgrade_or_reinstall():
    commands=[]
    def run(args,**kwargs):
        commands.append(args);return SimpleNamespace(returncode=0)
    assert boot.ensure_requirements(Path("python.exe"),["pyvistaqt>=0.11"],run=run)==0
    assert commands==[["python.exe","-m","pip","install","pyvistaqt>=0.11"]]


def test_reuses_complete_existing_environment_instead_of_installing(monkeypatch):
    paths=[Path("current/python.exe"),Path("old_version/.venv/python.exe")]
    monkeypatch.setattr(boot,"candidate_interpreters",lambda root:iter(paths))
    selected,missing=boot.select_interpreter(Path("project"),probe=lambda p:["PySide6>=6.6"] if p==paths[0] else [])
    assert selected==paths[1] and missing==[]


def test_virtualenv_interpreter_symlink_is_not_resolved_to_base_python(tmp_path,monkeypatch):
    base=tmp_path/"base_python";base.write_text("binary")
    venv=tmp_path/".venv/bin/python";venv.parent.mkdir(parents=True)
    try: venv.symlink_to(base)
    except OSError: pytest.skip("Symlink permission not available")
    monkeypatch.delenv("SYSTEM_DROP_PYTHON",raising=False)
    monkeypatch.setattr(boot.sys,"executable",str(venv))
    assert next(boot.candidate_interpreters(tmp_path))==venv
