import gzip,json
from pathlib import Path
import numpy as np
import pytest
from system_drop.model import ROOT,Settings
from system_drop.deck import read_mesh
from system_drop.stabilization import (brick_masses,remove_rigid_velocity,template_masses,
    prepare_native_release,release_matches_upstream)
from system_drop.restart import NativeRestart,disable_restart_overlay


def test_rigid_translation_and_spin_removed_but_breathing_mode_preserved():
    p=np.array([[a,b,c] for a in (-1,1) for b in (-1,1) for c in (-1,1)],float)
    m=np.ones(8);vibration=.2*p
    v=vibration+[42,-1900,7]+np.cross([.4,-.7,2],p)
    residual,report=remove_rigid_velocity(p,v,m)
    np.testing.assert_allclose(residual,vibration,atol=1e-12)
    np.testing.assert_allclose(report['residual_linear_momentum'],0,atol=1e-11)
    np.testing.assert_allclose(report['residual_angular_momentum'],0,atol=1e-11)
    assert report['kinetic_after_Nmm']==pytest.approx(.5*8*3*.2**2)
    assert report['kinetic_after_Nmm']<report['kinetic_before_Nmm']


def test_two_material_blocks_preserve_mass_and_shared_interface():
    for solver in ('calculix','abaqus'):
        main=ROOT/f'template_{solver}/{solver}_main.inp';mesh=read_mesh(main)
        masses=template_masses(mesh,main)
        assert sum(masses.values())==pytest.approx(304*212*8*(2.7e-9+1.2e-9))
        assert len(mesh.product_nodes)==585 and len(mesh.product_elements)==384
        layers=[]
        for i in (1,2):
            ids=mesh.elsets[f'BODY_{i}'];assert len(ids)==192
            nodes={n for e in ids for n in mesh.elements[e][1]};layers.append(nodes)
            assert len({round(mesh.nodes[n][1],6) for n in nodes})==3
        assert len(layers[0]&layers[1])==117
        text=main.read_text().upper()
        assert '*TIE' not in text and '*SHELL SECTION' not in text
        assert 'LOGO' not in (main.parent/f'{solver}_mesh.inp').read_text()
        assert 'PRODUCT_CONTACT' in text or 'PRODUCT_CONTACT' in (main.parent/f'{solver}_mesh.inp').read_text()


def test_native_projection_changes_only_velocity_and_damping_preserving_material(tmp_path):
    source=tmp_path/'source.rout';source.write_bytes(gzip.decompress((Path(__file__).parent/'fixtures/plastic_release_223.rout.gz').read_bytes()))
    mesh=read_mesh(ROOT/'template_calculix_reference/calculix_mesh.inp')
    r=NativeRestart.read(source);physical=np.array(sorted(r.product_labels(mesh)))-1
    co=r.doubles('co').reshape(-1,3);u=r.doubles('vold').reshape(-1,4)
    v=r.doubles('veold').reshape(-1,4).copy();p=(co+u[:,1:4])[physical]
    v[physical,1:4]=[20,2000,5]+np.cross([.1,.2,-.4],p-p.mean(axis=0))
    r.replace('veold',v);r.write(source);original=source.read_bytes()
    target=tmp_path/'job.rin';report=prepare_native_release(source,target,mesh,20.)
    incoming=NativeRestart.read(target)
    assert incoming.history_hashes()==r.history_hashes()
    assert set(report['changed_records'])=={'veold','xmodal'}
    assert report['kinetic_after_Nmm']<1e-20
    assert source.read_bytes()==original
    assert incoming.doubles('xmodal')[0]==20 and incoming.doubles('xmodal')[1]==0
    (tmp_path/'stabilization_transfer.json').write_text(json.dumps(report))
    assert release_matches_upstream(source,target,tmp_path)
    disable_restart_overlay(target)
    assert release_matches_upstream(source,target,tmp_path)
    incoming=NativeRestart.read(target);changed=incoming.doubles('sti').copy();changed[0]+=1
    incoming.replace('sti',changed);incoming.write(target)
    assert not release_matches_upstream(source,target,tmp_path)


def test_negative_damping_rejected_and_zero_supported():
    with pytest.raises(ValueError):Settings(release_damping=-1).validate()
    Settings(release_damping=0).validate()


def test_inverted_mass_geometry_is_rejected():
    with pytest.raises(ValueError):brick_masses(np.zeros((8,3)),1.)


def test_next_drop_restores_original_damping_and_new_release_cache_is_reusable(tmp_path):
    from system_drop.engine import Engine
    from system_drop.solver import setup_drop
    from system_drop.solver_cache import record_completion,reusable_completion
    s=Settings(template=str(ROOT/'template_calculix_reference'),directions=[1,2],output_root=str(tmp_path))
    e=Engine(s);e.initialize()
    first=e.run/'drop_01';first.mkdir()
    original=gzip.decompress((Path(__file__).parent/'fixtures/plastic_release_223.rout.gz').read_bytes())
    (first/'job.rout').write_bytes(original)
    release=e.run/'release_01';release.mkdir()
    mesh=read_mesh(ROOT/'template_calculix_reference/calculix_mesh.inp')
    report=prepare_native_release(first/'job.rout',release/'job.rin',mesh,20.)
    (release/'stabilization_transfer.json').write_text(json.dumps(report))
    (release/'job.inp').write_text('*RESTART,READ\n*STEP\n*END STEP\n')
    # A completion receipt checks the projected incoming state against its source.
    (release/'job.rout').write_bytes((release/'job.rin').read_bytes())
    (release/'job.frd').write_text('result')
    (release/'solver.log').write_text('Job finished\nTotal CalculiX Time: 1.0\n')
    record_completion(release,upstream=first/'job.rout')
    assert reusable_completion(release,upstream=first/'job.rout')
    (release/'results').mkdir();(release/'results/state.json').write_text('{"coordinates":{},"velocities":{}}')
    following=setup_drop(s,e.run,1,e.log)
    np.testing.assert_array_equal(NativeRestart.read(following/'job.rin').doubles('xmodal')[:2],[0.,0.])
    assert '*DAMPING' not in (following/'job.inp').read_text()
