`plastic_release_223.rout.gz`: actual CalculiX 2.23 final native snapshot from
Top Face impact (1000 mm, gap .001 mm, .000060 s) → 1 s implicit stabilization.
C3D8/S4 tied aluminum example. Contains nonzero plastic material history.
Generated locally with `artifacts/impact_check_v040`; gzip contains only the last
complete step snapshot. Regression data, not a solver executable or mock state.
