from pathlib import Path
import gzip,json,hashlib
import numpy as np
import pytest
from system_drop.restart import NativeRestart,RestartError,prepare_next_impact
from system_drop.model import ROOT,Settings,floor_geometry,drop_direction,frame,impact_velocity
from system_drop.deck import read_mesh
from system_drop.engine import Engine
from system_drop.solver import setup_drop


@pytest.fixture
def native(tmp_path):
    p=tmp_path/'previous.rout'
    p.write_bytes(gzip.decompress((Path(__file__).parent/'fixtures/plastic_release_223.rout.gz').read_bytes()))
    return p


def test_native_schema_reads_actual_plastic_history_and_latest_snapshot(native,tmp_path):
    r=NativeRestart.read(native)
    assert r.sizes['step']==2 and r.sizes['nstate']==13
    assert r.mi==(27,3,1)
    assert np.any(r.doubles('sti')) and np.any(r.doubles('xstate'))
    assert r.doubles('ttime')[0]==pytest.approx(1.000060)
    r.write(tmp_path/'copy.rout')
    assert (tmp_path/'copy.rout').read_bytes()==native.read_bytes()
    (tmp_path/'multiple.rout').write_bytes(native.read_bytes()*2)
    latest=NativeRestart.read(tmp_path/'multiple.rout')
    assert latest.history_hashes()==r.history_hashes()


@pytest.mark.parametrize('direction',[1,2,7,11,18])
def test_transfer_changes_only_floor_coordinates_and_physical_velocities(native,tmp_path,direction):
    mesh=read_mesh(ROOT/'template_calculix_reference/calculix_mesh.inp')
    previous=NativeRestart.read(native)
    original=hashlib.sha256(native.read_bytes()).hexdigest()
    coords=previous.physical_coordinates(mesh.product_nodes)
    rotation=frame(*mesh.reference_points(coords))
    d=drop_direction(direction,rotation)
    surface=floor_geometry(list(coords.values()),d,.001)
    velocity=impact_velocity(1000,.001,d)
    target=tmp_path/'job.rin'
    audit=prepare_next_impact(native,target,mesh,surface,velocity)
    incoming=NativeRestart.read(target)
    assert incoming.history_hashes()==previous.history_hashes()==audit['history_sha256']
    assert incoming.physical_coordinates(mesh.product_nodes)==coords
    assert incoming.records[incoming.fields['vold']]==previous.records[previous.fields['vold']]
    assert hashlib.sha256(native.read_bytes()).hexdigest()==original
    changed=[k for k,i in previous.fields.items() if previous.records[i]!=incoming.records[i]]
    assert set(changed)<= {'co','veold'}
    co=incoming.doubles('co').reshape(-1,3)
    floor=incoming.nset('FLOOR_NODES')
    assert np.allclose(co[np.array(floor[4:])-1],surface)
    v=incoming.doubles('veold').reshape(-1,4)
    assert np.allclose(v[np.array(list(mesh.product_nodes))-1,1:4],velocity)
    # Expanded shell physical corners get translation; incompatible modes do not.
    shell=next(n for n,(kind,_) in mesh.elements.items() if kind=='S4')
    pos=int(incoming.ints('ipkon')[shell-1]);conn=incoming.ints('kon')[pos:pos+11]
    assert np.allclose(v[conn[:8]-1,1:4],velocity)
    assert not np.any(v[conn[8:11]-1,1:4])
    assert not np.any(v[np.array(floor+incoming.nset('FLOOR_REF')+incoming.nset('FLOOR_ROT'))-1,1:4])


def test_transfer_fails_closed_on_other_version_or_corruption(native,tmp_path):
    raw=native.read_bytes()
    for bad in [raw.replace(b'Version 2.23',b'Version 2.22',1),raw[:-4],b'not-a-native-restart']:
        p=tmp_path/'bad.rout';p.write_bytes(bad)
        with pytest.raises(RestartError):NativeRestart.read(p)


def test_setup_next_drop_uses_native_pose_and_reactivates_contact(native,tmp_path):
    s=Settings(template=str(ROOT/'template_calculix_reference'),directions=[1,7],output_root=str(tmp_path/'runs'))
    e=Engine(s);e.initialize()
    release=e.run/'release_01';(release/'results').mkdir(parents=True)
    (release/'job.rout').write_bytes(native.read_bytes())
    # Presence gate for a completed converted state. Exact pose comes from native.
    (release/'results/state.json').write_text(json.dumps({'coordinates':{},'velocities':{}}))
    folder=setup_drop(s,e.run,1,e.log)
    deck=(folder/'job.inp').read_text()
    assert '*RESTART, READ' in deck and '*DYNAMIC, EXPLICIT=2' in deck
    assert '*MODEL CHANGE, TYPE=CONTACT PAIR, ADD' in deck
    assert '*INITIAL CONDITIONS' not in deck and '*INCLUDE' not in deck
    assert '*SOLID SECTION' not in deck and '*TIE' not in deck
    metadata=json.loads((folder/'setup.json').read_text())
    mesh=read_mesh(ROOT/'template_calculix_reference/calculix_mesh.inp')
    coords=NativeRestart.read(native).physical_coordinates(mesh.product_nodes)
    assert metadata['origin']==coords[mesh.nsets['FRAME_ORIGIN'][0]]
    assert json.loads((folder/'transfer.json').read_text())['native_material_history_preserved']


def test_deformed_shell_outer_surface_controls_next_floor_gap(native,tmp_path):
    # A synthetic outer-layer thickness change tests floor placement using actual
    # expanded coordinates, instead of assuming the original section thickness.
    mesh=read_mesh(ROOT/'template_calculix_reference/calculix_mesh.inp')
    r=NativeRestart.read(native)
    extra=sorted(r.product_labels(mesh)-set(mesh.product_nodes))
    u=r.doubles('vold').reshape(-1,4).copy()
    u[np.asarray(extra)-1,2]+=3
    r.replace('vold',u)
    s=Settings(template=str(ROOT/'template_calculix_reference'),directions=[1,1],gap=.001,output_root=str(tmp_path/'run'))
    e=Engine(s);e.initialize()
    prev=e.run/'release_01';(prev/'results').mkdir(parents=True)
    r.write(prev/'job.rout')
    (prev/'results/state.json').write_text('{"coordinates":{},"velocities":{}}')
    folder=setup_drop(s,e.run,1,e.log)
    meta=json.loads((folder/'setup.json').read_text());d=np.array(meta['direction'])
    actual=np.array(list(r.physical_coordinates(r.product_labels(mesh)).values()))
    assert np.min(np.array(meta['floor'])@d)-np.max(actual@d)==pytest.approx(.001)
