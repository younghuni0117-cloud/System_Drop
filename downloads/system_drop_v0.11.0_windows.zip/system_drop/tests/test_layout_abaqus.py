from pathlib import Path
import numpy as np
from system_drop.model import ROOT,Settings
from system_drop.deck import read_mesh,expanded_lines
from system_drop.inp_format import format_inp,BORDER
from system_drop.abaqus_audit import audit_abaqus
from system_drop.engine import Engine
from system_drop.solver import setup_drop


def semantic(text):return [s.strip() for s in text.splitlines() if s.strip() and not s.strip().startswith('**')]


def test_format_is_idempotent_and_changes_only_comments():
    text='*HEADING\nSample\n*INCLUDE, INPUT=mesh.inp\n*STEP\n*DYNAMIC, EXPLICIT\n, .02,, 1e-6\n*END STEP\n'
    out=format_inp(text)
    assert semantic(out)==semantic(text)
    assert format_inp(out)==out
    assert out.startswith(BORDER+'\n** 00SYSTEM_DROP\n')


def test_refined_templates_and_generated_decks_keep_grouping_and_unique_labels(tmp_path):
    for solver in ['calculix','abaqus']:
        main=ROOT/f'template_{solver}/{solver}_main.inp'
        mesh=read_mesh(main)
        assert sum(k=='C3D8' for k,_ in mesh.product_elements.values())==384
        assert sum(k=='S4' for k,_ in mesh.product_elements.values())==0
        assert all(len(mesh.elsets[f'BODY_{i}'])==192 for i in (1,2))
        assert 'LOGO_NODES' not in mesh.nsets
        assert not set(mesh.nsets['FLOOR_NODES'])&set(mesh.product_nodes)
        text=main.read_text()
        for name in ['00SYSTEM_DROP','01 MODEL','02 FLOOR GEOMETRY','03 SECTIONS']:assert '** '+name in text
        e=Engine(Settings(solver=solver,template=str(main.parent),directions=[1],output_root=str(tmp_path/solver)),workflow=True);e.initialize()
        folder=setup_drop(e.settings,e.run,0,e.log,True)
        assert '*TIE' not in (folder/'job.inp').read_text()
        if solver=='abaqus':assert audit_abaqus(folder/'job.inp')['passed']


def test_old_explicit_contact_pair_location_is_rejected(tmp_path):
    bad=tmp_path/'bad.inp'
    bad.write_text('*CONTACT PAIR, INTERACTION=C\nP,F\n*STEP\n*DYNAMIC, EXPLICIT\n,.02,,1e-6\n*END STEP\n')
    assert not audit_abaqus(bad)['passed']
