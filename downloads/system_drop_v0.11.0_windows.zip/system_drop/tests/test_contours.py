import numpy as np
import pyvista as pv
from system_drop.contours import contour_grid
from system_drop.parts import ensure_parts


def two_cells():
    # Two quads sharing two nodes, with discontinuous uniaxial stress.
    grid=pv.UnstructuredGrid([4,0,1,2,3,4,1,4,5,2],[9,9],
        np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[2,0,0],[2,1,0]],dtype=float))
    grid.cell_data['Stress IP mean']=np.array([[10.,0,0,0,0,0],[100.,0,0,0,0,0]])
    grid.point_data['Node ID']=np.arange(6);grid.cell_data['Element ID']=[1,2]
    ensure_parts(grid);return grid


def test_none_simple_and_thresholded_advanced_are_distinct_and_do_not_modify_raw():
    original=two_cells()
    none,a,_=contour_grid(original,'S Mises (MPa)','None')
    simple,b,_=contour_grid(original,'S Mises (MPa)','Simple')
    advanced,c,_=contour_grid(original,'S Mises (MPa)','Advanced',10)
    assert a=='cell' and np.array_equal(none.cell_data['Contour'],[10,100])
    assert b=='point' and simple.point_data['Contour'][1]==55
    assert c=='point' and advanced.n_points==8
    assert set(advanced.point_data['Contour'])=={10,100}
    assert 'Contour' not in original.array_names
    assert np.array_equal(original.cell_data['Stress IP mean'][:,0],[10,100])


def test_tensor_averaging_precedes_mises_and_keeps_sign_of_components():
    grid=two_cells();grid.cell_data['Stress IP mean'][1,0]=-10
    out,_,_=contour_grid(grid,'S Mises (MPa)','Simple')
    assert out.point_data['Contour'][1]==0
    source,_,_=contour_grid(grid,'S11','None')
    assert source.cell_data['Contour'][1]==-10
