from pathlib import Path
import sys,json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets,QtCore
from system_drop.viewer import Viewer
from system_drop.gui import Window,STYLE
from system_drop.model import ROOT
app=QtWidgets.QApplication([]);app.setQuitOnLastWindowClosed(False);app.setStyleSheet(STYLE)
w=Window(preferences_path=False);w.show();app.processEvents()
assert w.expected_frames.text()=='예상 Frame : 60개';assert w.expected_release_frames.text()=='예상 Frame : 100개'
assert w.expected_frames.styleSheet()==w.live.styleSheet()
w.grab().save(str(ROOT/'artifacts/gui_v011.png'));w.close()
v=Viewer(ROOT/'examples/two_material');v.show();v.scalar.setCurrentText('S Mises (MPa)');v.contour_mode.setCurrentText('Discrete');v.contour_levels.setValue(8)
assert v.option_tabs.count()==3
assert v.transitions.isEnabled() and v.view_mode.currentData()=='center'
assert any(r['kind']=='transition' for r in v.records)
v.perspective.click();assert v.plotter.camera.parallel_projection
v.perspective.click();assert not v.plotter.camera.parallel_projection
v.floor_color='#a8c5db';v.draw()
actors=[a for name,a in v.plotter.actors.items() if name.startswith('product_')]
assert actors and all(a.mapper.lookup_table.n_values==8 for a in actors)
assert {i.text(0) for i in v.part_items.values()}=={'BODY_1','BODY_2'}
def finish():
 v.option_tabs.setCurrentIndex(1);v.grab().save(str(ROOT/'artifacts/viewer_v011.png'))
 (ROOT/'artifacts/viewer011_summary.json').write_text(json.dumps({'success':True,'tabs':3,'parts':2,'discrete_levels':8,'projection_toggle':True,'center_transitions':True,'floor_color':v.floor_color,'drop_expected_frames':60,'release_expected_frames':100},indent=2));v.close();app.quit()
QtCore.QTimer.singleShot(500,finish);app.exec()
