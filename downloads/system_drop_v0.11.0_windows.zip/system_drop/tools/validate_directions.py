"""Check all 18 generated CalculiX decks in free flight for 1e-9 s."""
from pathlib import Path
import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
import tempfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import Settings,ROOT,new_run
from system_drop.solver import setup_drop


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--ccx",required=True)
    parser.add_argument("--workers",type=int,default=1)
    args=parser.parse_args()
    binary=str(Path(args.ccx).resolve())
    reports=[]
    with tempfile.TemporaryDirectory(prefix="system_drop_directions_") as temp:
        def check(direction):
            settings=Settings(directions=[direction],drop_time=1e-9)
            folder=setup_drop(settings,new_run(Path(temp),"calculix"),0,lambda *args:None)
            path=folder/"job.inp"
            path.write_text(path.read_text().replace("*RESTART, WRITE, FREQUENCY=1","*RESTART, WRITE, FREQUENCY=0"))
            env=os.environ.copy();env["OMP_NUM_THREADS"]="1"
            result=subprocess.run([binary,"-i","job"],cwd=folder,env=env,stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT,text=True,timeout=120)
            passed=result.returncode==0 and "Job finished" in result.stdout and "*ERROR" not in result.stdout
            return {"direction":direction,"success":passed,"exit_code":result.returncode,
                    "error_tail":result.stdout[-1500:] if not passed else ""}
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,args.workers)) as pool:
            reports=list(pool.map(check,range(1,19)))
    report={"kind":"18-direction keyword/free-flight check; 1e-9 s, NOT impact validation","results":reports}
    (ROOT/"artifacts").mkdir(exist_ok=True)
    (ROOT/"artifacts/calculix_directions.json").write_text(json.dumps(report,indent=2))
    print(json.dumps({"passed":sum(r["success"] for r in reports),"total":18},indent=2))
    return 0 if all(r["success"] for r in reports) else 1


if __name__=="__main__": raise SystemExit(main())
