"""Execute actual CalculiX cumulative impacts; no mocked solver or material state.

For a short 18-direction connection test use --drop-time 0.000001.
The default 0.000060 is the longer example impact period. A seed may reuse an
already solved first drop+stabilization (copied native files and results).
"""
from pathlib import Path
import argparse,json,shutil,sys,time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import Settings,ROOT
from system_drop.engine import Engine
from system_drop.restart import NativeRestart
from system_drop.results import read_state


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--ccx',required=True)
    p.add_argument('--directions',default=','.join(map(str,range(1,19))))
    p.add_argument('--drop-time',type=float,default=.000060)
    p.add_argument('--release-time',type=float,default=1.)
    p.add_argument('--seed-first',type=Path)
    p.add_argument('--output',type=Path,default=ROOT/'artifacts/cumulative_validation')
    args=p.parse_args()
    s=Settings(directions=[int(v) for v in args.directions.split(',')],scenario='Custom',
               drop_time=args.drop_time,release_time=args.release_time,
               release_dt=min(.01,args.release_time),release_max_dt=min(.01,args.release_time),
               output_root=str(args.output.resolve()),calculix_path=str(Path(args.ccx).resolve()))
    errors=[]
    def emit(name,data):
        if name=='error':errors.append(data['text'])
        if name in ('status','error'):print(name,json.dumps(data,ensure_ascii=False),flush=True)
    e=Engine(s,emit=emit);e.initialize()
    if args.seed_first:
        seed=args.seed_first.resolve()
        saved=Settings.read(seed/'settings.json')
        if saved.directions[0]!=s.directions[0] or saved.height!=s.height or saved.gap!=s.gap:
            raise ValueError('Seed first direction/height/gap does not match.')
        for kind in ('mesh','material'):
            if (seed/f'template_snapshot/calculix_{kind}.inp').read_bytes()!=(e.run/f'template_snapshot/calculix_{kind}.inp').read_bytes():
                raise ValueError('Seed template mismatch.')
        for name in ('drop_01','release_01'):shutil.copytree(seed/name,e.run/name)
        e.records[0]=dict.fromkeys(('setup','drop','release'),'done');e.save()
    start=time.monotonic();e.execute()
    report={'success':e.next_stage() is None,'solver':'CalculiX 2.23','platform':sys.platform,
            'run':str(e.run),'directions':s.directions,'drop_time':s.drop_time,
            'release_time':s.release_time,'seed_first':str(args.seed_first) if args.seed_first else None,
            'elapsed_seconds':time.monotonic()-start,'records':e.records,'errors':errors,'drops':[]}
    import pyvista as pv
    for i,row in enumerate(e.records):
        if row['release']!='done':continue
        d=e.run/f'drop_{i+1:02d}';r=e.run/f'release_{i+1:02d}'
        entry={'drop':i+1,'direction':s.directions[i]}
        for stage,folder in [('impact',d),('stabilization',r)]:
            native=NativeRestart.read(folder/'job.rout')
            state=read_state(folder/'results/state.json')
            frames=json.loads((folder/'results/frames.json').read_text())
            # Converter manifests contain a list of filename/time records.
            record=frames[-1] if isinstance(frames,list) else frames['frames'][-1]
            filename=record.get('file') or record.get('path')
            grid=pv.read(folder/'results'/filename)
            pe=grid.point_data.get('PE')
            stress=grid.point_data.get('S Mises (MPa)')
            entry[stage]={'native_step':native.sizes['step'],'total_time':float(native.doubles('ttime')[0]),
                'coordinates_finite':bool(np.isfinite(list(state['coordinates'].values())).all()),
                'velocities_finite':bool(np.isfinite(list(state['velocities'].values())).all()),
                'max_peeq':float(np.max(pe)) if pe is not None else None,
                'max_mises_mpa':float(np.max(stress)) if stress is not None else None}
        if i:
            audit=json.loads((d/'transfer.json').read_text());entry['transfer']=audit
            source=NativeRestart.read(e.run/f'release_{i:02d}/job.rout');incoming=NativeRestart.read(d/'job.rin')
            assert source.history_hashes()==incoming.history_hashes()==audit['history_sha256']
            assert source.records[source.fields['vold']]==incoming.records[incoming.fields['vold']]
        report['drops'].append(entry)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'summary.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False),flush=True)
    return 0 if report['success'] else 1

if __name__=='__main__':raise SystemExit(main())
