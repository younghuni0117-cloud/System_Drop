"""Qt/VTK interaction smoke test, run with DISPLAY (Xvfb is sufficient)."""
from pathlib import Path
import argparse,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets,QtCore
from system_drop.viewer import Viewer
from system_drop.gui import STYLE
from system_drop.model import ROOT
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);args=p.parse_args()
errors=[]
def exception_hook(*args):
    import traceback
    errors.append(''.join(traceback.format_exception(*args)))
    sys.__excepthook__(*args)
sys.excepthook=exception_hook
app=QtWidgets.QApplication([]);app.setStyleSheet(STYLE)
v=Viewer(args.folder);v.show();v.scalar.setCurrentText('S Mises (MPa)')
results={}
for mode in ['None','Simple','Advanced']:
    v.averaging.setCurrentText(mode);app.processEvents();assert v.max_value is not None;results[mode]=v.max_value
v.lock_range.setChecked(True);v.minimum.setValue(0);v.maximum.setValue(100);v.slider.setValue(0)
assert v.minimum.value()==0 and v.maximum.value()==100
v.slider.setValue(v.slider.maximum());v.show_max.setChecked(True)
assert v.max_position is not None
logo=next(item for item in v.part_items.values() if item.text(0)=='LOGO')
body=next(item for item in v.part_items.values() if item.text(0)=='BODY')
body.setCheckState(2,QtCore.Qt.CheckState.Unchecked);assert 'LOGO' in v.max_label.text()
v.parts.setCurrentItem(logo);v.show_parts(True)
assert body.checkState(1)==QtCore.Qt.CheckState.Unchecked
v.show_parts(False);body.setCheckState(2,QtCore.Qt.CheckState.Checked)
v.play.click();assert v.timer.isActive();v.advance();v.pause.click();assert not v.timer.isActive()
v.slider.setValue(v.slider.maximum())
def finish():
    assert not errors,'\n'.join(errors)
    assert v.annotation.label.isVisible() and v.annotation.world is not None
    results.update(success=True,frames=len(v.records),parts=[i.text(0) for i in v.part_items.values()],
                   fixed_range=[v.minimum.value(),v.maximum.value()],max_position=v.max_position.tolist(),
                   playback_and_part_scope=True)
    v.grab().save(str(ROOT/'artifacts/viewer_controls_latest.png'))
    (ROOT/'artifacts/viewer_controls_latest_summary.json').write_text(json.dumps(results,indent=2));print(results)
    v.close();app.quit()
QtCore.QTimer.singleShot(400,finish);app.exec()
