"""Actual Qt/VTK rendering, native Max drag, stride and three-codec export check. Requires DISPLAY."""
import json,sys,math
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets,QtCore,QtTest
from system_drop.model import ROOT
from system_drop.viewer import Viewer
from system_drop.gui import STYLE
errors=[]
def exception_hook(*args):
 import traceback
 errors.append(''.join(traceback.format_exception(*args)));sys.__excepthook__(*args)
sys.excepthook=exception_hook
app=QtWidgets.QApplication([]);app.setStyleSheet(STYLE);v=Viewer(ROOT/'examples/three_body/drop_01');v.show();v.resize(1180,820)
v.scalar.setCurrentText('S Mises (MPa)');v.show_max.setChecked(True);counts=[]
for i in range(24):
 v.slider.setValue(i%len(v.records));v.show_max.setChecked(bool(i%2));app.processEvents();counts.append(v.plotter.renderer.GetViewProps().GetNumberOfItems())
assert max(counts)-min(counts)<=1,counts
v.show_max.setChecked(True);app.processEvents()
a=v.annotation;point=a.screen_rect.center();old=a.pos()
QtTest.QTest.mousePress(v.plotter.interactor,QtCore.Qt.MouseButton.LeftButton,QtCore.Qt.KeyboardModifier.NoModifier,point)
QtTest.QTest.mouseMove(v.plotter.interactor,point-QtCore.QPoint(60,20),30)
QtTest.QTest.mouseRelease(v.plotter.interactor,QtCore.Qt.MouseButton.LeftButton,QtCore.Qt.KeyboardModifier.NoModifier,point-QtCore.QPoint(60,20))
assert a.custom and a.pos()!=old,(a.custom,a.pos(),old)
v.set_part_color('BODY_1','#b6dbcb');v.scalar.setCurrentText('형상');assert v.part_colors['BODY_1']=='#b6dbcb'
v.frame_step.setValue(2);v.slider.setValue(0);v.advance();assert v.slider.value()==2
v.scalar.setCurrentText('S Mises (MPa)');v.lock_range.setChecked(True);v.minimum.setValue(0);v.maximum.setValue(150);v.fps.setValue(5)
suffixes=['avi','mp4','gif'];saved=[]
def export():
 assert not errors,errors
 v.begin_export(ROOT/f'artifacts/viewer_stride100.{suffixes[len(saved)]}')
def done(path):
 saved.append(path)
 if len(saved)<3:QtCore.QTimer.singleShot(0,export)
 else:
  assert not errors,errors
  report={'success':True,'formats':['avi','mp4','gif'],'source_frames':len(v.records),'frame_step':v.frame_step.value(),'exported_frames':math.ceil(len(v.records)/v.frame_step.value()),'annotation_dragged':a.custom,'actor_counts_after_24_changes':counts,'part_color':v.part_colors['BODY_1']}
  report['parts']=[i.text(0) for i in v.part_items.values()];assert set(report['parts'])=={'BODY_1','BODY_2','BODY_3'}
  (ROOT/'artifacts/viewer100_summary.json').write_text(json.dumps(report,indent=2));v.scalar.setCurrentText('형상');v.grab().save(str(ROOT/'artifacts/viewer_v100.png'));print(report,flush=True);v.close();app.quit()
def failed(text):print('MOVIE FAILED',text,flush=True);app.exit(3)
v.movie_saved.connect(done);v.movie_failed.connect(failed)
QtCore.QTimer.singleShot(300,export);QtCore.QTimer.singleShot(90000,lambda:app.exit(4));code=app.exec();assert code==0 and not errors,(code,errors)
