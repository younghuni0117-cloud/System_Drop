"""Real, intentionally very short solver checks; NOT impact validation."""
from pathlib import Path
import argparse
import json
import shutil
import sys
import tempfile
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.engine import Engine
from system_drop.model import ROOT,Settings


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--ccx",required=True,help="Path to ccx 2.23 executable")
    parser.add_argument("--keep-files",action="store_true")
    args=parser.parse_args()
    artifact=ROOT/"artifacts";artifact.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="system_drop_smoke_") as temp:
        settings=Settings(directions=[1],drop_time=1e-7,release_dt=1e-7,
                          release_max_dt=5e-7,release_time=1e-6,output_root=temp,
                          calculix_command='"'+str(Path(args.ccx).resolve())+'" -i {job}')
        messages=[]
        engine=Engine(settings,emit=lambda name,data:messages.append((name,data)))
        start=time.monotonic(); engine.execute()
        success=engine.next_stage() is None
        report={"success":success,"kind":"free-flight native restart smoke test, NOT impact validation",
                "drop_period":settings.drop_time,"release_period":settings.release_time,
                "elapsed_seconds":time.monotonic()-start,"records":engine.records,
                "errors":[data["text"] for name,data in messages if name=="error"]}
        if success:
            from system_drop.results import read_state
            d=read_state(engine.run/"drop_01/results/state.json")
            r=read_state(engine.run/"release_01/results/state.json")
            report.update(product_nodes=len(r["coordinates"]),drop_time=d["time"],release_total_time=r["time"],
                          native_restart_bytes=(engine.run/"drop_01/job.rout").stat().st_size,
                          retained_velocity_example=r["velocities"].get(1))
        (artifact/"native_smoke_summary.json").write_text(json.dumps(report,indent=2),encoding="utf-8")
        for stage in ("drop","release"):
            path=engine.run/(stage+"_01")/"solver.log" if engine.run else None
            if path and path.exists(): shutil.copy2(path,artifact/("native_"+stage+".log"))
        if args.keep_files and engine.run:
            target=artifact/"native_smoke"
            if target.exists():
                raise RuntimeError("artifacts/native_smoke already exists; move it before using --keep-files")
            shutil.copytree(engine.run,target)
        print(json.dumps(report,indent=2))
        return 0 if success else 1


if __name__=="__main__": raise SystemExit(main())
