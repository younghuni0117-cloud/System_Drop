"""Run bundled pip directly from its wheel; network is explicitly disabled."""
from pathlib import Path
import runpy,sys
root=Path(__file__).resolve().parents[1]
pip_wheel=next((root/'offline/wheels').glob('pip-*.whl'))
sys.path.insert(0,str(pip_wheel))
(root/'logs').mkdir(exist_ok=True)
sys.argv=['pip','install','--no-index','--find-links',str(root/'offline/wheels'),'--disable-pip-version-check','--no-warn-script-location','--log',str(root/'logs/offline_pip.log'),*sys.argv[1:]]
runpy.run_module('pip',run_name='__main__')
