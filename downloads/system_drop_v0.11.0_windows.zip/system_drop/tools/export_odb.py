"""Run using Abaqus Python, not the GUI interpreter.

Usage: abaqus python export_odb.py job.odb results_folder
Compatible syntax with Abaqus Python 2.7/3.x; no third-party packages.
Only flat models with unique node/element labels and C3D8/S4 are accepted.
Visualization JSON/VTU does NOT replace the native Abaqus import state files.
"""
from __future__ import print_function
import json
import math
import os
import sys
from xml.sax.saxutils import escape


def array(name,values,components=1,kind="Float64"):
    return '<DataArray type="%s" Name="%s" NumberOfComponents="%s" format="ascii">%s</DataArray>' % (
        kind,escape(name),components," ".join(str(v) for row in values for v in (row if isinstance(row,(list,tuple)) else [row])))



def value_data(value):
    try:return value.data
    except Exception:return value.dataDouble


def tensor_global(value,labels):
    components=dict(zip(labels,value_data(value)))
    t=[[float(components.get('S11',0)),float(components.get('S12',0)),float(components.get('S13',0))],
       [float(components.get('S12',0)),float(components.get('S22',0)),float(components.get('S23',0))],
       [float(components.get('S13',0)),float(components.get('S23',0)),float(components.get('S33',0))]]
    try:r=value.localCoordSystem
    except Exception:
        try:r=value.localCoordSystemDouble
        except Exception:r=None
    if r:
        # FieldValue stores the global-to-local matrix: S_global = R^T S_local R.
        t=[[sum(r[k][i]*t[k][l]*r[l][j] for k in range(3) for l in range(3))
            for j in range(3)] for i in range(3)]
    return [t[0][0],t[1][1],t[2][2],t[0][1],t[1][2],t[0][2]]

def export(odb_path,output):
    from odbAccess import openOdb
    odb=openOdb(path=os.path.abspath(odb_path),readOnly=True)
    if not os.path.isdir(output): os.makedirs(output)
    try:
        vtk_types={'C3D8':12,'C3D8R':12,'C3D4':10,'C3D6':13,'C3D10':24,'C3D20':25,'C3D20R':25,'S3':5,'S4':9,'S4R':9,'S8R':23}
        nodes={}; elements={}; keys={}; element_keys={}; parts={}
        index_path=os.path.join(output,'part_index.json')
        part_index=json.load(open(index_path)) if os.path.isfile(index_path) else None
        from abaqusConstants import INTEGRATION_POINT
        for instance in odb.rootAssembly.instances.values():
            needed=set()
            for element in instance.elements:
                if element.type not in vtk_types: continue
                if element.label in elements: raise ValueError("Duplicate element labels: use flat unique numbering")
                elements[element.label]=(element.type,list(element.connectivity))
                element_keys[(instance.name,element.label)]=element.label
                names=[] if part_index else [name for name,element_set in instance.elementSets.items() if name not in ('PRODUCT_ELEMENTS','AUTO_PRODUCT_ELEMENTS','BODY_TOP') and
                       any(item.label==element.label for item in element_set.elements)]
                parts[element.label]=(part_index['names'][part_index['elements'][str(element.label)]] if part_index else
                                      min(names,key=lambda n:(len(instance.elementSets[n].elements),n)) if names else element.type)
                needed.update(element.connectivity)
            for node in instance.nodes:
                if node.label not in needed: continue
                if node.label in nodes: raise ValueError("Duplicate node labels: use flat unique numbering")
                nodes[node.label]=list(node.coordinates)
                keys[(instance.name,node.label)]=node.label
        labels=sorted(nodes); lookup=dict((n,i) for i,n in enumerate(labels))
        elabels=sorted(elements)
        connectivity=[]; offsets=[]; types=[]
        for label in elabels:
            kind,conn=elements[label]
            connectivity.extend(lookup[n] for n in conn); offsets.append(len(connectivity)); types.append(vtk_types[kind])
        part_names=sorted(set(parts.values()))
        records=[]; final_state=None
        for step in odb.steps.values():
            for frame in step.frames:
                fields={}
                for field in ("U","V","VR"):
                    values={}
                    if field in frame.fieldOutputs:
                        for value in frame.fieldOutputs[field].values:
                            key=(value.instance.name,value.nodeLabel)
                            if key in keys: values[keys[key]]=list(value_data(value))
                    fields[field]=values
                if not all(n in fields["U"] for n in labels): continue
                coords=dict((n,[nodes[n][i]+fields["U"][n][i] for i in range(3)]) for n in labels)
                cell_fields={}
                tensors={}
                for field in ("S","PEEQ"):
                    accum={}
                    if field not in frame.fieldOutputs: continue
                    for value in frame.fieldOutputs[field].getSubset(position=INTEGRATION_POINT).values:
                        key=(value.instance.name,value.elementLabel)
                        if key not in element_keys: continue
                        if field=='S':
                            tensors.setdefault(element_keys[key],[]).append(tensor_global(value,frame.fieldOutputs[field].componentLabels))
                        scalar=float(value.mises) if field=="S" else float(value_data(value))
                        accum.setdefault(element_keys[key],[]).append(scalar)
                    cell_fields["S Mises (MPa)" if field=="S" else "PEEQ"]=[
                        sum(accum[n])/len(accum[n]) if accum.get(n) else float("nan") for n in elabels]
                if 'S' in frame.fieldOutputs:
                    peaks={}
                    for value in frame.fieldOutputs['S'].getSubset(position=INTEGRATION_POINT).values:
                        key=(value.instance.name,value.elementLabel)
                        if key in element_keys:peaks.setdefault(element_keys[key],[]).append(float(value.mises))
                    cell_fields['S IP max Mises']=[max(peaks[n]) if n in peaks else float('nan') for n in elabels]
                if tensors and all(n in tensors for n in elabels):
                    cell_fields['Stress IP mean']=[[sum(v[i] for v in tensors[n])/len(tensors[n]) for i in range(6)] for n in elabels]
                point_data=[array("Node ID",labels,kind="Int64"),array("DISP",[fields["U"][n][:3] for n in labels],3)]
                if all(n in fields["V"] for n in labels): point_data.append(array("VELO",[fields["V"][n][:3] for n in labels],3))
                cell_data=[array("Element ID",elabels,kind="Int64"),array("Part ID",[part_names.index(parts[n]) for n in elabels],kind="Int64")]+[array(k,v,6 if k=="Stress IP mean" else 1) for k,v in cell_fields.items()]
                xml='''<?xml version="1.0"?>
<VTKFile type="UnstructuredGrid" version="0.1" byte_order="LittleEndian"><UnstructuredGrid>
<Piece NumberOfPoints="%d" NumberOfCells="%d"><Points>%s</Points><Cells>%s%s%s</Cells>
<PointData>%s</PointData><CellData>%s</CellData></Piece></UnstructuredGrid></VTKFile>''' % (
                    len(labels),len(elabels),array("Points",[coords[n] for n in labels],3),
                    array("connectivity",connectivity,kind="Int64"),array("offsets",offsets,kind="Int64"),
                    array("types",types,kind="UInt8"),"".join(point_data),"".join(cell_data))
                filename="frame_%04d.vtu" % len(records)
                with open(os.path.join(output,filename),"w") as stream: stream.write(xml)
                records.append({"time":frame.frameValue,"file":filename})
                velocities={}
                for n in labels:
                    if n in fields["V"]:
                        velocities[n]=fields["V"][n][:3]+fields["VR"].get(n,fields["V"][n][3:6])
                final_state={"coordinates":coords,"velocities":velocities,"time":frame.frameValue,
                             "material_history":"native_abaqus_import_required"}
        with open(os.path.join(output,'parts.json'),'w') as stream:json.dump(part_names,stream)
        if not records: raise ValueError("No complete product displacement frames in ODB")
        for filename,data in (("frames.json",records),("state.json",final_state)):
            with open(os.path.join(output,filename),"w") as stream: json.dump(data,stream,indent=2)
        print("Exported %d frames" % len(records))
    finally:
        odb.close()


if __name__=="__main__":
    export(sys.argv[1],sys.argv[2])
