"""Generate and lint first Explicit, Standard import and next Explicit decks.
No licensed Abaqus solver is invoked. Company-side datacheck is still required.
"""
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import ROOT,Settings
from system_drop.engine import Engine
from system_drop.solver import setup_drop,prepare_release
from system_drop.deck import read_mesh
from system_drop.abaqus_audit import audit_abaqus

s=Settings(solver='abaqus',template=str(ROOT/'template_abaqus'),directions=[1,7],
           output_root=str(ROOT/'artifacts/abaqus_review_v011'))
e=Engine(s,workflow=True);e.initialize();first=setup_drop(s,e.run,0,e.log,True)
mesh=read_mesh(ROOT/'template_abaqus/abaqus_mesh.inp')
state={'coordinates':mesh.product_nodes,'velocities':{n:[0.,0.,0.,0.,0.,0.] for n in mesh.product_nodes}}
for path in (e.run/'drop_01/results',e.run/'release_01/results'):
    path.mkdir(parents=True,exist_ok=True);(path/'state.json').write_text(json.dumps(state))
release=prepare_release(s,e.run,0,e.log);second=setup_drop(s,e.run,1,e.log)
report={str(p.relative_to(e.run)):audit_abaqus(p) for p in [first/'job.inp',release/'job.inp',second/'job.inp']}
report['licensed_solver_executed']=False;report['run']=str(e.run)
(ROOT/'artifacts/abaqus_review_v011_summary.json').write_text(json.dumps(report,indent=2))
assert all(v['passed'] for v in report.values() if isinstance(v,dict))
assert report['drop_02/job.inp']['import_sets']==['BODY_1','BODY_2']
print(json.dumps(report,indent=2))
