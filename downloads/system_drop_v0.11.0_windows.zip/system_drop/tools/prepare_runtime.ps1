$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$target = Join-Path $root 'runtime\python311'
$archive = Join-Path $root 'offline\python-3.11.9-embed-amd64.zip'
Write-Host '[1/4] Bundled Windows x64 Python preparation'
try {
    $manifest = Get-Content -LiteralPath (Join-Path $root 'offline\manifest.json') -Raw | ConvertFrom-Json
    $expected = $manifest.files.'python-3.11.9-embed-amd64.zip'
    if ((Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLower() -ne $expected) { throw 'Python archive checksum mismatch. Copy the offline package again.' }
    if (!(Test-Path -LiteralPath (Join-Path $target 'python.exe'))) { Expand-Archive -LiteralPath $archive -DestinationPath $target -Force }
    New-Item -ItemType Directory -Force -Path (Join-Path $target 'Lib\site-packages') | Out-Null
    $pth = "python311.zip`r`n.`r`nLib`r`nLib/site-packages`r`n../..`r`nimport site`r`n"
    [IO.File]::WriteAllText((Join-Path $target 'python311._pth'), $pth, [Text.UTF8Encoding]::new($false))
    exit 0
} catch { Write-Host $_ -ForegroundColor Red; Write-Host 'Extract the complete offline package into a writable local folder, then retry.'; exit 1 }
