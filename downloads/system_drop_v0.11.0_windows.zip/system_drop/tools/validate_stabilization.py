"""Real Top/Bottom impact and 1 s stabilization check. Requires CCX 2.23.

Writes a new run; may take several minutes. No dependencies are installed.
"""
from pathlib import Path
import argparse,json,sys,time
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import ROOT,Settings
from system_drop.engine import Engine
from system_drop.restart import NativeRestart


def summarize(run):
    report={}
    for number in (1,2):
        folder=run/f'release_{number:02d}'
        start=json.loads((folder/'stabilization_transfer.json').read_text())
        end=json.loads((folder/'stabilization_quality.json').read_text())
        drift=float(np.linalg.norm(np.asarray(end['center'])-start['center']))
        end['mass_center_drift_mm']=drift
        assert drift<.001,f'Unexpected rigid drift: {drift} mm'
        assert end['max_nodal_speed_mm_s']<.01,'Stabilization velocity remains high'
        assert end['kinetic_after_Nmm']<max(1e-12,start['kinetic_after_Nmm']*1e-6)
        assert NativeRestart.read(folder/'job.rin').history_hashes()==start['history_sha256']
        report[f'release_{number:02d}']={'start':start,'end':end}
    np.testing.assert_array_equal(NativeRestart.read(run/'drop_02/job.rin').doubles('xmodal')[:2],
                                  NativeRestart.read(run/'drop_01/job.rout').doubles('xmodal')[:2])
    return report


def main():
    p=argparse.ArgumentParser();p.add_argument('--ccx',required=True);args=p.parse_args()
    settings=Settings(directions=[1,2],scenario='Custom',cpus=1,
        output_root=str(ROOT/'artifacts/stabilization_full080'),calculix_path=str(Path(args.ccx).resolve()))
    engine=Engine(settings,emit=lambda name,data:print(name,data,flush=True) if name in ('status','error') else None)
    start=time.monotonic();engine.execute()
    report={'success':engine.next_stage() is None,'run':str(engine.run),'records':engine.records,
            'elapsed_seconds':time.monotonic()-start,
            'settings':{'drop':settings.drop_time,'release':settings.release_time,'damping':settings.release_damping}}
    if report['success']:report.update(summarize(engine.run))
    (ROOT/'artifacts/stabilization_full080_summary.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2));return 0 if report['success'] else 1


if __name__=='__main__':raise SystemExit(main())
