"""Qt/VTK timeline, annotation and AVI integration check; run with DISPLAY.
Uses the bundled read-only example and writes evidence in artifacts.
"""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets,QtCore,QtTest
from system_drop.viewer import Viewer
from system_drop.model import ROOT
from system_drop.gui import STYLE
errors=[]
def on_error(*args):
 import traceback
 errors.append(''.join(traceback.format_exception(*args)));sys.__excepthook__(*args)
sys.excepthook=on_error
app=QtWidgets.QApplication([]);app.setStyleSheet(STYLE)
v=Viewer(ROOT/'examples/three_body/drop_01');v.show();v.resize(1180,820)
v.scalar.setCurrentText('S Mises (MPa)');v.view_mode.setCurrentIndex(1);v.release_guide.setChecked(True);v.show_max.setChecked(True)
v.lock_range.setChecked(True);v.minimum.setValue(0);v.maximum.setValue(200)
for number,item in v.part_items.items():v.opacity_controls[number].setValue(45 if item.text(0).startswith('BODY') else 95)
v.fps.setValue(5)
def export():
 assert not errors,errors
 label=v.plotter.interactor;old=v.annotation.pos();point=v.annotation.screen_rect.center()
 QtTest.QTest.mousePress(label,QtCore.Qt.MouseButton.LeftButton,QtCore.Qt.KeyboardModifier.NoModifier,point)
 QtTest.QTest.mouseMove(label,point-QtCore.QPoint(42,-30),10)
 QtTest.QTest.mouseRelease(label,QtCore.Qt.MouseButton.LeftButton,QtCore.Qt.KeyboardModifier.NoModifier,point)
 assert v.annotation.custom and v.annotation.pos()!=old
 v.grab().save(str(ROOT/'artifacts/viewer_sequence_latest.png'))
 v.begin_export(ROOT/'artifacts/sequence_demo_latest.avi')
def saved(path):
 assert not errors,errors
 report={'success':True,'stages':len(v.stages),'frames':len(v.records),'transitions':sum(r['kind']=='transition' for r in v.records),
         'floor_fixed':True,'part_opacity':{i.text(0):v.opacity_controls[n].value() for n,i in v.part_items.items()},'annotation_dragged':v.annotation.label.custom,'video':path}
 (ROOT/'artifacts/viewer_sequence_latest_summary.json').write_text(json.dumps(report,indent=2));print(report,flush=True);v.close();app.quit()
v.movie_saved.connect(saved);v.movie_failed.connect(lambda text:(_ for _ in ()).throw(AssertionError(text)))
QtCore.QTimer.singleShot(400,export);QtCore.QTimer.singleShot(90000,lambda:app.exit(2));code=app.exec()
assert code==0 and not errors,(code,errors)
