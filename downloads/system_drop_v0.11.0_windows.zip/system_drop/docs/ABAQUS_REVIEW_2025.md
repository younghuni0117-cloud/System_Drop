# Abaqus 2025 입력 규칙 검토

검토 대상: flat C3D8/S4 모델의 첫 Explicit → 별도 Standard 안정화 → 다음 Explicit.
공개된 SIMULIA 2025 문서의 키워드 규칙을 대조했습니다. Abaqus 설치/라이선스가 없어
실제 `datacheck` 또는 해석을 수행한 것은 아닙니다. 따라서 아래 정적 점검을 실행 검증과 구분합니다.

## 찾아서 반영한 수정

1. **Explicit CONTACT PAIR 위치**: 기존 model-level 정의를 DROP step의 DYNAMIC 뒤로 이동.
   상호작용 물성은 모델 데이터로 유지합니다.
   [CONTACT PAIR](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-contactpair.htm)
2. **Import 요소 집합**: Solid/Shell을 섞은 AUTO_PRODUCT_ELEMENTS를 import 목록으로 사용하지 않고,
   section 집합 BODY/LOGO를 각각 import합니다. 추가 section 집합도 목록에 반영합니다.
   [Explicit–Standard 전달의 요소 호환 표](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEANLRefMap/simaanl-c-exptostd.htm)
3. **Shell tie**: Abaqus 템플릿의 로고 결합면을 element-based `LOGO, SNEG`로 정의.
   로고 midsurface Y=8.1, 두께 0.2이므로 안쪽 면 Y=8.0이 body top에 놓입니다.
   양 솔버 단계에서 일관된 `TYPE=SURFACE TO SURFACE` tie를 재정의합니다.
   [Mesh Tie Constraints](https://docs.software.vt.edu/abaqusv2025/English/SIMACAECSTRefMap/simacst-c-tiedconstraint.htm)
4. **속도 전달**: Standard 안정화 시작에 제품 V와 S4의 VR을 명시합니다.
   S4 VR이 누락되면 조용히 버리지 않고 오류로 알립니다. 다음 낙하의 회전 초기속도는 0으로 지정합니다.
   [INITIAL CONDITIONS](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-initialconditions.htm)
5. **native 원본 지정**: 사용자 실행 명령에서 `{oldjob}`를 생략해도 Import 작업에는 oldjob 인수를 보완합니다.
   [IMPORT](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-import.htm)
6. **ODB 후처리**: nodal U/V/VR과 integration-point S/PEEQ의 위치를 구분합니다.
   텐서 성분 순서를 통일하고 shell local tensor를 global로 회전한 뒤 표시 평균에 사용합니다.
   [FieldValue 방향 코사인](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKERRefMap/simaker-c-fieldvaluecpp.htm)

## 적합성을 확인한 항목

- C3D8와 S4는 2025 Explicit/Standard 사이의 지원 요소 표에 포함됩니다.
  [2025 지원 요소](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEANLRefMap/simaanl-c-exptostd.htm)
- Explicit 자동 증분 행은 `, period, , max_dt`. 첫째/셋째 칸을 비워 둡니다.
  Standard 안정화는 `APPLICATION=QUASI-STATIC`, 초기/총/최소/최대 증분 네 값을 사용합니다.
  [DYNAMIC](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-dynamic.htm)
- Import는 model data이며 `UPDATE=YES, STATE=YES`로 형상과 재료 이력을 가져옵니다.
  section/material은 다시 정의하지 않고 named sets/surfaces/tie만 필요한 만큼 재구성합니다.
- 낙하 바닥 R3D4 및 ref node를 재생성하고 ref DOF 1–6을 고정합니다.
  안정화에는 바닥 요소/접촉/중력을 넣지 않으며 첫 Standard import step의 MODEL CHANGE를 사용하지 않습니다.
- 초기 Explicit에는 interval restart, Standard에는 frequency restart를 기록합니다.
  [전달에 필요한 파일](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEANLRefMap/simaanl-c-transferoverview.htm)

`tools/review_abaqus.py`가 세 단계 입력을 생성하고 범위가 한정된 정적 규칙 검사 결과를 저장합니다.
샘플은 `examples/abaqus_review`에 포함했습니다. 실행 전에도 같은 검사를 수행합니다.
이 검사기는 Abaqus 전체 문법/요소 기능을 대체하는 parser가 아닙니다.

## 회사 PC에서 남은 확인

템플릿 폴더에서 설치된 명령에 맞춰 다음처럼 첫 모델의 datacheck를 수행하세요.

```bat
abaqus job=check_drop input=abaqus_main.inp datacheck interactive
```

Import 단계는 실제 이전 해석의 native 파일이 있어야 datacheck할 수 있습니다.
동일 Abaqus release 및 binary-compatible 환경에서 모든 관련 파일을 보존하세요.
다른 회사 버전은 해당 버전 문서/실행으로 확인해야 합니다.
Tie 조정, shell 두께/offset, 접촉 초기 관입 및 단계 전환 전후 응력·PEEQ·속도 연속성은
실제 `.dat/.msg/.sta/ODB`로 확인해야 합니다. 물성/접촉의 수치적 정확성은 정적 키워드 점검으로 보증되지 않습니다.
