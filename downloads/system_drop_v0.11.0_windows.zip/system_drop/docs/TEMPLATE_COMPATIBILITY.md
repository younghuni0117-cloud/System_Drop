# Abaqus 입력 호환성과 역할 매핑

세 파일은 `abaqus_main.inp`, `abaqus_material.inp`, `abaqus_mesh.inp`입니다.
원본 INP를 편집하지 않고 `template_snapshot` 작업 사본을 만듭니다.
이미 AUTO 계약이 있는 템플릿은 그대로 사용합니다. 없는 경우 식별 가능한 낙하 단계와
바닥/속도/중력 영역을 작업 사본에 구성합니다.

## 새로 지원하는 구성

- 키워드 대소문자, 주석, 키워드/요소 연결 행 이어쓰기, GENERATE/참조 집합
- 따옴표·쉼표 포함 INCLUDE, 중첩/외부 INCLUDE의 동결 복사와 순환 검출
- 일반적인 meshed PART/INSTANCE의 병진·축 회전 배치를 flat 작업 사본으로 변환
- 재료 원본과 전역 미지 키워드 보존, section/tie 중복 추가 방지
- 사용자 접촉 이름/표면 물성, 기본 general contact 구성 보존
- Explicit의 general contact와 Standard의 model-data 속성 할당 위치 구분
- 바닥 접촉 제거와 자유체 안정화, 다음 Explicit의 접촉 재생성

**상세 옵션 → Abaqus 템플릿 검사 / 매핑**에서 기준점 NSET 세 개, 제품/바닥 surface,
바닥 집합과 낙하 STEP을 연결합니다. `template_profile.json`에 저장합니다.
PART 안의 집합은 `INSTANCE.SET` 형태로 지정할 수 있습니다.
검사는 별도 임시 사본에서 이루어지며 솔버를 실행하지 않습니다.
`template_adaptation.json`, `template_check.json`에 변환 내용과 제한을 기록합니다.

## 지원 경계

모든 Abaqus 키워드의 임의 조합을 자동 호환한다고 보장하지 않습니다.
단독 낙하 입력이 유효한지와 Explicit↔Standard Import가 가능한지는 별개의 문제입니다.
현재 누적 안정화 질량 계산은 **C3D8/C3D8R/C3D4/S3/S4/S4R, 상수 밀도**를 지원합니다.
추가 요소 형식은 형상 판독/뷰어 지원과 실제 누적 Import 지원 범위가 다를 수 있습니다.

아래 조건은 임의로 생략하지 않고 실행 전에 전용 설정이 필요하다고 알립니다.

- PART 안의 미지원 지역 좌표/특수 속성 카드, orphan instance
- 선행 해석의 이력을 요구하는 STEP, composite shell, 온도 의존 밀도
- 제품의 특수 RIGID BODY, COUPLING/EQUATION/MPC/CONNECTOR/TRANSFORM
- 추가 제품 구속, GRAV 이외 하중, 열 하중, mass scaling의 반복 전달
- 복수/혼합 contact pair 또는 전용 접촉 제어

General contact는 CONTACT/INCLUSIONS/EXCLUSIONS/PROPERTY ASSIGNMENT의 기본 구성을 다룹니다.
Standard에서는 속성 할당을 model data에 두고, 물리 바닥 참조를 제거합니다.
복잡한 접촉/사용자 재료/시간 의존 물성은 회사 Abaqus에서 Import 호환 검토가 필요합니다.
검사 통과는 Abaqus 라이선스 실행 검증이 아니며 회사 버전에서 datacheck를 수행하세요.

참조: [CONTACT](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-contact.htm),
[CONTACT PROPERTY ASSIGNMENT](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-contactpropertyassignment.htm),
[IMPORT](https://docs.software.vt.edu/abaqusv2025/English/SIMACAEKEYRefMap/simakey-r-import.htm).

자동화가 맡는 영역은 바닥 배치, 제품 초기속도/중력, 시간·출력, 안정화 연결입니다.
재료를 다른 물성으로 바꾸거나 미지원 조건을 몰래 삭제하지 않습니다.
