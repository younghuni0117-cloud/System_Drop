# v0.6.0

- 템플릿 및 자동 생성 job 입력에 `**====` / 번호 구획 / 세 줄 `**` 형식 적용.
- mesh/material include, section, tie, contact, boundary, 초기조건, step을 구분.
  native restart/import 입력은 필요한 정의만 기록하며 inherited section/tie를 중복 생성하지 않음.
- 제품 C3D8 12×8×2 → 24×16×4: 192 → 1536개.
- 로고 30×20 → 150×100 mm(각 변 5배), S4 2×2 → 12×8: 4 → 96개.
- 바닥 번호를 제품 번호보다 크게 생성해 세분화 모델과 충돌하지 않도록 수정.
- PyVista에 평균화, 범위 고정, 파트별 표시/컨투어, 재생/멈춤, Max 위치, 보기/마우스 모드 추가.
- 새 CalculiX 결과에 요소 IP 응력을 보존. IP 최대 Mises도 별도로 제공.
- Abaqus 2025 공식 문서 대조 후 Explicit contact 위치, import 집합, tie 및 VR 전달 등 보완.
- 자세한 뷰어 계산 방식은 VIEWER_v060.md, Abaqus 정적 검토는 ABAQUS_REVIEW_2025.md 참고.

검증: 새 메쉬 두 방향의 짧은 실제 solver 연결 및 1 us 초기 충돌 + 1초 안정화,
Qt/VTK 조작 확인. 새 모델의 전체 18회 충돌 응답을 끝까지 평가한 시험은 아닙니다.
기존 실행은 자신의 template_snapshot을 계속 사용하며 새 템플릿 메쉬는 새 실행에 적용됩니다.
