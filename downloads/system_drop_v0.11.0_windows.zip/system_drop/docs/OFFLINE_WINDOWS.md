# Windows 오프라인 실행

**인터넷 없는 PC에는 `_windows_offline.zip`을 가져가세요.** 일반 ZIP에는 대용량 wheel/Python이 없습니다.
지원 대상은 Windows 10/11 64비트입니다. Linux/ARM/32비트용 설치 파일이 아닙니다.

1. 오프라인 ZIP 전체를 USB 등으로 옮겨 **쓰기 가능한 로컬 폴더**에 압축 해제합니다.
2. `start_windows.bat` 실행. Python을 별도로 설치하지 않아도 동봉 Python 3.11.9를 사용합니다.
3. 기존 호환 환경이 있으면 재사용합니다. 없으면 동봉 wheel만 사용해 전용 환경에 설치합니다.
4. 무결성/설치/실제 import 검사가 끝나면 Manager가 열립니다.

회사 PC의 시스템 Python이나 Abaqus Python을 변경하지 않습니다.
프로그램을 EXE로 빌드한 것이 아니라 Python/BAT 소스와 원본 Python 실행 환경을 동봉한 것입니다.
Manager 런타임과 CalculiX는 포함되지만 Abaqus 실행에는 회사 설치본과 라이선스가 필요합니다.

## 설치가 멈추거나 실패하면

콘솔 안내에서 R은 재시도, V는 동봉 Microsoft VC++ x64 런타임 설치, Q는 종료입니다.
VC++ 설치 시 Windows 관리자 승인 창이 나올 수 있습니다.
`logs/offline_setup_error.txt`, `logs/offline_pip.log`를 확인합니다.
복사 누락/손상은 파일명과 함께 표시합니다. 누락된 파일을 인터넷에서 받으려 하지 않습니다.
완료된 라이브러리는 강제 재설치하지 않습니다.

`install_windows.bat`로 설치/검사만 먼저 할 수 있습니다.
Python 자체 실행이 실패하면 압축을 완전히 풀었는지, Windows x64인지 확인하세요.
`runtime/python311`이 손상되면 해당 전용 폴더만 별도 보관한 후 동봉 Python ZIP에서 복구할 수 있습니다.
관리 정책으로 실행이 차단되면 회사 IT의 허용이 필요하며 보안 정책을 변경하지 않습니다.

## 동봉 내용

- 원본 Windows CPython 3.11.9 + 복구용 embeddable ZIP / PSF LICENSE
- CPython 3.11 x64용 wheel 전체 의존성: NumPy, PySide6/Essentials/Addons, VTK,
  PyVista, PyVistaQt, Matplotlib, Pillow 및 하위 의존성
- wheel에서 실행하는 pip, Microsoft 공식 VC++ Redistributable x64
- `offline/manifest.json`: 버전·SHA-256 목록

설치는 `--no-index --find-links`로 수행합니다. 외부 패키지 서버로 대체하지 않습니다.
최초 설치 뒤에는 전용 환경을 재사용합니다. 업데이트 때 프로그램 폴더를 별도로 풀어도
완전한 기존 환경을 탐색하여 불필요한 재설치를 줄입니다.

패키지 라이선스는 각 wheel 내부 `.dist-info`와 설치 후 `Lib/site-packages`의 라이선스 파일에 있습니다.
원본 배포 경로는 manifest 및 `offline/THIRD_PARTY.md`를 참고하세요.

## 검사 범위

Windows wheel의 오프라인 의존성 해석, SHA-256, Python x64 아키텍처,
Python 3.11 소스 문법, 누락/손상/재시도/설치 생략 경로를 검사했습니다.
이 개발 환경은 Linux이므로 실제 오프라인 Windows 기기에서 설치를 완료한 검증은 아닙니다.
