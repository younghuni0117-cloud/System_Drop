# 검증 범위와 후속 작업

## 환경

개발: Linux, Python 3.12, PySide6 6.12, PyVista 0.49.2, VTK 9.3.1.
Windows용 실행 스크립트와 명령 경로를 제공하지만 Windows 실기기에서 확인하지는 않았습니다.
Abaqus 실행 파일·라이선스·실제 ODB는 제공되지 않았습니다.

## 수행한 검증

- 18개 방향의 단위벡터, 바닥 수직성, 30도 Edge, 직사각형 대각선 Corner.
- 제품 강체 회전·이동 후 FRAME 좌표계 갱신.
- 초기 간격 변화와 목표 충돌 에너지 일치.
- 템플릿 읽기, section/tie/접촉 중복 방지, 재료 파일 보존.
- Custom 중복 방향 순서, 체크포인트, 단계별 수동 실행, 일시정지·재개.
- 실패 시 다음 단계 미실행, 실행 폴더 충돌 방지, 명령 인수의 공백 경로.
- Qt GUI의 Solver 전환, 시나리오 순서와 버튼 활성화.
- 실제 Qt GUI에서 18방향 워크플로 테스트를 끝까지 실행했고,
  진행 중 연 별도 PyVista 창이 계속 열린 상태에서 다음 해석 단계가 진행되는 것을 확인했습니다.
- CalculiX 2.23에서 18방향 모두 1e-9초 자유비행 입력 검사를 통과했습니다.
  이는 방향별 키워드/메쉬/접촉 정의의 초기 구동 검사이며 충돌 검증이 아닙니다.
- CalculiX 2.23의 C3D8/S4/tie/강체 바닥 예제로 1e-7초 Explicit → 1e-6초 Implicit native restart 연결.
  원래 제품 노드 360개의 결과를 읽고 VTU로 변환했습니다.
  이 짧은 시험은 바닥 충돌 이전이며 실제 충돌/소성 응답 검증이 아닙니다.

증거: `artifacts/gui_v040.png`, `artifacts/native_smoke_summary.json`,
`artifacts/calculix_directions.json`, `artifacts/test_report_v040.txt`, `examples/top_face_impact/summary.json`.
v0.2 GUI의 실제 Solver 연결 기록은 `artifacts/gui_native_v020_summary.json`,
시퀀스 체크 기록은 `artifacts/gui_check_v020_summary.json`에 있습니다.
해당 파일은 검증 도구를 실행하면 생성/갱신합니다.

v0.2에서는 패키지가 모두 있는 경우 pip를 호출하지 않는 것, 이전 환경 재사용,
Custom 횟수/행별 편집, 작은 화면의 가로 스크롤 없음, 실행 파일 자동 탐색 및 누락 안내,
재실행 시 Solver 경로 보존을 추가 검사했습니다.

v0.3에서는 Windows x64 바이너리와 필요한 DLL, 원본 파일 SHA-256을 검사했습니다.
확보한 배포본 자체를 패키지에 포함했으며, Windows 실기기에서의 실행 검증은 아직 없습니다.
이 Linux 환경의 Wine 보조 검사는 Wine 초기화 중 kernel32/user32 로딩 문제로 진행되지 않았습니다.
따라서 Windows 바이너리가 실행 검증까지 통과했다고 주장하지 않습니다.
GUI의 작은 방향 모식도, 직접 솔버 경로, 초기/최대 증분 반영, Abaqus 자동 증분의 네 번째 필드를 추가 검사했습니다.

v0.4는 원래 C3D8+S4/tie 모델로 실제 Top Face 충돌 0.000060초와 1초 안정화를 완료했습니다.
변형·소성·반발과 마지막 응력값의 안정성이 관측되었습니다.
단계 버튼 진행률/애니메이션/시간 저장, 고정 바닥 모식도, 18행 표시, 실제 결과의 유한값도 검사합니다.
자세한 조건과 수치는 `IMPACT_VALIDATION_v040.md`에 있습니다.

## 추가 평가가 필요한 범위

1. 실제 충돌, 접촉 에너지, 재료 소성 이력의 정확성 및 릴리즈 안정화 기준.
2. CalculiX 누적 연결은 v0.5에 구현했습니다. 18방향 짧은 실제 연결과 소성 상태에서
   다음 충돌을 실행하는 시험의 범위·수치는 `CUMULATIVE_v050.md`와 동봉 JSON을 참고하세요.
3. 회사 Abaqus 버전에서 C3D8/S4 Explicit 지원, Import·tie·접촉 재정의, V/VR 전달,
   restart 파일 호환성 및 ODB 추출 확인.
4. Windows cmd/bat 실행·즉시 프로세스 트리 종료·Abaqus Viewer의 실제 구동.

## 공식 참고 문서

- [Abaqus Explicit–Standard 상태 전달](https://docs.software.vt.edu/abaqusv2026/English/SIMACAEANLRefMap/simaanl-c-exptostd.htm)
- [Abaqus Implicit Dynamic](https://docs.software.vt.edu/abaqusv2026/English/SIMACAEANLRefMap/simaanl-c-dynamic.htm)
- [CalculiX DYNAMIC](https://feacluster.com/CalculiX/ccx_2.18/doc/ccx/node259.html)
- [CalculiX RESTART](https://feacluster.com/CalculiX/ccx_2.18/doc/ccx/node318.html)
- [CalculiX MODEL CHANGE](https://www.feacluster.com/CalculiX/ccx_2.18/doc/ccx/node299.html)
- [CalculiX 초기조건 구현](https://github.com/Dhondtguido/CalculiX/blob/master/src/initialconditionss.f)
