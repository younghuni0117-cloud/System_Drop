# Aluminum / Plastic 두 파트 누적 예제

상세 옵션의 `2파트 Al/Plastic` 검증 예제에서 엽니다.
BODY_1은 Aluminum, BODY_2는 일반 Plastic 예시 물성입니다.
C3D8 384개, 585노드, 두 파트의 117개 경계 노드를 공유합니다. 로고/Shell/Tie는 없습니다.
각 파트는 두께 방향 2층입니다. 재료별 탄소성 곡선은 템플릿 material.inp에 있습니다.

실제 Linux CalculiX 2.23에서 Top Face 낙하 0.00006 s → 안정화 1 s →
Bottom Face 낙하 → 안정화를 계산했습니다. 읽기 전용 예제에는 일부 저장 프레임만 포함합니다.
이 예제는 해석/GUI 개발용 블록이며 실제 노트북 물성의 검증 결과가 아닙니다.
