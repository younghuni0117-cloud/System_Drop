# 새 메쉬 실제 결과 예제

- BODY 1536 C3D8, LOGO 96 S4 / 150×100 mm.
- `impact`: 1 us의 초기 충돌 5프레임. 새 GLOBAL=YES 요소 응력 출력 포함.
- `stabilization`: 앞 초기 충돌을 잇는 1초 안정화의 마지막 결과.
  이 과거 검증 출력은 local IP 텐서였으므로 텐서 평균 필드를 제외하고 원본 FRD 및
  회전 불변인 `S IP max Mises`를 제공합니다.
- `global_basis_validation.json`: GLOBAL 출력으로 1 us 낙하 + 1 us 안정화를 다시 확인한 기록.
  출력 좌표계 변경 전후의 native 재료 상태 해시가 정확히 일치합니다.

전체 낙하 충돌 응답 평가가 아니라 뷰어/초기 충돌 및 안정화 검증 데이터입니다.
Linux CalculiX 2.23 실제 결과이며 GUI 흐름용 가상 응력이 아닙니다.
본문 `docs/VIEWER_v060.md`에 평균화의 정의와 한계를 설명했습니다.
