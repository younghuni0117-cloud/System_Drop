# 완료된 실제 Top Face 시험

Linux CalculiX 2.23으로 계산한 예제입니다. GUI 순서 점검용 가상 결과가 아닙니다.

- `drop/results`: 실제 드랍 51개 프레임, 0.000060초까지 충돌·반발·소성변형 확인.
- `stabilization/results`: 1초 안정화 시험의 마지막 프레임.
- `summary.json`: 완료 증분, 실행 시간, 응력·소성변형 및 마지막 구간 안정성 관측.
- 각 단계 `solver.log`: 원본 실행 로그. `job.inp`: 사용한 입력.

상세 옵션의 **검증 예제 결과 보기**에서 열 수 있습니다. 창에 검증 예제임을 표시합니다.
이 자료는 결과 미리보기용이며, 사용자 실행의 native 재시작 상태를 대신하지 않습니다.
조건과 한계: `docs/IMPACT_VALIDATION_v040.md`.
