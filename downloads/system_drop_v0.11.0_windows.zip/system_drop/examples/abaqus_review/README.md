# Abaqus 2025 정적 검토 입력

`drop_01/job.inp`: 첫 Explicit. 같은 폴더에 mesh/material include가 있습니다.
`release_01/job.inp`: Standard native import 안정화.
`drop_02/job.inp`: 다음 Explicit native import.

공식 키워드 규칙을 대조해 생성하고 제한된 정적 검사에 통과했습니다.
실제 Abaqus solver/datacheck는 실행하지 않았습니다. 변형/속도 JSON은 입력 생성용 기준 상태입니다.
Import 입력을 실행하려면 실제 이전 job의 native 파일과 `oldjob=...`가 필요합니다.
이 예제의 정적 검토 보고서는 `docs/ABAQUS_REVIEW_2025.md`에 있습니다.
