"""User-visible preflight and role mapping for imported Abaqus templates."""
from pathlib import Path
import json,tempfile
from PySide6 import QtWidgets as W
from .template_adapter import ROLES,read_profile,blocks,card
from .deck import expanded_lines,keyword


class TemplateDialog(W.QDialog):
    def __init__(self,parent,folder):
        super().__init__(parent);self.folder=Path(folder);self.setWindowTitle('Abaqus 템플릿 검사 / 역할 매핑');self.resize(740,620)
        layout=W.QVBoxLayout(self)
        note=W.QLabel('원본 INP는 수정하지 않습니다. 바닥·제품 접촉면·기준 NSET 이름을 연결하면 작업 사본에 적용합니다.\n일반적인 meshed PART/INSTANCE는 전역 flat 작업 사본으로 변환합니다. 미지원 조건은 실행 전에 알려줍니다.');note.setWordWrap(True);layout.addWidget(note)
        form=W.QFormLayout();layout.addLayout(form);self.fields={};choices=set();steps=[];self.current=read_profile(folder)
        try:
            part=None;parts={};instances=[]
            for b in blocks(expanded_lines(folder/'abaqus_main.inp')):
                c=card(b);p=keyword(b[0])[1] if c else {}
                if c=='*PART':part=str(p['NAME']).upper();parts[part]=[]
                elif c=='*END PART':part=None
                elif c=='*INSTANCE':instances.append((str(p.get('NAME','')),str(p.get('PART','')).upper()))
                if c in ('*NSET','*ELSET','*SURFACE'):
                    name=str(p.get('NSET',p.get('ELSET',p.get('NAME',''))));choices.add(name)
                    if part:parts[part].append(name)
                if c=='*STEP':steps.append(str(p.get('NAME','')))
            for instance,part in instances:
                for name in parts.get(part,[]):choices.add(instance+'.'+name)
        except Exception:pass
        labels={'frame_origin':'기준 원점 NSET','frame_x':'기준 X NSET','frame_y':'기준 Y NSET','floor_surface':'바닥 SURFACE','floor_elements':'바닥 ELSET','floor_nodes':'바닥 NSET','floor_ref':'바닥 기준 NSET','floor_rot':'바닥 회전 NSET','product_surface':'제품 접촉 SURFACE'}
        for key,canonical in ROLES.items():
            combo=W.QComboBox();combo.setEditable(True);combo.addItems(sorted(choices));combo.setCurrentText(str(self.current.get(key,canonical)));form.addRow(labels[key],combo);self.fields[key]=combo
        self.step=W.QComboBox();self.step.setEditable(True);self.step.addItem('');self.step.addItems(steps);self.step.setCurrentText(self.current.get('drop_step',''));form.addRow('낙하 STEP (빈값=첫 Explicit)',self.step)
        self.report=W.QPlainTextEdit();self.report.setReadOnly(True);layout.addWidget(self.report,1)
        buttons=W.QHBoxLayout();layout.addLayout(buttons)
        save=W.QPushButton('매핑 저장');check=W.QPushButton('작업 사본 검사');close=W.QPushButton('닫기')
        for button in (save,check,close):buttons.addWidget(button)
        save.clicked.connect(self.save);check.clicked.connect(self.check);close.clicked.connect(self.accept)
    def values(self):
        result={key:combo.currentText().strip() for key,combo in self.fields.items()}
        if self.step.currentText().strip():result['drop_step']=self.step.currentText().strip()
        return result
    def save(self):
        try:
            (self.folder/'template_profile.json').write_text(json.dumps(self.values(),indent=2,ensure_ascii=False),encoding='utf-8')
            self.report.setPlainText('template_profile.json에 저장했습니다. 원본 INP는 유지했습니다.')
        except Exception as exc:self.report.setPlainText(str(exc))
    def check(self):
        from .model import Settings
        from .solver import snapshot_template
        from .template_adapter import validate_contract
        import shutil
        try:
            with tempfile.TemporaryDirectory(prefix='drop_template_') as temp:
                temp=Path(temp);source=temp/'source';shutil.copytree(self.folder,source)
                (source/'template_profile.json').write_text(json.dumps(self.values()),encoding='utf-8')
                run=temp/'run';run.mkdir();path=snapshot_template(Settings(solver='abaqus',template=str(source)),run)
                result=validate_contract(path,'abaqus');result['adaptation']=json.loads((path/'template_adaptation.json').read_text())
                self.report.setPlainText(json.dumps(result,ensure_ascii=False,indent=2)+'\n\nAbaqus 실행 검증은 아닙니다. 회사 PC에서 datacheck를 수행하세요.')
        except Exception as exc:self.report.setPlainText('검사 실패 — 솔버는 실행하지 않았습니다.\n'+str(exc))
