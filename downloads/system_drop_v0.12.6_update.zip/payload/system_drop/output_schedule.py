"""Time-based result output, independent of solver integration increments."""
from decimal import Decimal,ROUND_CEILING
import re

NAME='AUTO_DROP_TIMES'


def decimal_text(value):
    text=format(Decimal(str(value)),'f')
    return text.rstrip('0').rstrip('.') if '.' in text else text


def frame_count(period,interval):
    if interval<=0:return None
    return int((Decimal(str(period))/Decimal(str(interval))).to_integral_value(rounding=ROUND_CEILING))


def times(period,interval):
    count=frame_count(period,interval)
    if count is None:return []
    if count>100000:raise ValueError('예상 Frame이 100000개를 초과합니다. 최대 증분/출력 간격을 늘리세요.')
    end=Decimal(str(period));dt=Decimal(str(interval))
    return [min(i*dt,end) for i in range(1,count+1)]


def configure_output(text,solver,period,interval,define=True):
    if interval<=0:return text
    if solver=='abaqus':
        from .deck import logical_lines,keyword,tokens
        lines=[];found=set()
        for line in logical_lines(text.splitlines()):
            if line.strip().startswith('*') and not line.strip().startswith('**'):
                name,params=keyword(line)
                mode=next((m for m in ('FIELD','HISTORY') if m in params),None)
                if name=='*OUTPUT' and mode:
                    found.add(mode)
                    kept=[t for t in tokens(line)[1:] if ' '.join(t.split('=')[0].upper().split()) not in
                          ('FREQUENCY','NUMBER INTERVAL','TIME INTERVAL','TIME POINTS','TIMEPOINTS')]
                    line='*OUTPUT, '+', '.join(kept+['TIME INTERVAL='+decimal_text(interval)])
            lines.append(line)
        additions=[]
        if 'FIELD' not in found:additions.extend(['*OUTPUT, FIELD, TIME INTERVAL='+decimal_text(interval),'*NODE OUTPUT','U, V, UR, VR','*ELEMENT OUTPUT','S, PE, PEEQ'])
        if 'HISTORY' not in found:additions.extend(['*OUTPUT, HISTORY, TIME INTERVAL='+decimal_text(interval),'*ENERGY OUTPUT','ALLKE, ALLIE, ALLAE'])
        if additions:
            end=next((i for i,l in enumerate(lines) if l.strip().upper()=='*END STEP'),len(lines))
            lines[end:end]=additions
        return '\n'.join(lines)+'\n'
    # CCX 2.23 EXPLICIT=2 bypasses TIME POINTS output filtering. Preserve
    # every solved frame, then select actual frames against target times.
    def replace(match):
        tokens=[t.strip() for t in match[0].split(',')]
        tokens=[t for t in tokens if t.upper().split('=')[0].strip() not in ('FREQUENCY','TIME POINTS','TIMEPOINTS')]
        return ', '.join(tokens+['FREQUENCY=1'])
    text=re.sub(r'(?mi)^\*(?:NODE FILE|EL FILE|NODE PRINT|EL PRINT)\b[^\n]*',replace,text)
    values=times(period,interval)
    note=f'** SYSTEM_DROP_OUTPUT_INTERVAL={decimal_text(interval)}; TARGET_FRAMES={len(values)}\n'
    text=re.sub(r'(?mi)^\*\* SYSTEM_DROP_OUTPUT_INTERVAL=.*\n?','',text)
    return note+text


def select_frame_indices(actual_times,period,interval,offset=0.):
    import numpy as np
    targets=np.asarray([float(t)+offset for t in times(period,interval)])
    actual=np.asarray(actual_times,dtype=float)
    if np.any(np.diff(actual)<0):raise ValueError('결과 프레임 시간이 역순입니다.')
    tolerance=max(1e-12,abs(offset+period)*1e-12)
    indices=np.searchsorted(actual,targets-tolerance)
    if len(indices):indices[-1]=len(actual)-1
    # Late cumulative FRD/DAT headers round different increments to the same
    # printed time. Keep real frames and printed times; never invent precision.
    if len(actual)>=len(targets) and len(set(indices))!=len(targets):
        indices=np.ceil(np.arange(1,len(targets)+1)*len(actual)/len(targets)).astype(int)-1
    if (len(set(indices))!=len(targets) or np.any(indices>=len(actual))
        or (len(targets) and actual[-1]<targets[-1]-tolerance)):
        raise ValueError('목표 프레임을 구성할 실제 결과가 부족합니다. 원본 출력 간격과 해석 완료 시간을 확인하세요.')
    return indices.tolist(),targets.tolist()


def reconcile_frame_times(reported_times,significant_digits=6,offset=None,end_time=None):
    """Bound printed timestamp uncertainty without sorting physical frames.

    DAT has 7 significant digits; FRD has 6. A native endpoint can be below
    the last rounded header. Each correction must stay inside its header's
    rounding interval. A genuine time reversal still fails closed.
    """
    import numpy as np
    reported=np.asarray(reported_times,dtype=float)
    if reported.ndim!=1 or not len(reported) or not np.isfinite(reported).all():
        raise ValueError('결과 프레임 시간에 비유한 값 또는 빈 배열이 있습니다.')
    digits=np.broadcast_to(np.asarray(significant_digits,dtype=int),reported.shape)
    if np.any(digits<1):raise ValueError('시간 표기 유효 자릿수가 올바르지 않습니다.')
    magnitude=np.maximum(np.abs(reported),0.000000000001)
    quantum=10.**(np.floor(np.log10(magnitude))-digits+1)
    slack=16*np.spacing(np.maximum(magnitude,1.))
    tolerance=.51*quantum+slack
    lower=reported-tolerance;upper=reported+tolerance
    if offset is not None:
        if not np.isfinite(offset):raise ValueError('시작 native 시간이 유한하지 않습니다.')
        lower=np.maximum(lower,offset)
    if end_time is not None:
        if not np.isfinite(end_time):raise ValueError('종료 native 시간이 유한하지 않습니다.')
        if offset is not None and end_time<=offset:raise ValueError('Native 시작/종료 시간 범위가 잘못됐습니다.')
        if abs(reported[-1]-end_time)>tolerance[-1]:
            raise ValueError('최종 결과 시간과 native 종료 시간이 출력 반올림 범위를 초과해 다릅니다.')
        upper=np.minimum(upper,end_time)
        lower[-1]=upper[-1]=end_time
    # Backward caps avoid choosing an earlier, coarsely rounded header above
    # a later, more precise timestamp. Frame arrays are never reordered.
    caps=np.minimum.accumulate(upper[::-1])[::-1]
    if np.any(lower>caps):
        index=int(np.flatnonzero(lower>caps)[0])
        raise ValueError(f'결과 프레임 시간이 실제로 역행하거나 native 범위를 벗어납니다 (frame {index+1}).')
    corrected=np.maximum.accumulate(np.minimum(np.maximum(reported,lower),caps))
    if np.any(corrected>caps+slack):raise ValueError('결과 프레임의 시간 순서를 반올림 범위에서 복원할 수 없습니다.')
    changed=np.flatnonzero(corrected!=reported)
    audit={'method':'Monotone time labels within printed rounding intervals; native endpoint verified; physical frame order unchanged.',
           'corrected_frames':len(changed),'max_correction_s':float(np.max(np.abs(corrected-reported))),
           'native_start_time':offset,'native_end_time':end_time,
           'significant_digits':sorted(set(map(int,digits)))}
    return corrected.tolist(),audit
