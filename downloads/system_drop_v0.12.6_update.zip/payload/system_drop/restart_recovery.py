"""Recover only the known Windows OVERLAY rename failure after a full snapshot.

'Job finished' alone is insufficient. Native step/time/schema, finite physical
and material state, current inputs and the upstream restart must all match.
No error text is deleted; the verified recovery is recorded separately.
"""
from pathlib import Path
import json,re,shutil,math
import numpy as np
from .restart import NativeRestart
from .deck import read_mesh


def overlay_rename_error(text):
    errors=re.findall(r'(?im)^\s*\*ERROR[^\r\n]*',text)
    return (bool(errors) and all(e.strip().lower()=='*error in restartwrite:' for e in errors)
            and 'temporaryrestartfile cannot be renamed' in ' '.join(text.lower().split())
            and 'job finished' in text.lower()
            and not any(s in text.upper() for s in ('ANALYSIS HAS NOT BEEN COMPLETED','EXITED WITH AN ERROR')))


def without_overlay(text):
    lines=[]
    for line in text.splitlines(keepends=True):
        if re.match(r'^\s*\*RESTART\s*,',line,re.I) and re.search(r'\bWRITE\b',line,re.I):
            ending='\r\n' if line.endswith('\r\n') else '\n' if line.endswith('\n') else ''
            line=', '.join(t.strip() for t in line.strip().split(',') if t.strip().upper().split('=')[0]!='OVERLAY')+ending
        lines.append(line)
    return ''.join(lines)


def dynamic_period(path):
    active=False
    for line in Path(path).read_text(encoding='utf-8-sig').splitlines():
        line=line.strip()
        if not line or line.startswith('**'):continue
        if line.startswith('*'):active=line.upper().split(',')[0]=='*DYNAMIC';continue
        if active:
            value=float(line.split(',')[1])
            if not math.isfinite(value) or value<=0:raise ValueError('Invalid dynamic period')
            return value
    raise ValueError('DYNAMIC period missing')


def recover_overlay_error(folder,upstream=None):
    from .solver_cache import digest,inputs,fingerprints
    folder=Path(folder);log=folder/'solver.log'
    if not log.exists() or not overlay_rename_error(log.read_text(errors='replace')):return None
    audit_path=folder/'restart_recovery.json'
    report={'recovered':False,'reason':'No complete final native snapshot verified.','candidates':[]}
    try:
        if not (folder/'job.frd').is_file():raise ValueError('FRD missing')
        paths=inputs(folder)
        if not (folder/'job.inp').is_file() or not paths:raise ValueError('Input missing')
        latest=max(p.stat().st_mtime_ns for p in paths)
        if log.stat().st_mtime_ns<latest:raise ValueError('Inputs changed after solver completion')
        incoming=folder/'job.rin'
        before=NativeRestart.read(incoming) if incoming.exists() else None
        if upstream:
            upstream=Path(upstream)
            if not upstream.is_file():raise ValueError('Upstream native restart missing')
            if folder.name.startswith('release_'):
                if digest(upstream)!=digest(incoming):
                    from .stabilization import release_matches_upstream
                    if not release_matches_upstream(upstream,incoming,folder):raise ValueError('Upstream state changed')
            else:
                transfer=json.loads((folder/'transfer.json').read_text())
                actual=NativeRestart.read(upstream)
                if transfer.get('source_file_sha256'):
                    if transfer['source_file_sha256']!=digest(upstream):raise ValueError('Upstream state changed')
                elif actual.history_hashes()!=transfer['history_sha256'] or not np.array_equal(actual.doubles('vold'),before.doubles('vold')):
                    raise ValueError('Upstream native history/displacement changed')
        period=dynamic_period(folder/'job.inp')
        base=float(before.doubles('ttime')[0]) if before else 0.
        target=base+period;step=(before.sizes['step'] if before else 0)+1
        mesh_path=folder/'calculix_mesh.inp'
        if not mesh_path.exists():mesh_path=folder.parent/'template_snapshot/calculix_mesh.inp'
        mesh=read_mesh(mesh_path)
        for candidate in (folder/'job.rout',folder/'temporaryrestartfile'):
            if not candidate.is_file():continue
            try:
                native=NativeRestart.read(candidate)
                actual=float(native.doubles('ttime')[0])
                if native.sizes['step']!=step or abs(actual-target)>max(1e-13,abs(target)*1e-12,period*1e-7):
                    raise ValueError(f'Incomplete/stale step/time: {native.sizes["step"]}/{actual:.16g}; expected {step}/{target:.16g}')
                native.product_labels(mesh)
                for key in ('co','vold','veold','sti','eme','xstate'):
                    if key in native.fields and not np.isfinite(native.doubles(key)).all():raise ValueError(f'Nonfinite {key}')
                target_path=folder/'job.rout'
                source_sha=digest(candidate)
                if candidate!=target_path:
                    if target_path.exists():shutil.copy2(target_path,folder/'job.rout.before_recovery')
                    pending=folder/'job.rout.recovered.partial';shutil.copyfile(candidate,pending)
                    if digest(pending)!=source_sha:raise ValueError('Recovery copy digest mismatch')
                    pending.replace(target_path)
                report.update(recovered=True,reason='Complete final native snapshot verified; original log retained.',
                              source=candidate.name,step=step,total_time=actual,expected_total_time=target,
                              native_sha256=source_sha,history_sha256=native.history_hashes(),
                              inputs=fingerprints(folder,paths))
                break
            except (ValueError,OSError,KeyError) as exc:
                report['candidates'].append({'file':candidate.name,'error':str(exc)})
    except (ValueError,OSError,KeyError,IndexError) as exc:report['reason']=str(exc)
    audit_path.write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report if report['recovered'] else None
