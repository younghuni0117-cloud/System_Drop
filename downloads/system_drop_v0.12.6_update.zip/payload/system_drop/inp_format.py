"""Comment-only INP layout; solver keyword/data order is never changed."""
import re
BORDER='**'+'='*81

def heading(label):return f'{BORDER}\n** {label}\n{BORDER}'

def format_inp(text,title='00SYSTEM_DROP'):
    lines=text.splitlines();out=[heading(title)];section=None;previous_card=None
    names={'*INCLUDE':'01 MODEL: replace mesh/material includes, retain AUTO markers.',
           '*SOLID SECTION':'03 SECTIONS','*SHELL SECTION':'03 SECTIONS','*TIE':'04 TIE',
           '*SURFACE INTERACTION':'05 CONTACT PROPERTIES','*BOUNDARY':'06 BOUNDARY CONDITIONS',
           '*INITIAL CONDITIONS':'07 INITIAL CONDITIONS','*RESTART':'01 NATIVE STATE / RESTART',
           '*IMPORT':'01 NATIVE STATE / IMPORT'}
    managed={'FLOOR':'02 FLOOR GEOMETRY (AUTO)','VELOCITY':'07 INITIAL CONDITIONS (AUTO)','DROP_STEP':'08 DROP ANALYSIS (AUTO)'}
    inside=False;in_step=False
    for line in lines:
        stripped=line.strip()
        if not stripped:continue
        if re.match(r'^\*\*\s*[=\-]{5,}',stripped):continue
        if re.match(r'^\*\*\s*\d{2}(?:\s|SYSTEM_DROP)',stripped):continue
        label=None
        marker=re.match(r'^\*\* AUTO:BEGIN (\w+)',stripped)
        if marker:label=managed.get(marker[1]);inside=True
        if stripped.upper().startswith('*STEP') and not stripped.startswith('**'):
            in_step=True
            if not inside:label='08 ANALYSIS STEP'
        if stripped.startswith('*') and not stripped.startswith('**'):
            card=stripped.split(',')[0].upper()
            if not inside and not in_step and card in names:label=names[card]
            if card=='*HEADING':label=None
            if label is None and previous_card!=card and out and not out[-1].startswith('**'):
                out.append('**')
            previous_card=card
        if label and label!=section:
            if len(out)>1:out.extend(['**','**','**'])
            out.append(heading(label));section=label
        out.append(line.rstrip())
        if stripped.startswith('** AUTO:END '):inside=False
        if stripped.upper()=='*END STEP':in_step=False
    return re.sub(r'(?m)(?:^\*\*\n){4,}', '**\n**\n**\n', '\n'.join(out)+'\n')
