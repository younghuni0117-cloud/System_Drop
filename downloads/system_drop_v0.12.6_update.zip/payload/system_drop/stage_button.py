"""Clickable progress buttons; animation does not invent solver progress."""
import math
from PySide6 import QtCore,QtGui,QtWidgets


def duration_text(seconds):
    if seconds is None:return '시간 없음'
    if seconds>=3600:value,unit=seconds/3600,'h'
    elif seconds>=60:value,unit=seconds/60,'min'
    else:value,unit=seconds,'s'
    digits=2 if 0<value<1 else 1
    return f'{value:.{digits}f}'.rstrip('0').rstrip('.')+unit


def percent_text(percent):
    if 0<percent<1:return f'{percent:.3f}'.rstrip('0').rstrip('.')
    if 99.5<=percent<100:return f'{percent:.1f}'
    return f'{percent:.0f}'


class StageButton(QtWidgets.QPushButton):
    def __init__(self,parent=None):
        super().__init__('대기',parent)
        self.status='pending';self.percent=0.;self.phase=0.
        self.setMinimumHeight(18);self.setMouseTracking(True)
        self.timer=QtCore.QTimer(self);self.timer.setInterval(70);self.timer.timeout.connect(self.animate)

    def animate(self):
        self.phase+=.23;self.update()

    def set_stage(self,status,percent=0,elapsed=None,ready=False):
        self.status=status;self.percent=max(0.,min(100.,percent))
        labels={'pending':'실행' if ready else '대기','failed':'실패 · 재시도','interrupted':'중지 · 재시도'}
        if status=='running':text=f'해석 중({percent_text(self.percent)}%)'
        elif status=='processing':text=f'결과 변환({percent_text(self.percent)}%)'
        elif status=='done':text=f'완료({duration_text(elapsed)})'
        else:text=labels.get(status,status)
        self.setText(text)
        if status in ('running','processing'):
            if not self.timer.isActive():self.timer.start()
            self.setToolTip('파일 검사 바이트 수와 프레임 저장 수에 따른 변환 진행률입니다. 최종 검증 뒤 완료됩니다.' if status=='processing' else '퍼센트는 솔버가 보고한 실제 해석 시간 기준입니다. 물결은 실행 상태를 나타내며 남은 시간의 예측값이 아닙니다.')
        else:
            self.timer.stop()
            if status=='done':self.setToolTip('클릭하면 결과를 새 창으로 엽니다. 표시 시간은 이 단계의 실행·파일 처리에 걸린 실제 시간입니다.')
        self.update()

    def paintEvent(self,event):
        p=QtGui.QPainter(self);p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        rect=QtCore.QRectF(self.rect()).adjusted(.5,.5,-.5,-.5)
        colors={'done':'#dceee4','running':'#f0f7fc','processing':'#f0f7fc','failed':'#f9e4e4','interrupted':'#fff0d5'}
        background=QtGui.QColor(colors.get(self.status,'#ffffff' if self.isEnabled() else '#f3f6fa'))
        if self.isDown():background=background.darker(105)
        p.setPen(QtGui.QPen(QtGui.QColor('#c6d3e0'),1));p.setBrush(background);p.drawRoundedRect(rect,2,2)
        if self.status in ('running','processing') and self.percent>0:
            p.save();clip=QtGui.QPainterPath();clip.addRoundedRect(rect,2,2);p.setClipPath(clip)
            width=self.width()*self.percent/100
            wave=QtGui.QPainterPath();wave.moveTo(0,0);wave.lineTo(width,0)
            for y in range(self.height()+1):
                wave.lineTo(max(0,width+math.sin(self.phase+y*.28)*1.8),y)
            wave.lineTo(0,self.height());wave.closeSubpath()
            p.fillPath(wave,QtGui.QColor('#aad4ed'))
            p.setPen(QtGui.QPen(QtGui.QColor(255,255,255,105),1))
            for x in range(-30,self.width()+30,17):
                xx=x+(self.phase*6)%17
                if xx<width:p.drawLine(QtCore.QPointF(xx,self.height()),QtCore.QPointF(min(width,xx+12),0))
            p.restore()
        elif self.status in ('running','processing'):
            # Activity-only ripple at 0%; keep the progress area empty until an
            # actual solver time is observed.
            ripple=QtGui.QPainterPath();ripple.moveTo(1,self.height()-2)
            for x in range(1,self.width()):ripple.lineTo(x,self.height()-2+math.sin(self.phase+x*.14)*.8)
            p.setPen(QtGui.QPen(QtGui.QColor('#87b9da'),1));p.drawPath(ripple)
        p.setPen(QtGui.QColor('#294960' if self.isEnabled() or self.status in ('running','processing') else '#98a5b4'))
        p.setFont(self.font());p.drawText(self.rect(),QtCore.Qt.AlignmentFlag.AlignCenter,self.text())
        if self.hasFocus():
            p.setPen(QtGui.QPen(QtGui.QColor('#558fb8'),1,QtCore.Qt.PenStyle.DotLine));p.setBrush(QtCore.Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(rect.adjusted(2,2,-2,-2),2,2)
