"""Checked working-copy adaptation for marker-free Abaqus decks.

Source inputs are never edited. Unknown global/material keywords survive.
Only identified floor, launch velocity, gravity and selected step are managed.
"""
from pathlib import Path
import json,re
import numpy as np
from .deck import keyword,tokens,expanded_lines,include_path,logical_lines,mesh_from_lines,id_lines
from .assembly import blocks,card,data,flatten_assembly

ROLES={'frame_origin':'FRAME_ORIGIN','frame_x':'FRAME_X','frame_y':'FRAME_Y',
       'floor_surface':'FLOOR_SURFACE','floor_elements':'FLOOR_ELEMENTS','floor_nodes':'FLOOR_NODES',
       'floor_ref':'FLOOR_REF','floor_rot':'FLOOR_ROT','product_surface':'PRODUCT_CONTACT'}
GEOMETRY={'*NODE','*ELEMENT','*NSET','*ELSET','*SURFACE'}


def read_profile(folder):
    path=Path(folder)/'template_profile.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}


def replace_names(lines,aliases):
    result=[];current=''
    def replace(value):
        for old,new in sorted(aliases.items(),key=lambda p:-len(p[0])):
            if old.upper()!=new:value=re.sub(r'(?i)(?<![\w.-])'+re.escape(old)+r'(?![\w.-])',new,value)
        return value
    references={'*NSET','*ELSET','*SURFACE','*TIE','*CONTACT PAIR','*CONTACT INCLUSIONS','*CONTACT EXCLUSIONS','*BOUNDARY','*DLOAD','*INITIAL CONDITIONS'}
    for line in lines:
        if line.lstrip().startswith('**'):result.append(line);continue
        if line.lstrip().startswith('*'):
            current=keyword(line)[0];fields=tokens(line);changed=False
            for i,field in enumerate(fields[1:],1):
                if '=' not in field:continue
                key,value=field.split('=',1);name=' '.join(key.upper().split())
                if name in ('NSET','ELSET','SURFACE','REF NODE','ANALYTICAL SURFACE') or name=='NAME' and current=='*SURFACE':
                    converted=replace(value)
                    if converted!=value:fields[i]=key+'='+converted;changed=True
            result.append(', '.join(fields) if changed else line)
        else:result.append(replace(line) if current in references else line)
    return result


def include_graph(path,chain=()):
    path=Path(path).resolve()
    if path in chain:raise ValueError('순환 INCLUDE: '+str(path))
    yield path
    for line in logical_lines(path.read_text(encoding='utf-8-sig').splitlines()):
        if line.strip().upper().startswith('*INCLUDE,'):
            yield from include_graph(include_path(path.parent,str(keyword(line)[1]['INPUT'])),(*chain,path))


def expand_excluding(path,excluded,chain=()):
    path=Path(path).resolve()
    if path in chain:raise ValueError('순환 INCLUDE: '+str(path))
    if path in excluded:return
    for line in logical_lines(path.read_text(encoding='utf-8-sig').splitlines()):
        if line.strip().upper().startswith('*INCLUDE,'):
            yield from expand_excluding(include_path(path.parent,str(keyword(line)[1]['INPUT'])),excluded,(*chain,path))
        else:yield line


def dynamic_data_index(lines):
    start=next(i for i,line in enumerate(lines) if line.strip().upper().startswith('*DYNAMIC'))
    index=next(i for i in range(start+1,len(lines)) if lines[i].strip() and not lines[i].lstrip().startswith('**'))
    if lines[index].lstrip().startswith('*'):raise ValueError('DYNAMIC 시간 데이터 행이 없습니다.')
    return index


def set_dynamic_times(text,value,solver=None):
    lines=list(logical_lines(text.splitlines()));index=dynamic_data_index(lines)
    if solver=='abaqus':
        start=next(i for i,l in enumerate(lines) if l.strip().upper().startswith('*DYNAMIC'))
        _,params=keyword(lines[start])
        if 'EXPLICIT' not in params:raise ValueError('낙하 Step은 DYNAMIC, EXPLICIT이어야 합니다.')
        fixed=any(p in params for p in ('DIRECT USER CONTROL','FIXED TIME INCREMENTATION'))
        kept=[t for t in tokens(lines[start])[1:] if ' '.join(t.split('=')[0].upper().split()) not in ('DIRECT USER CONTROL','FIXED TIME INCREMENTATION')]
        lines[start]='*DYNAMIC, '+', '.join(kept)
        previous=lines[index].split(',');updated=value.split(',')
        if not fixed and len(previous)>2 and previous[2].strip():updated[2]=' '+previous[2].strip()
        value=','.join(updated)
    lines[index]=value
    return '\n'.join(lines)+'\n'


def adapt_abaqus(folder):
    folder=Path(folder);main=folder/'abaqus_main.inp';profile=read_profile(folder)
    text=main.read_text(encoding='utf-8-sig')
    has_markers=all(f'** AUTO:BEGIN {role}' in text for role in ('FLOOR','VELOCITY','DROP_STEP'))
    # Already contracted examples need no reconstruction or material rewriting.
    if has_markers and not profile:return {'adapted':False,'reason':'Existing AUTO contract retained.'}
    excluded=set(include_graph(folder/'abaqus_material.inp'))
    lines=[line for line in expand_excluding(main,excluded) if not line.strip().startswith('** AUTO:')];report={'adapted':True,'warnings':[],'profile':profile}
    aliases={str(profile[k]).upper():v for k,v in ROLES.items() if profile.get(k) and '.' not in str(profile[k])}
    lines=replace_names(lines,aliases)
    if any(card(b) in ('*PART','*ASSEMBLY') for b in blocks(lines)):
        lines,mapping=flatten_assembly(lines,True);report['assembly']=mapping
        extra={}
        for role,canonical in ROLES.items():
            value=str(profile.get(role,canonical)).upper()
            if '.' in value:
                inst,local=value.split('.',1)
                value=mapping['instances'].get(inst,{}).get('names',{}).get(local,value)
            candidates=[]
            for b in blocks(lines):
                if card(b) in ('*NSET','*ELSET','*SURFACE'):
                    params=keyword(b[0])[1];name=str(params.get('NSET',params.get('ELSET',params.get('NAME','')))).upper()
                    if name==value or name.endswith('__'+value):candidates.append(name)
            if canonical not in candidates and len(set(candidates))==1:extra[candidates[0]]=canonical
        lines=replace_names(lines,extra)
    parts=blocks(lines);step_starts=[i for i,b in enumerate(parts) if card(b)=='*STEP']
    if not step_starts:raise ValueError('Abaqus 템플릿에 STEP이 없습니다.')
    chosen=profile.get('drop_step');selected=None
    candidates=0
    for position in step_starts:
        end_position=next((j for j in range(position+1,len(parts)) if card(parts[j])=='*END STEP'),len(parts))
        if any(card(b)=='*DYNAMIC' and 'EXPLICIT' in keyword(b[0])[1] for b in parts[position:end_position]):candidates+=1
    if candidates>1 and not chosen:raise ValueError('Explicit Step이 여러 개입니다. template_profile.json의 drop_step으로 낙하 Step을 지정하세요.')
    for start in step_starts:
        name=str(keyword(parts[start][0])[1].get('NAME','')).upper()
        end=next((i for i in range(start+1,len(parts)) if card(parts[i])=='*END STEP'),None)
        if end is None:raise ValueError('END STEP 누락: '+name)
        explicit=any(card(b)=='*DYNAMIC' and 'EXPLICIT' in keyword(b[0])[1] for b in parts[start:end])
        if explicit and (not chosen or name==str(chosen).upper()):selected=(start,end);break
    if selected is None:raise ValueError('선택 가능한 DYNAMIC, EXPLICIT 단계가 없습니다. drop_step 매핑을 확인하세요.')
    start,end=selected
    if start!=step_starts[0]:raise ValueError('낙하 전 선행 STEP의 이력은 자동 생략할 수 없습니다. 초기 상태 Import/Restart 모델로 준비하세요.')
    if len(step_starts)>1:report['warnings'].append('선택한 낙하 이후 기존 STEP은 사용하지 않습니다. 안정화는 Manager가 별도 생성합니다.')
    model=parts[:start];step=parts[start:end+1]
    mesh=mesh_from_lines([line for b in model for line in b],False)
    floor_e=set(mesh.elsets.get('FLOOR_ELEMENTS',[]));floor_n=set(mesh.nsets.get('FLOOR_NODES',[]))
    for e in floor_e:floor_n.update(mesh.elements[e][1])
    for n in ('FLOOR_REF','FLOOR_ROT'):floor_n.update(mesh.nsets.get(n,[]))
    product={e:v for e,v in mesh.elements.items() if e not in floor_e};product_nodes={n for _,conn in product.values() for n in conn}
    if not product:raise ValueError('바닥 제외 후 제품 요소가 없습니다.')
    if floor_n&product_nodes:raise ValueError('바닥과 제품 노드가 공유되어 있습니다. floor_* 매핑을 확인하세요.')
    mesh_lines=[];main_lines=[];surfaces=set();has_contact=False;has_general=any(card(b)=='*CONTACT' for b in step)
    for b in model:
        c=card(b);params=keyword(b[0])[1] if c else {}
        if c in ('*HEADING','*INCLUDE'):continue
        if c=='*INITIAL CONDITIONS' and str(params.get('TYPE','')).upper()=='VELOCITY':continue
        if c=='*RIGID BODY':
            values={str(v).upper() for v in params.values()}
            if values&{'FLOOR_ELEMENTS','FLOOR_REF','FLOOR_SURFACE'} or str(params.get('REF NODE','')).isdigit() and int(params['REF NODE']) in floor_n:continue
        if c in ('*SOLID SECTION','*SHELL SECTION') and str(params.get('ELSET','')).upper()=='FLOOR_ELEMENTS':continue
        if c=='*SURFACE' and str(params.get('NAME','')).upper()=='FLOOR_SURFACE':continue
        if c in ('*NSET','*ELSET'):
            name=str(params.get('NSET',params.get('ELSET',''))).upper()
            if name in ('FLOOR_NODES','FLOOR_REF','FLOOR_ROT','FLOOR_ELEMENTS'):continue
            ids=mesh.nsets[name] if c=='*NSET' else mesh.elsets[name];remove=floor_n if c=='*NSET' else floor_e
            ids=[v for v in ids if v not in remove]
            if ids:mesh_lines.extend([c+', '+c.lstrip('*')+'='+name,id_lines(ids)])
            continue
        if c=='*NODE':
            rows=[row for row in data(b) if int(tokens(row)[0]) not in floor_n]
            if rows:mesh_lines.extend([b[0],*rows])
            continue
        if c=='*ELEMENT':
            # Connectivity continuation is normalized from the parsed mesh.
            group=str(params.get('ELSET','')).upper();kind=str(params['TYPE']).upper()
            ids=[e for e,(k,_) in product.items() if k==kind and (not group or mesh.element_groups.get(e)==group)]
            # Each source block can share a type/group; emit once below instead.
            continue
        if c=='*BOUNDARY':
            rows=[row for row in data(b) if tokens(row)[0].upper() not in ('FLOOR_NODES','FLOOR_REF','FLOOR_ROT') and not(tokens(row)[0].isdigit() and int(tokens(row)[0]) in floor_n)]
            if rows:main_lines.extend([b[0],*rows])
            continue
        if c=='*SURFACE':surfaces.add(str(params['NAME']).upper())
        if c=='*CONTACT PAIR':has_contact=True
        if c=='*CONTACT':has_general=True
        (mesh_lines if c in GEOMETRY else main_lines).extend(b)
    from collections import defaultdict
    grouped=defaultdict(list)
    for e,(kind,conn) in product.items():grouped[(kind,mesh.element_groups.get(e))].append((e,conn))
    element_lines=[]
    for (kind,group),items in grouped.items():
        element_lines.append('*ELEMENT, TYPE='+kind+(', ELSET='+group if group else ''))
        element_lines.extend(str(e)+', '+', '.join(map(str,conn)) for e,conn in items)
    geometry_blocks=blocks(mesh_lines)
    mesh_lines=[line for b in geometry_blocks if card(b)=='*NODE' for line in b]+element_lines+[line for b in geometry_blocks if card(b)!='*NODE' for line in b]
    for role in ('FRAME_ORIGIN','FRAME_X','FRAME_Y'):
        if len(mesh.nsets.get(role,[]))!=1:raise ValueError(role+'에 제품 노드 하나인 NSET을 지정하세요. 상세 옵션의 템플릿 매핑에서 이름을 연결할 수 있습니다.')
    if 'PRODUCT_CONTACT' not in surfaces and not has_general:
        raise ValueError('제품 접촉 SURFACE를 찾지 못했습니다. template_profile.json의 product_surface 또는 상세 옵션 매핑에서 선택하세요.')
    # A robust complete-product aggregate, independent of the user's set names.
    mesh_lines.extend(['*ELSET, ELSET=PRODUCT_ELEMENTS',id_lines(product), '*NSET, NSET=PRODUCT_NODES',id_lines(product_nodes)])
    dynamic=False;step_lines=[];gravity_removed=0
    for b in step:
        c=card(b)
        if c=='*CONTACT PAIR':has_contact=True
        if c=='*CONTACT':has_general=True
        if c=='*DLOAD':
            rows=[]
            for row in data(b):
                if len(tokens(row))>1 and tokens(row)[1].upper()=='GRAV':gravity_removed+=1
                else:rows.append(row)
            if rows:step_lines.extend([b[0],*rows])
        elif c=='*END STEP':
            step_lines.extend(['*DLOAD','PRODUCT_ELEMENTS, GRAV, 9810., 0., 1., 0.',
                               '*OUTPUT, FIELD, NUMBER INTERVAL=20','*NODE OUTPUT','U, V, UR, VR','*ELEMENT OUTPUT','S, PE, PEEQ',*b])
        else:step_lines.extend(b)
    if not has_contact and not has_general:
        report['warnings'].append('기존 접촉이 없어 마찰 0의 기본 접촉을 추가했습니다.')
        main_lines.extend(['*SURFACE INTERACTION, NAME=FLOOR_CONTACT','*SURFACE BEHAVIOR, PRESSURE-OVERCLOSURE=HARD','*FRICTION','0.'])
        pos=dynamic_data_index(step_lines)+1
        step_lines[pos:pos]=['*CONTACT PAIR, INTERACTION=FLOOR_CONTACT, MECHANICAL CONSTRAINT=PENALTY','PRODUCT_CONTACT, FLOOR_SURFACE']
    # Explicit CONTACT PAIR is step data, even if an imported deck placed it in model data.
    rebuilt=[];pairs=[];general=[]
    for b in blocks(main_lines):
        if card(b)=='*CONTACT PAIR':pairs.extend(b)
        elif card(b) in ('*CONTACT','*CONTACT INCLUSIONS','*CONTACT EXCLUSIONS','*CONTACT PROPERTY ASSIGNMENT'):general.extend(b)
        else:rebuilt.extend(b)
    main_lines=rebuilt
    if pairs or general:
        pos=dynamic_data_index(step_lines)+1
        step_lines[pos:pos]=pairs+general
    from .floor import floor_text
    from .model import floor_geometry
    from .inp_format import format_inp
    coords=np.array([mesh.nodes[n] for n in sorted(product_nodes)])
    floor=floor_geometry(coords,[0,1,0],1.)
    text='*HEADING\nSystem Drop | adapted Abaqus template\n*INCLUDE, INPUT=abaqus_material.inp\n*INCLUDE, INPUT=abaqus_mesh.inp\n'
    text+='** AUTO:BEGIN FLOOR\n'+floor_text('abaqus',floor,max(max(mesh.nodes),max(mesh.elements))+100)+'\n** AUTO:END FLOOR\n'
    text+='\n'.join(main_lines)+'\n*BOUNDARY\nFLOOR_REF, 1, 6\n'
    text+='** AUTO:BEGIN VELOCITY\n*INITIAL CONDITIONS, TYPE=VELOCITY\nPRODUCT_NODES, 1, 0.\nPRODUCT_NODES, 2, 4427.188724\nPRODUCT_NODES, 3, 0.\n** AUTO:END VELOCITY\n'
    text+='** AUTO:BEGIN DROP_STEP\n'+'\n'.join(step_lines)+'\n** AUTO:END DROP_STEP\n'
    (folder/'abaqus_mesh.inp').write_text(format_inp('\n'.join(mesh_lines)+'\n','00SYSTEM_DROP ADAPTED MESH'),encoding='utf-8')
    main.write_text(format_inp(text),encoding='utf-8')
    report.update(product_elements=len(product),product_nodes=len(product_nodes),gravity_rows_replaced=gravity_removed)
    (folder/'template_adaptation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return report


def validate_contract(folder,solver):
    from .deck import read_mesh
    folder=Path(folder);main=folder/f'{solver}_main.inp';mesh=read_mesh(main)
    if solver=='calculix':
        types=sorted({kind for kind,_ in mesh.product_elements.values()}-{'C3D8','S4'})
        if types:raise ValueError('CalculiX 누적 native 연결은 C3D8/S4만 검증됐습니다: '+', '.join(types))
    else:
        from .stabilization import template_masses
        template_masses(mesh,main)
        all_blocks=blocks(expanded_lines(main))
        pairs=[b for b in all_blocks if card(b)=='*CONTACT PAIR']
        generals=[b for b in all_blocks if card(b)=='*CONTACT']
        if not (len(pairs)==1 and not generals or not pairs and len(generals)==1):raise ValueError('바닥 CONTACT PAIR 1개 또는 GENERAL CONTACT 1개를 사용하세요. 복수/혼합 접촉은 전용 Import 검토가 필요합니다.')
        if pairs and (len(data(pairs[0]))!=1 or not any('FLOOR_SURFACE' in row.upper() for row in data(pairs[0]))):raise ValueError('바닥 CONTACT PAIR의 단일 데이터 행 및 floor_surface 매핑을 확인하세요.')
        basic={'*CONTACT','*CONTACT PAIR','*CONTACT INCLUSIONS','*CONTACT EXCLUSIONS','*CONTACT PROPERTY ASSIGNMENT','*CONTACT OUTPUT'}
        extra={card(b) for b in all_blocks if card(b).startswith('*CONTACT') and card(b) not in basic}
        if extra:raise ValueError('전용 접촉 제어의 Standard/Explicit 호환 검토가 필요합니다: '+', '.join(sorted(extra)))
        for b in all_blocks:
            c=card(b)
            if c=='*RIGID BODY':
                params=keyword(b[0])[1];allowed={str(n) for n in mesh.nsets.get('FLOOR_REF',[])}|{'FLOOR_REF'}
                if str(params.get('ELSET','')).upper()!='FLOOR_ELEMENTS' and str(params.get('REF NODE','')).upper() not in allowed:
                    raise ValueError('제품 내부 RIGID BODY의 반복 Import는 전용 설정이 필요합니다.')
            if c=='*BOUNDARY':
                floor_labels={str(n) for name in ('FLOOR_NODES','FLOOR_REF','FLOOR_ROT') for n in mesh.nsets.get(name,[])}|{'FLOOR_NODES','FLOOR_REF','FLOOR_ROT'}
                if any(tokens(row)[0].upper() not in floor_labels for row in data(b)):
                    raise ValueError('제품 구속 BOUNDARY의 안정화/다음 낙하 전달은 전용 설정이 필요합니다. 현재 자동 안정화는 자유체입니다.')
            if c in ('*CLOAD','*FILM','*RADIATE','*DFLUX','*DSFLUX','*TEMPERATURE','*FIXED MASS SCALING','*VARIABLE MASS SCALING'):
                raise ValueError(c+'의 누적 단계 전달은 전용 설정이 필요합니다. 현재 자동 낙하 계약은 중력/초기속도 기반입니다.')
            if c=='*DLOAD' and any(len(tokens(row))>1 and tokens(row)[1].upper()!='GRAV' for row in data(b)):
                raise ValueError('GRAV 이외 DLOAD의 반복 전달은 전용 설정이 필요합니다.')
            if c in ('*EQUATION','*COUPLING','*KINEMATIC','*DISTRIBUTING','*MPC','*CONNECTOR SECTION','*TRANSFORM'):
                raise ValueError(c+'의 누적 Import 전달은 아직 지원하지 않습니다. 회사 Abaqus용 Import 스크립트를 확장해야 합니다.')
    return {'solver':solver,'product_elements':len(mesh.product_elements),'product_nodes':len(mesh.product_nodes),
            'element_types':sorted({kind for kind,_ in mesh.product_elements.values()}),'checked':'geometry, frame, include graph, cumulative mass/Import contract; not a solver datacheck'}
