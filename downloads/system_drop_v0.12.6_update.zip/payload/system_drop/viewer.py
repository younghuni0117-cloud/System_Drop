"""Independent PyVista result viewer; never blocks the solver queue."""
from __future__ import annotations
from pathlib import Path
import argparse,json,sys
from collections import OrderedDict
import numpy as np
from PySide6 import QtCore,QtWidgets,QtGui
from .parts import ensure_parts
from .contours import contour_grid,STRESS_FIELDS,is_stress_field,result_label,result_unit
from .output_schedule import decimal_text
from .timeline import collect_stages,build_records,record_key,run_root,display_transform,floor_basis,center,read_json
from .annotation import MaxAnnotation


class Viewer(QtWidgets.QMainWindow):
    movie_saved=QtCore.Signal(str)
    movie_failed=QtCore.Signal(str)
    def __init__(self,folder,setup=False,workflow=False,example=False):
        super().__init__()
        import pyvista as pv
        from pyvistaqt import QtInteractor
        self.pv=pv;self.folder=Path(folder);self.setup=setup;self.workflow=workflow;self.example=example
        self._drawing=False;self.part_colors={};self.custom_stages=None;self.export_state=None;self.export_indices=[];self.release_heights={};self.opacity_controls={};self.floor_span=None
        self.cache=OrderedDict();self.solver_names={};self.last_clim=(0.,1.);self.max_value=None;self.max_position=None
        self.resize(760,540) if setup else self.resize(1100,740)
        self.setWindowTitle('PyVista (Open-Source) · '+('방향 셋업' if setup else '결과 보기')+(' · 검증 예제' if example else ''))
        center=QtWidgets.QWidget();self.setCentralWidget(center);layout=QtWidgets.QVBoxLayout(center)
        self.viewer_title=QtWidgets.QLabel('PyVista (Open-Source)');self.viewer_title.setStyleSheet('font-size:15px;font-weight:600;');layout.addWidget(self.viewer_title)
        self.option_tabs=QtWidgets.QTabWidget();layout.addWidget(self.option_tabs)
        result_page=QtWidgets.QWidget();result_layout=QtWidgets.QVBoxLayout(result_page)
        contour_page=QtWidgets.QWidget();contour_layout=QtWidgets.QVBoxLayout(contour_page)
        view_page=QtWidgets.QWidget();view_layout=QtWidgets.QVBoxLayout(view_page)
        for page,name in ((result_page,'결과 · 목록'),(contour_page,'컨투어'),(view_page,'화면 · 바닥')):self.option_tabs.addTab(page,name)
        stage_row=QtWidgets.QHBoxLayout();result_layout.addLayout(stage_row)
        self.stage_select=QtWidgets.QComboBox();self.stage_select.setSizePolicy(QtWidgets.QSizePolicy.Policy.Expanding,QtWidgets.QSizePolicy.Policy.Fixed);stage_row.addWidget(self.stage_select,1)
        open_run=QtWidgets.QPushButton('실행 폴더');open_run.clicked.connect(self.choose_run);stage_row.addWidget(open_run)
        self.pick_files=QtWidgets.QPushButton('파일 선택');self.edit_list=QtWidgets.QPushButton('재생 목록')
        stage_row.addWidget(self.pick_files);stage_row.addWidget(self.edit_list)
        self.pick_files.setEnabled(not setup);self.edit_list.setEnabled(not setup)
        self.pick_files.clicked.connect(lambda:self.edit_playback_list(True));self.edit_list.clicked.connect(lambda:self.edit_playback_list(False))
        refresh=QtWidgets.QPushButton('새로고침');refresh.clicked.connect(lambda:self.refresh_timeline(True));stage_row.addWidget(refresh)
        timeline_row=QtWidgets.QHBoxLayout();result_layout.addLayout(timeline_row)
        self.sequence=QtWidgets.QCheckBox('시퀀스 연속 보기');self.sequence.setChecked(not setup and run_root(self.folder) is not None);self.sequence.setEnabled(not setup)
        self.include_release=QtWidgets.QCheckBox('안정화 포함');self.include_release.setChecked(True)
        timeline_row.addWidget(self.sequence);timeline_row.addWidget(self.include_release);timeline_row.addStretch()
        self.save_movie=QtWidgets.QPushButton('동영상 저장');self.save_movie.clicked.connect(self.choose_movie);timeline_row.addWidget(self.save_movie)
        controls=QtWidgets.QHBoxLayout();contour_layout.addLayout(controls)
        self.scalar=QtWidgets.QComboBox();self.scalar.addItem('형상','형상');self.scalar.setMinimumWidth(255);controls.addWidget(QtWidgets.QLabel('결과'));controls.addWidget(self.scalar,1)
        self.averaging=QtWidgets.QComboBox();self.averaging.addItems(['Source','None','Simple','Advanced']);self.averaging.setToolTip('None: 요소별 IP 평균, Simple: 파트 내 절점 평균, Advanced: 임계값 기준. HyperView 내부 계산과 완전히 같다는 뜻은 아닙니다.');controls.addWidget(QtWidgets.QLabel('평균화'));controls.addWidget(self.averaging)
        self.threshold=QtWidgets.QDoubleSpinBox();self.threshold.setDecimals(1);self.threshold.setRange(0,100);self.threshold.setValue(75);self.threshold.setSuffix(' %');self.threshold.setFixedWidth(105);controls.addWidget(self.threshold)
        style_row=QtWidgets.QHBoxLayout();contour_layout.addLayout(style_row)
        self.contour_mode=QtWidgets.QComboBox();self.contour_mode.addItems(['Continuous','Discrete']);style_row.addWidget(self.contour_mode)
        self.contour_levels=QtWidgets.QSpinBox();self.contour_levels.setRange(2,32);self.contour_levels.setValue(12);self.contour_levels.setSuffix(' 단계');self.contour_levels.setEnabled(False);self.contour_levels.setFixedWidth(115);style_row.addWidget(self.contour_levels)
        self.show_max=QtWidgets.QCheckBox('Max 위치');style_row.addWidget(self.show_max);style_row.addStretch()
        ranges=QtWidgets.QHBoxLayout();contour_layout.addLayout(ranges)
        self.lock_range=QtWidgets.QCheckBox('범위 고정');ranges.addWidget(self.lock_range)
        self.minimum=QtWidgets.QDoubleSpinBox();self.maximum=QtWidgets.QDoubleSpinBox()
        for name,spin in [('Min',self.minimum),('Max',self.maximum)]:
            spin.setRange(-1e20,1e20);spin.setDecimals(3);spin.setMinimumWidth(135);ranges.addWidget(QtWidgets.QLabel(name));ranges.addWidget(spin)
        self.maximum.setValue(1);self.minimum.setEnabled(False);self.maximum.setEnabled(False)
        self.max_label=QtWidgets.QLabel('Max: —');self.max_label.setMinimumWidth(180);self.max_label.setSizePolicy(QtWidgets.QSizePolicy.Policy.Ignored,QtWidgets.QSizePolicy.Policy.Fixed);ranges.addWidget(self.max_label,1)
        view_controls=QtWidgets.QHBoxLayout();view_layout.addLayout(view_controls)
        self.view_mode=QtWidgets.QComboBox();self.view_mode.addItem('제품 중심 / 바닥 이동','center');self.view_mode.addItem('바닥 고정 / 제품 회전','floor');self.view_mode.addItem('원래 좌표','raw')
        if setup:self.view_mode.setCurrentIndex(2)
        view_controls.addWidget(self.view_mode)
        self.transitions=QtWidgets.QSpinBox();self.transitions.setRange(0,60);self.transitions.setValue(8);self.transitions.setSuffix(' 전환 프레임');self.transitions.setEnabled(not setup);view_controls.addWidget(self.transitions)
        self.perspective=QtWidgets.QPushButton('원근 ON');self.perspective.setCheckable(True);self.perspective.setChecked(True);self.perspective.clicked.connect(self.set_perspective);view_controls.addWidget(self.perspective)
        self.scale=QtWidgets.QDoubleSpinBox();self.scale.setRange(0,1000);self.scale.setValue(1);self.scale.setFixedWidth(120);view_controls.addWidget(QtWidgets.QLabel('변형 배율'));view_controls.addWidget(self.scale)
        self.edges=QtWidgets.QCheckBox('격자');self.edges.setChecked(True);view_controls.addWidget(self.edges);view_controls.addStretch()
        camera_row=QtWidgets.QHBoxLayout();view_layout.addLayout(camera_row)
        self.shading=QtWidgets.QSpinBox();self.shading.setRange(0,100);self.shading.setValue(65);self.shading.setSuffix(' %');self.shading.setFixedWidth(100);camera_row.addWidget(QtWidgets.QLabel('음영 농도'));camera_row.addWidget(self.shading)
        for caption,method in [('Iso','view_isometric'),('Front','view_xy'),('Top','view_xz'),('Right','view_yz'),('맞춤','reset_camera')]:
            button=QtWidgets.QPushButton(caption);camera_row.addWidget(button);button.clicked.connect(lambda checked=False,m=method:self.camera_view(m))
        self.show_floor=QtWidgets.QCheckBox('바닥');self.show_floor.setChecked(True);camera_row.addWidget(self.show_floor)
        self.floor_color='#c9ad78';self.floor_color_button=QtWidgets.QPushButton('바닥 색상');self.floor_color_button.clicked.connect(self.choose_floor_color);camera_row.addWidget(self.floor_color_button)
        self.floor_opacity=QtWidgets.QSpinBox();self.floor_opacity.setRange(0,100);self.floor_opacity.setValue(55);self.floor_opacity.setSuffix('%');self.floor_opacity.setFixedWidth(100);camera_row.addWidget(self.floor_opacity)
        self.release_guide=QtWidgets.QCheckBox('안정화 바닥 가이드');self.release_guide.setToolTip('표시용 가이드이며 실제 접촉은 없습니다.');camera_row.addWidget(self.release_guide);camera_row.addStretch()
        self.source_label=QtWidgets.QLabel();self.source_label.setWordWrap(True);self.source_label.setFixedHeight(36);layout.addWidget(self.source_label)
        split=QtWidgets.QSplitter();layout.addWidget(split,1)
        pane=QtWidgets.QWidget();pane_layout=QtWidgets.QVBoxLayout(pane);pane_layout.setContentsMargins(0,0,0,0)
        self.parts=QtWidgets.QTreeWidget();self.parts.setHeaderLabels(['파트','표시','컨투어','불투명도','색상'])
        self.parts.setRootIsDecorated(False);self.parts.setIndentation(0);self.parts.header().setStretchLastSection(False)
        for column,width in enumerate((100,42,62,100,36)):
            self.parts.header().setSectionResizeMode(column,QtWidgets.QHeaderView.ResizeMode.Fixed);self.parts.setColumnWidth(column,width)
        self.parts.header().setSectionResizeMode(0,QtWidgets.QHeaderView.ResizeMode.Stretch)
        pane.setMinimumWidth(365);pane_layout.addWidget(self.parts)
        actions=QtWidgets.QHBoxLayout();pane_layout.addLayout(actions)
        all_on=QtWidgets.QPushButton('전체');solo=QtWidgets.QPushButton('선택만');actions.addWidget(all_on);actions.addWidget(solo)
        split.addWidget(pane)
        plot_widget=QtWidgets.QWidget();plot_layout=QtWidgets.QVBoxLayout(plot_widget);plot_layout.setContentsMargins(0,0,0,0)
        self.plotter=QtInteractor(plot_widget);plot_layout.addWidget(self.plotter.interactor);split.addWidget(plot_widget);split.setSizes([365,735])
        from matplotlib import colors
        self.contour_cmap=colors.LinearSegmentedColormap.from_list('HyperView-style',['#0000ff','#00aaff','#00ffff','#00ff00','#ffff00','#ffaa00','#ff0000'])
        self.plotter.set_background('white')
        from .mouse_controls import ClassicMouse
        self.classic_mouse=ClassicMouse(self.plotter.interactor,self.plotter,self.fit_view)
        self.annotation=MaxAnnotation(self.plotter.interactor,self.plotter)
        self.plotter.iren.add_observer('EndInteractionEvent',lambda *_:self.annotation.update())
        self.plotter.iren.add_observer('InteractionEvent',lambda *_:self.annotation.update())
        playback=QtWidgets.QHBoxLayout();layout.addLayout(playback)
        self.play=QtWidgets.QPushButton();self.continuous_play=QtWidgets.QPushButton();self.playback_mode=None
        for button in (self.play,self.continuous_play):button.setFixedSize(34,28);button.setIconSize(QtCore.QSize(18,18));playback.addWidget(button)
        self.slider=QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal);playback.addWidget(self.slider,1)
        self.fps=QtWidgets.QSpinBox();self.fps.setRange(1,60);self.fps.setValue(10);self.fps.setSuffix(' fps');playback.addWidget(self.fps)
        self.frame_step=QtWidgets.QSpinBox();self.frame_step.setRange(1,10000);self.frame_step.setValue(1);self.frame_step.setMaximumWidth(75);playback.addWidget(QtWidgets.QLabel('프레임 간격'));playback.addWidget(self.frame_step)
        self.loop=QtWidgets.QCheckBox('반복');self.loop.setChecked(True);playback.addWidget(self.loop)
        self.frame_label=QtWidgets.QLabel();self.frame_label.setFixedWidth(290);self.frame_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight|QtCore.Qt.AlignmentFlag.AlignVCenter);self.frame_label.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.SystemFont.FixedFont));playback.addWidget(self.frame_label)
        self.stages=[]
        if setup:
            from .timeline import stage_info
            stage=stage_info(self.folder);stage['phase']='setup';stage['metadata']=read_json(self.folder/'setup.json',{})
            self.records=[{'time':0,'file':'product.vtu','stage':stage,'kind':'setup'}]
            self.stages=[stage]
        else:
            self.stages=collect_stages(self.folder,self.sequence.isChecked(),self.include_release.isChecked())
            self.records=build_records(self.stages,0)
        if not self.records:raise ValueError('완료된 결과 프레임이 없습니다.')
        self.slider.setRange(0,len(self.records)-1)
        current=[i for i,r in enumerate(self.records) if Path(r['stage']['folder'])==self.folder.resolve()]
        self.slider.setValue(current[-1] if current else 0)
        self.rebuild_stage_selector()
        grid=self.load_grid(self.slider.value());self.part_items={};self.build_parts(grid)
        names=[n for n in grid.array_names if n not in ('Node ID','Element ID','Part ID','Part Names','Stress source','Stress IP mean','STRESS','S Mises (MPa)') and n not in grid.field_data]
        if 'STRESS' in grid.array_names or 'Stress IP mean' in grid.cell_data:names.extend(STRESS_FIELDS)
        for name in dict.fromkeys('PEEQ' if n=='PE' else n for n in names):self.scalar.addItem(result_label(name),name)
        self.timer=QtCore.QTimer(self);self.timer.timeout.connect(self.advance)
        self.play.clicked.connect(self.toggle_play)
        self.continuous_play.setEnabled(not setup);self.continuous_play.clicked.connect(self.play_continuously)
        self.fps.valueChanged.connect(lambda _:self.timer.setInterval(round(1000/self.fps.value())));self.sync_play_buttons()
        self.play.setEnabled(len(self.records)>1)
        for signal in (self.slider.valueChanged,self.scalar.currentTextChanged,self.averaging.currentTextChanged,self.threshold.valueChanged,self.scale.valueChanged,self.edges.toggled,self.show_max.toggled,self.minimum.valueChanged,self.maximum.valueChanged):signal.connect(self.draw)
        self.lock_range.toggled.connect(self.range_changed);self.parts.itemChanged.connect(self.draw)
        all_on.clicked.connect(lambda:self.show_parts(False));solo.clicked.connect(lambda:self.show_parts(True))
        for signal in (self.sequence.toggled,self.include_release.toggled,self.transitions.valueChanged):signal.connect(lambda *_:self.refresh_timeline(True))
        self.view_mode.currentIndexChanged.connect(self.change_view_mode)
        self.floor_opacity.valueChanged.connect(self.draw);self.shading.valueChanged.connect(self.draw)
        self.contour_mode.currentIndexChanged.connect(self.change_contour_mode);self.contour_levels.valueChanged.connect(self.draw)
        self.show_floor.toggled.connect(self.draw);self.release_guide.toggled.connect(self.draw)
        self.stage_select.currentIndexChanged.connect(self.jump_stage)
        self.refresh_timer=QtCore.QTimer(self);self.refresh_timer.setInterval(3000);self.refresh_timer.timeout.connect(self.refresh_timeline);self.refresh_timer.start()
        self.refresh_timeline(True);self.draw();self.plotter.view_isometric();self.fit_view()
        for key,method in [('F','reset_camera'),('I','view_isometric')]:
            shortcut=QtGui.QShortcut(QtGui.QKeySequence(key),self);shortcut.activated.connect(lambda m=method:self.camera_view(m))
        self.statusBar().showMessage('Ctrl+왼쪽: 회전 / 클릭: 회전 중심 · Ctrl+오른쪽: 이동 · Ctrl+가운데: 영역 확대 / 클릭: 맞춤 · 휠: 확대')

    def update_solver_title(self,stage,grid):
        folder=Path(stage['folder']);root=run_root(folder)
        metadata=stage.get('metadata',{})
        cached=self.solver_names.get(str(folder))
        explicit={'abaqus':'Abaqus','calculix':'Calculix'}.get(metadata.get('solver'))
        if cached and (not explicit or cached==explicit):
            title=cached+' - PyVista (Open-Source)'
            if self.viewer_title.text()!=title:self.viewer_title.setText(title);self.setWindowTitle(title)
            return
        settings=read_json(root/'settings.json',{}) if root else {}
        state=read_json(folder/'results/state.json',{})
        solver=metadata.get('solver') or settings.get('solver') or state.get('solver')
        if not solver and 'abaqus' in state.get('material_history',''):solver='abaqus'
        if not solver:
            if list(folder.glob('*.odb')):solver='abaqus'
            elif list(folder.glob('*.frd')) or list(folder.glob('*.rout')):solver='calculix'
            else:
                source=' '.join(str(x) for x in grid.field_data.get('Stress source',[]))
                provenance=str(read_json(root/'sequence.json',{}).get('provenance','')) if root else ''
                if 'abaqus' in (source+' '+provenance).lower():solver='abaqus'
                elif 'calculix' in (source+' '+provenance).lower():solver='calculix'
        label={'abaqus':'Abaqus','calculix':'Calculix'}.get(str(solver).lower())
        if label:self.solver_names[str(folder)]=label
        title=(label+' - ' if label else '')+'PyVista (Open-Source)'
        if self.viewer_title.text()!=title:self.viewer_title.setText(title);self.setWindowTitle(title)

    def build_parts(self,grid):
        old={item.text(0):(item.checkState(1),item.checkState(2),self.opacity_controls[n].value()) for n,item in self.part_items.items() if n in self.opacity_controls}
        blocker=QtCore.QSignalBlocker(self.parts);self.parts.clear();self.part_items={};self.opacity_controls={};self.color_buttons={}
        for number,name in ensure_parts(grid).items():
            item=QtWidgets.QTreeWidgetItem([name,'','','','']);item.setData(0,QtCore.Qt.ItemDataRole.UserRole,number)
            item.setFlags(item.flags()|QtCore.Qt.ItemFlag.ItemIsUserCheckable)
            visible,contour,opacity=old.get(name,(QtCore.Qt.CheckState.Checked,QtCore.Qt.CheckState.Checked,100))
            item.setCheckState(1,visible);item.setCheckState(2,contour);self.parts.addTopLevelItem(item);self.part_items[number]=item
            spin=QtWidgets.QSpinBox();spin.setRange(0,100);spin.setValue(opacity);spin.setSuffix(' %');spin.setMinimumWidth(85);spin.setToolTip('0% 완전 투명 / 100% 불투명')
            self.parts.setItemWidget(item,3,spin);self.opacity_controls[number]=spin;spin.valueChanged.connect(self.draw)
            self.part_colors.setdefault(name,['#9bc4dd','#bad7bf','#ebd0aa','#d3bedb'][number%4])
            color=QtWidgets.QPushButton();color.setFixedWidth(28);color.setToolTip('파트 색상: 형상 모드 또는 이 파트의 컨투어를 끄면 적용됩니다.')
            color.setStyleSheet('background:'+self.part_colors[name]+';border:1px solid #aab7c5;')
            color.clicked.connect(lambda checked=False,n=name:self.choose_part_color(n));self.parts.setItemWidget(item,4,color);self.color_buttons[name]=color
        del blocker

    def choose_part_color(self,name):
        color=QtWidgets.QColorDialog.getColor(QtGui.QColor(self.part_colors[name]),self,'파트 색상 · '+name)
        if color.isValid():self.set_part_color(name,color.name())

    def set_part_color(self,name,color):
        if not QtGui.QColor(color).isValid():return
        self.part_colors[name]=color
        if name in self.color_buttons:self.color_buttons[name].setStyleSheet('background:'+color+';border:1px solid #aab7c5;')
        self.draw()

    def record_path(self,record):
        folder=Path(record['stage']['folder']);base=folder/'preview' if record['kind']=='setup' else folder/'results'
        return base/record['file']

    def load_record(self,record):
        path=self.record_path(record);key=str(path)
        if key not in self.cache:
            self.cache[key]=self.pv.read(path)
            if (path.parent/'parts.json').exists():self.cache[key].field_data['Part Names']=np.array(json.loads((path.parent/'parts.json').read_text()))
            ensure_parts(self.cache[key])
            if len(self.cache)>8:self.cache.popitem(last=False)
        self.cache.move_to_end(key);return self.cache[key].copy(deep=True)

    def load_grid(self,index):return self.load_record(self.records[index])

    def rebuild_stage_selector(self):
        blocker=QtCore.QSignalBlocker(self.stage_select);self.stage_select.clear()
        for stage in self.stages:self.stage_select.addItem(stage['title'],stage.get('playlist_id',stage['folder']))
        del blocker

    def refresh_timeline(self,force=False):
        if self.setup or self.export_state is not None:return
        selected=record_key(self.records[self.slider.value()]) if self.records else None
        stages=([s for s in self.custom_stages if self.include_release.isChecked() or s['phase']!='release']
                if self.custom_stages is not None else collect_stages(self.folder,self.sequence.isChecked(),self.include_release.isChecked()))
        count=self.transitions.value() if self.view_mode.currentData() in ('floor','center') and self.sequence.isChecked() else 0
        records=build_records(stages,count)
        if not records:return
        if not force and [record_key(r) for r in records]==[record_key(r) for r in self.records]:return
        self.stages=stages;self.records=records;self.floor_span=None;self.rebuild_stage_selector()
        index=next((i for i,r in enumerate(records) if record_key(r)==selected),min(self.slider.value(),len(records)-1))
        blocker=QtCore.QSignalBlocker(self.slider);self.slider.setRange(0,len(records)-1);self.slider.setValue(index);del blocker
        self.play.setEnabled(len(records)>1);self.draw()

    def jump_stage(self,index):
        folder=self.stage_select.itemData(index)
        match=next((i for i,r in enumerate(self.records) if r['stage'].get('playlist_id',r['stage']['folder'])==folder and r['kind']!='transition'),None)
        if match is not None:self.slider.setValue(match)

    def edit_playback_list(self,add_files=False):
        if self.export_state is not None:return
        from .playlist import edit_playlist
        self.stop_playback()
        stages=edit_playlist(self,self.custom_stages if self.custom_stages is not None else self.stages,add_files)
        if stages is None:return
        if not stages:
            QtWidgets.QMessageBox.information(self,'재생 목록','재생할 결과를 한 개 이상 체크하세요.');return
        self.apply_playlist(stages)

    def apply_playlist(self,stages):
        self.stop_playback();self.custom_stages=stages;self.cache.clear();self.release_heights.clear()
        self.sequence.setChecked(True);self.sequence.setEnabled(False);self.include_release.setChecked(True)
        self.refresh_timeline(True);self.slider.setValue(0);self.build_parts(self.load_grid(0));self.draw();self.fit_view()
        self.statusBar().showMessage(f'직접 선택한 재생 목록: {len(stages)}개 결과 · 연속재생 버튼으로 시작')

    def choose_run(self):
        if self.export_state is not None:return
        path=QtWidgets.QFileDialog.getExistingDirectory(self,'doe 실행 폴더 선택',str(self.folder.parent))
        if not path:return
        if not collect_stages(path,True,True):QtWidgets.QMessageBox.information(self,'결과 보기','완료된 해석 결과가 없습니다.');return
        self.custom_stages=None;self.sequence.setEnabled(True)
        self.stop_playback();self.folder=Path(path);self.sequence.setChecked(True);self.release_heights.clear();self.cache.clear()
        self.refresh_timeline(True);self.build_parts(self.load_grid(self.slider.value()));self.draw();self.fit_view()

    def change_view_mode(self):
        self.transitions.setEnabled(self.view_mode.currentData() in ('floor','center') and not self.setup)
        self.refresh_timeline(True);self.draw();self.camera_view('view_isometric')

    def set_perspective(self,checked):
        self.perspective.setText('원근 ON' if checked else '원근 OFF')
        self.plotter.camera.parallel_projection=not checked;self.plotter.render()

    def choose_floor_color(self):
        color=QtWidgets.QColorDialog.getColor(QtGui.QColor(self.floor_color),self,'바닥 색상')
        if color.isValid():self.floor_color=color.name();self.draw()

    def change_contour_mode(self):
        self.contour_levels.setEnabled(self.contour_mode.currentText()=='Discrete');self.draw()

    def camera_view(self,method):
        if method=='reset_camera':self.fit_view();return
        if method=='view_isometric' and self.view_mode.currentData()=='floor':
            self.plotter.view_vector((1,.7,1),viewup=(0,1,0));self.fit_view()
        else:getattr(self.plotter,method)()

    def floor_size(self):
        if self.floor_span is None:
            spans=[]
            for stage in self.stages:
                _,_,p=floor_basis(stage.get('metadata',{}))
                if p is not None:spans.append(max(np.linalg.norm(p[1]-p[0]),np.linalg.norm(p[2]-p[1]))*.5)
            self.floor_span=max(spans) if spans else 300.
        return self.floor_span

    def release_height(self,stage):
        key=stage['folder']
        if key not in self.release_heights:
            drop=Path(stage['drop_folder']);frames=read_json(drop/'results/frames.json',[])
            if frames:
                g=self.load_record({'stage':{'folder':str(drop)},'file':frames[-1]['file'],'kind':'result'})
                r,anchor,_=floor_basis(stage.get('metadata',{}));self.release_heights[key]=float((center(g.points)-anchor)@r[:,1])
            else:self.release_heights[key]=None
        return self.release_heights[key]

    def fit_view(self):
        if self.view_mode.currentData()=='floor' and self.records:
            g=self.load_grid(self.slider.value());length=max(g.length,1.)
            span=self.floor_size();self.plotter.reset_camera(bounds=(-span,span,-.05*length,1.1*length,-span,span))
        else:self.plotter.reset_camera()

    def show_parts(self,solo):
        selected=self.parts.currentItem()
        if solo and selected is None:return
        blocker=QtCore.QSignalBlocker(self.parts)
        for item in self.part_items.values():item.setCheckState(1,QtCore.Qt.CheckState.Checked if not solo or item is selected else QtCore.Qt.CheckState.Unchecked)
        del blocker;self.draw()

    def range_changed(self,checked):
        self.minimum.setEnabled(checked);self.maximum.setEnabled(checked)
        if checked:
            a=QtCore.QSignalBlocker(self.minimum);b=QtCore.QSignalBlocker(self.maximum)
            self.minimum.setValue(self.last_clim[0]);self.maximum.setValue(self.last_clim[1]);del a,b
        self.draw()

    def sync_play_buttons(self):
        active=self.timer.isActive()
        for button,mode,idle,tip in ((self.play,'normal',QtWidgets.QStyle.StandardPixmap.SP_MediaPlay,'재생'),(self.continuous_play,'sequence',QtWidgets.QStyle.StandardPixmap.SP_MediaSkipForward,'연속재생')):
            playing=active and self.playback_mode==mode
            button.setIcon(self.style().standardIcon(QtWidgets.QStyle.StandardPixmap.SP_MediaPause if playing else idle))
            button.setToolTip('멈춤' if playing else tip);button.setAccessibleName('멈춤' if playing else tip)

    def stop_playback(self):
        self.timer.stop();self.sync_play_buttons()

    def toggle_play(self):
        if self.export_state is not None or self.setup:return
        if self.timer.isActive() and self.playback_mode=='normal':self.stop_playback();return
        self.playback_mode='normal'
        if self.slider.value()==self.slider.maximum():self.slider.setValue(0)
        self.timer.start(round(1000/self.fps.value()));self.sync_play_buttons()

    def play_continuously(self):
        if self.setup or self.export_state is not None:return
        if self.timer.isActive() and self.playback_mode=='sequence':self.stop_playback();return
        self.stop_playback();self.sequence.setChecked(True);self.refresh_timeline(True)
        self.playback_mode='sequence';self.slider.setValue(0);self.timer.start(round(1000/self.fps.value()));self.sync_play_buttons()

    def advance(self):
        value=self.slider.value()+self.frame_step.value()
        if value>self.slider.maximum():
            if self.loop.isChecked():value=0
            else:self.stop_playback();return
        self.slider.setValue(value)

    def draw(self,*_):
        if self._drawing:return
        self._drawing=True;self.plotter.suppress_rendering=True
        try:self.draw_scene()
        finally:
            self.plotter.suppress_rendering=False;self._drawing=False
        self.plotter.render()

    def draw_scene(self):
        if not hasattr(self,'part_items'):return
        record=self.records[self.slider.value()];grid=self.load_grid(self.slider.value());stage=record['stage']
        if ensure_parts(grid)!={i:item.text(0) for i,item in self.part_items.items()}:self.build_parts(grid)
        if not self.setup and 'DISP' in grid.point_data:grid.points+=(self.scale.value()-1)*grid.point_data['DISP'][:,:3]
        height=self.release_height(stage) if stage['phase']=='release' else None
        grid.points,floor,r,offset=display_transform(grid.points,record,self.view_mode.currentData(),height,self.floor_size())
        scalar=self.scalar.currentData();stress=is_stress_field(scalar)
        self.update_solver_title(stage,grid)
        available='Stress IP mean' in grid.cell_data
        for i in range(1,4):self.averaging.model().item(i).setEnabled(available and stress)
        if not (available and stress) and self.averaging.currentIndex()!=0:
            blocker=QtCore.QSignalBlocker(self.averaging);self.averaging.setCurrentIndex(0);del blocker
        self.threshold.setEnabled(available and self.averaging.currentText()=='Advanced')
        prepared=[];sources=[];outlines={}
        try:
            for number,item in self.part_items.items():
                if item.checkState(1)!=QtCore.Qt.CheckState.Checked:continue
                sub=grid.extract_cells(np.flatnonzero(grid.cell_data['Part ID']==number))
                if not self.edges.isChecked():outlines[number]=sub.extract_surface().extract_feature_edges(feature_angle=35,boundary_edges=True,non_manifold_edges=True,feature_edges=True,manifold_edges=False)
                contour=scalar!='형상' and item.checkState(2)==QtCore.Qt.CheckState.Checked
                if contour:
                    try:sub,association,source=contour_grid(sub,scalar,self.averaging.currentText(),self.threshold.value());sources.append(source)
                    except ValueError:association=None;sources.append(f'{item.text(0)}: 이 프레임에 {scalar} 출력 없음')
                else:association=None
                prepared.append((number,sub,association))
        except ValueError as exc:self.source_label.setText(str(exc));return
        entries=[(n,g,a) for n,g,a in prepared if a is not None]
        if entries:
            values=np.concatenate([(g.point_data if a=='point' else g.cell_data)['Contour'] for _,g,a in entries]);finite=values[np.isfinite(values)]
            if len(finite):low,high=float(finite.min()),float(finite.max())
            else:low,high=0.,1.
            auto=(low,high if high>low else low+max(abs(low)*1e-6,1e-6))
            if not self.lock_range.isChecked():self.last_clim=auto
        clim=(self.minimum.value(),self.maximum.value()) if self.lock_range.isChecked() else self.last_clim
        if clim[0]>=clim[1]:self.source_label.setText('컨투어 범위는 Min < Max여야 합니다.');return
        self.plotter.clear();bar=False;best=None
        for number,sub,association in prepared:
            self.plotter.add_mesh(sub,scalars='Contour' if association else None,preference=association or 'point',color=self.part_colors.get(self.part_items[number].text(0),'#b9cddd'),cmap=self.contour_cmap,n_colors=self.contour_levels.value() if self.contour_mode.currentText()=='Discrete' else 256,interpolate_before_map=True,clim=clim,
                                  name=f'product_{number}',lighting=True,ambient=.65-.004*self.shading.value(),diffuse=.35+.005*self.shading.value(),specular=.16,specular_power=24,render=False,opacity=self.opacity_controls[number].value()/100,show_edges=self.edges.isChecked(),edge_color='#52677b',reset_camera=False,show_scalar_bar=bool(association and not bar),
                                  scalar_bar_args={'title':self.scalar.currentText(),'color':'#263b50','fmt':'%.3g','title_font_size':12,'label_font_size':11,'n_labels':4,'unconstrained_font_size':True})
            if number in outlines and outlines[number].n_cells:
                self.plotter.add_mesh(outlines[number],color='#536170',opacity=self.opacity_controls[number].value()/100,line_width=1.2,lighting=False,name=f'feature_{number}',reset_camera=False,render=False)
            if association:
                bar=True;values=(sub.point_data if association=='point' else sub.cell_data)['Contour'];valid=np.flatnonzero(np.isfinite(values))
                if len(valid):
                    i=int(valid[np.argmax(values[valid])]);value=float(values[i]);position=sub.points[i] if association=='point' else sub.cell_centers().points[i]
                    if best is None or value>best[0]:
                        id_name='Node ID' if association=='point' else 'Element ID'
                        data=sub.point_data if association=='point' else sub.cell_data
                        label=int(data[id_name][i]) if id_name in data else i
                        best=(value,position,self.part_items[number].text(0),association,label)
        self.max_value=best[0] if best else None;self.max_position=best[1].copy() if best else None
        max_text=(f'Max {0. if round(best[0],3)==0 else best[0]:.3f} '+result_unit(scalar)).strip() if best else 'Max: —'
        self.max_label.setText(max_text)
        self.max_label.setToolTip('현재 표시된 컨투어의 최대값')
        if best and self.show_max.isChecked():
            text=max_text
            self.annotation.set_result(best[1],text)
        else:self.annotation.set_result(None,'')
        guide=stage['phase']=='release' and record.get('kind')!='transition'
        if floor is not None and self.show_floor.isChecked() and (not guide or self.release_guide.isChecked()):
            self.plotter.add_mesh(self.pv.PolyData(floor,faces=[4,0,1,2,3]),color=self.floor_color,opacity=min(.22,self.floor_opacity.value()/100) if guide else self.floor_opacity.value()/100,show_edges=True,reset_camera=False,name='display_floor')
        if self.setup:
            info=stage['metadata'];origin=np.array(info['origin'])@r+offset
            for vec,color in zip(np.array(info['rotation']).T,('#ef7575','#70d8a1','#75a5ef')):self.plotter.add_arrows(origin,(vec@r)*45,color=color)
            self.plotter.add_arrows(np.array(grid.center),(np.array(info['direction'])@r)*65,color='#e9a830')
        self.plotter.add_axes();self.frame_label.setText(f'{self.slider.value()+1:5d}/{len(self.records):5d}  t={record["time"]:12.6f} s')
        self.frame_label.setToolTip('t = '+decimal_text(record['time'])+' s')
        title=('방향 전환(보기용) · 응력은 이전 완료 상태' if record['kind']=='transition' else stage['title'])
        if guide and self.release_guide.isChecked():title+=' · 바닥은 보기용 가이드(접촉 없음)'
        if guide and self.view_mode.currentData()=='floor':title+=' · 안정화 강체 병진 제거'
        self.plotter.add_text(self.viewer_title.text()+'\n'+title+f'\nFrame {self.slider.value()+1}/{len(self.records)} · t={decimal_text(record["time"])} s',position='upper_left',font_size=8,color='#405165',name='sequence_caption')
        selected=next((i for i,s in enumerate(self.stages) if s.get('playlist_id',s['folder'])==stage.get('playlist_id',stage['folder'])),0)
        blocker=QtCore.QSignalBlocker(self.stage_select);self.stage_select.setCurrentIndex(selected);del blocker
        note=' | '.join(dict.fromkeys(sources)) if sources else '파트별 표시/컨투어 체크로 영역을 선택하세요.'
        self.source_label.setText(note+(' · 요소 응력이 없는 이전 결과는 Source만 표시합니다.' if stress and not available else ''))
        if self.workflow:self.plotter.add_text('SEQUENCE CHECK - NO PHYSICS RESULTS',font_size=10,color='#304c68')
        elif self.example:self.plotter.add_text('VERIFICATION EXAMPLE (Linux CalculiX 2.23)',font_size=10,color='#304c68')
        self.annotation.update()

    def choose_movie(self):
        if self.export_state is not None:return
        path,chosen=QtWidgets.QFileDialog.getSaveFileName(self,'동영상 저장',str(self.folder/'drop_sequence.mp4'),'MP4 동영상 (*.mp4);;AVI 동영상 (*.avi);;GIF 애니메이션 (*.gif)')
        if path:
            extension='.gif' if '*.gif' in chosen else '.avi' if '*.avi' in chosen else '.mp4'
            target=Path(path)
            self.begin_export(target if target.suffix.lower() in ('.avi','.mp4','.gif') else target.with_suffix(extension))

    def begin_export(self,path):
        if self.export_state is not None:return
        from .movie import movie_writer
        self.stop_playback();self.refresh_timer.stop()
        image=self.plotter.screenshot(return_img=True)
        width=image.shape[1]//2*2;height=image.shape[0]//2*2
        try:writer=movie_writer(path,width,height,self.fps.value())
        except Exception as exc:
            self.refresh_timer.start();self.statusBar().showMessage('동영상 저장 실패: '+str(exc));self.movie_failed.emit(str(exc));return
        indices=list(range(0,len(self.records),self.frame_step.value()))
        self.export_state={'writer':writer,'old_frame':self.slider.value(),'index':0,'indices':indices,'total':len(indices),'width':width,'height':height}
        self.centralWidget().setEnabled(False)
        self.export_progress=QtWidgets.QProgressDialog('동영상 프레임 저장 중','취소',0,len(indices),self)
        self.export_progress.setWindowTitle('동영상 저장 · '+Path(path).suffix.upper());self.export_progress.setWindowModality(QtCore.Qt.WindowModality.WindowModal)
        self.export_progress.setAutoClose(False);self.export_progress.canceled.connect(self.abort_export);self.export_progress.show()
        self.export_timer=QtCore.QTimer(self);self.export_timer.setSingleShot(True);self.export_timer.timeout.connect(self.export_frame);self.export_timer.start(0)

    def export_frame(self):
        state=self.export_state
        if state is None:return
        try:
            if state['index']<state['total']:
                index=state['indices'][state['index']]
                if self.slider.value()==index:self.draw()
                else:self.slider.setValue(index)
                image=self.annotation.paint_on(self.plotter.screenshot(return_img=True))
                accepted=state['writer'].add(image[:state['height'],:state['width']])
                if accepted is False:self.export_timer.start(10);return
                state['index']+=1;self.export_progress.setValue(state['index'])
            if state['index']>=state['total']:
                if state['writer'].close() is False:self.export_timer.start(20);return
                path=str(state['writer'].path);self.finish_export();self.statusBar().showMessage('동영상 저장 완료: '+path);self.movie_saved.emit(path)
            else:self.export_timer.start(0)
        except Exception as exc:
            state['writer'].abort();self.finish_export();self.statusBar().showMessage('동영상 저장 실패: '+str(exc));self.movie_failed.emit(str(exc))

    def finish_export(self):
        state=self.export_state
        if state is None:return
        self.export_timer.stop();self.export_state=None;self.export_progress.close();self.export_progress.deleteLater()
        self.centralWidget().setEnabled(True);self.slider.setValue(state['old_frame']);self.draw();self.refresh_timer.start()

    def abort_export(self):
        if self.export_state is None:return
        self.export_state['writer'].abort();self.finish_export();self.statusBar().showMessage('동영상 저장 취소 · 미완성 파일은 제거했습니다.')

    def closeEvent(self,event):
        self.stop_playback();self.refresh_timer.stop()
        if self.export_state is not None:self.abort_export()
        self.refresh_timer.stop()
        self.plotter.close();super().closeEvent(event)


def main():
    p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('--setup',action='store_true');p.add_argument('--workflow',action='store_true');p.add_argument('--example',action='store_true');p.add_argument('--drop-only',action='store_true');p.add_argument('--screenshot',type=Path);args=p.parse_args()
    app=QtWidgets.QApplication(sys.argv)
    from .gui import STYLE
    app.setStyleSheet(STYLE)
    try:
        win=Viewer(args.folder,args.setup,args.workflow,args.example)
        if args.drop_only:win.include_release.setChecked(False)
        win.show()
    except Exception as exc:QtWidgets.QMessageBox.critical(None,'결과 열기 실패',str(exc));return 1
    if args.screenshot:
        def capture():win.plotter.screenshot(str(args.screenshot));win.close();app.quit()
        QtCore.QTimer.singleShot(1000,capture)
    return app.exec()

if __name__=='__main__':raise SystemExit(main())
