"""Stable element-set part labels shared by solver conversion and the viewer."""
import numpy as np


def mesh_parts(mesh):
    groups={}
    eligible={name:set(ids) for name,ids in mesh.elsets.items() if
              not name.startswith(('AUTO_','PRODUCT_','FLOOR_')) and name!='BODY_TOP'}
    for e,(kind,_) in mesh.product_elements.items():
        candidates=[name for name,ids in eligible.items() if e in ids]
        groups[e]=mesh.element_groups.get(e) or (min(candidates,key=lambda n:(len(mesh.elsets[n]),n)) if candidates else ('SHELL' if kind=='S4' else 'SOLID'))
    names=sorted(set(groups.values()))
    return names,{e:names.index(name) for e,name in groups.items()}


def ensure_parts(grid):
    if 'Part ID' not in grid.cell_data:
        types=sorted(set(grid.celltypes))
        names=[{12:'BODY',9:'LOGO'}.get(int(t),f'Type {t}') for t in types]
        grid.cell_data['Part ID']=np.array([types.index(t) for t in grid.celltypes],dtype=np.int32)
        grid.field_data['Part Names']=np.array(names)
    names=[str(n) for n in grid.field_data.get('Part Names',[])]
    ids=sorted(set(int(n) for n in grid.cell_data['Part ID']))
    return {i:names[i] if i<len(names) else f'Part {i}' for i in ids}
