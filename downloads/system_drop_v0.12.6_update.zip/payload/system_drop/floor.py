"""Solver-specific rigid-floor geometry definitions."""
import numpy as np

def floor_text(solver, surface, base=1001):
    lines = ["** --- FLOOR GEOMETRY: regenerated for each direction ---", "*NODE"]
    if solver == "abaqus":
        for i,p in enumerate(surface): lines.append(f"{20001+i}, " + ", ".join(f"{x:.12g}" for x in p))
        lines.extend(["20010, " + ", ".join(f"{x:.12g}" for x in surface.mean(axis=0)),
                      "*ELEMENT, TYPE=R3D4, ELSET=FLOOR_ELEMENTS", "20001, 20001, 20002, 20003, 20004",
                      "*NSET, NSET=FLOOR_NODES", "20001, 20002, 20003, 20004, 20010",
                      "*NSET, NSET=FLOOR_REF", "20010",
                      "*RIGID BODY, REF NODE=20010, ELSET=FLOOR_ELEMENTS",
                      "*SURFACE, TYPE=ELEMENT, NAME=FLOOR_SURFACE", "FLOOR_ELEMENTS, SPOS"])
    else:
        # CalculiX rigid body uses dependent C3D8 nodes, no R3D4 element.
        d = -np.cross(surface[1]-surface[0], surface[2]-surface[1])
        d /= np.linalg.norm(d)
        points = np.vstack((surface+10*d, surface))
        for i,p in enumerate(points): lines.append(f"{20001+i}, " + ", ".join(f"{x:.12g}" for x in p))
        lines.extend(["20010, " + ", ".join(f"{x:.12g}" for x in surface.mean(axis=0)),
                      "20011, 0., 0., 0.",
                      "*ELEMENT, TYPE=C3D8, ELSET=FLOOR_ELEMENTS",
                      "20001, 20001, 20002, 20003, 20004, 20005, 20006, 20007, 20008",
                      "*NSET, NSET=FLOOR_NODES", "20001, 20002, 20003, 20004, 20005, 20006, 20007, 20008",
                      "*NSET, NSET=FLOOR_REF", "20010",
                      "*NSET, NSET=FLOOR_ROT", "20011",
                      "*RIGID BODY, NSET=FLOOR_NODES, REF NODE=20010, ROT NODE=20011",
                      "*SURFACE, TYPE=ELEMENT, NAME=FLOOR_SURFACE", "FLOOR_ELEMENTS, S2"])
    rigid=next(line for line in lines if line.startswith('*RIGID BODY'))
    lines.remove(rigid);lines.append(rigid)
    if base!=20001:
        import re
        card=""
        rewritten=[]
        for line in lines:
            if line.startswith("*") and not line.startswith("**"):
                card=line.split(",")[0]
                if card=="*RIGID BODY":
                    line=re.sub(r"\b200(?:0[1-9]|1[01])\b",lambda m:str(int(m.group())+base-20001),line)
            elif not line.startswith("**"):
                if card=="*NODE":
                    label,rest=line.split(",",1)
                    line=str(int(label)+base-20001)+","+rest
                elif card in ("*ELEMENT","*NSET"):
                    line=", ".join(str(int(x.strip())+base-20001) for x in line.split(","))
            rewritten.append(line)
        lines=rewritten
    return "\n".join(lines)


