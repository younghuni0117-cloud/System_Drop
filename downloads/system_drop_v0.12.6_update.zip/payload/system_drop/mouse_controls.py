"""Classic HyperMesh navigation bindings for the result viewport."""
from PySide6 import QtCore,QtWidgets
import numpy as np


class ClassicMouse(QtCore.QObject):
    def __init__(self,viewport,plotter,fit):
        super().__init__(viewport)
        self.viewport=viewport;self.plotter=plotter;self.fit=fit;self.start=None;self.rotate_start=None
        self.rubber=QtWidgets.QRubberBand(QtWidgets.QRubberBand.Shape.Rectangle,viewport)
        plotter.enable_custom_trackball_style(control_left='rotate',control_middle='dolly',control_right='pan')
        viewport.installEventFilter(self)

    def zoom_region(self,rect):
        renderer=self.plotter.renderer;camera=self.plotter.camera
        w,h=self.plotter.render_window.GetSize()
        sx=w/max(1,self.viewport.width());sy=h/max(1,self.viewport.height())
        renderer.SetWorldPoint(*camera.focal_point,1);renderer.WorldToDisplay();depth=renderer.GetDisplayPoint()[2]
        renderer.SetDisplayPoint(rect.center().x()*sx,h-rect.center().y()*sy,depth);renderer.DisplayToWorld()
        point=np.asarray(renderer.GetWorldPoint());point=point[:3]/point[3]
        delta=point-np.asarray(camera.focal_point)
        camera.position=np.asarray(camera.position)+delta;camera.focal_point=point
        camera.zoom(min(self.viewport.width()/max(rect.width(),1),self.viewport.height()/max(rect.height(),1)))
        renderer.ResetCameraClippingRange();self.plotter.render()

    def pick_center(self,point):
        from vtkmodules.vtkRenderingCore import vtkCellPicker
        w,h=self.plotter.render_window.GetSize()
        picker=vtkCellPicker();picker.SetTolerance(.005)
        picker.PickFromListOn()
        for name,actor in self.plotter.actors.items():
            if name.startswith('product_'):picker.AddPickList(actor)
        if picker.Pick(point.x()*w/max(1,self.viewport.width()),h-point.y()*h/max(1,self.viewport.height()),0,self.plotter.renderer):
            camera=self.plotter.camera;target=np.asarray(picker.GetPickPosition())
            delta=target-np.asarray(camera.focal_point)
            camera.position=np.asarray(camera.position)+delta;camera.focal_point=target
            self.plotter.renderer.ResetCameraClippingRange();self.plotter.render()

    def eventFilter(self,obj,event):
        kind=event.type();control=bool(event.modifiers() & QtCore.Qt.KeyboardModifier.ControlModifier) if hasattr(event,'modifiers') else False
        if kind==QtCore.QEvent.Type.MouseButtonPress:
            if control and event.button()==QtCore.Qt.MouseButton.MiddleButton:
                self.start=event.position().toPoint();return True
            if control and event.button()==QtCore.Qt.MouseButton.LeftButton:self.rotate_start=event.position().toPoint()
            if not control:return True
        if kind==QtCore.QEvent.Type.MouseMove and self.start is not None:
            rect=QtCore.QRect(self.start,event.position().toPoint()).normalized()
            self.rubber.setGeometry(rect)
            if rect.width()+rect.height()>6:self.rubber.show()
            return True
        if kind==QtCore.QEvent.Type.MouseButtonRelease:
            if event.button()==QtCore.Qt.MouseButton.MiddleButton and self.start is not None:
                rect=QtCore.QRect(self.start,event.position().toPoint()).normalized();self.start=None;self.rubber.hide()
                if max(rect.width(),rect.height())<5:self.fit()
                else:self.zoom_region(rect)
                return True
            if event.button()==QtCore.Qt.MouseButton.LeftButton and self.rotate_start is not None:
                if (event.position().toPoint()-self.rotate_start).manhattanLength()<5:self.pick_center(event.position().toPoint())
                self.rotate_start=None
        return super().eventFilter(obj,event)
