"""Mass-weighted rigid velocity removal; constitutive state is never reset."""
from pathlib import Path
import hashlib,json
import numpy as np
from .deck import expanded_lines,keyword


def brick_masses(points,density):
    """Row-sum consistent C3D8 mass, 2x2x2 reference Gauss integration."""
    points=np.asarray(points,dtype=float)
    signs=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],
                    [-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]])
    mass=np.zeros(8)
    for a in (-1,1):
        for b in (-1,1):
            for c in (-1,1):
                q=np.array([a,b,c])/np.sqrt(3);f=1+signs*q
                shape=np.prod(f,axis=1)/8
                grad=np.column_stack([signs[:,i]*np.prod(np.delete(f,i,axis=1),axis=1)/8 for i in range(3)])
                det=np.linalg.det(points.T@grad)
                if not np.isfinite(det) or det<=0:raise ValueError('질량 계산: C3D8 기준 형상이 뒤집혔거나 퇴화했습니다.')
                mass+=density*det*shape
    if density<=0 or not np.isfinite(mass).all():raise ValueError('양의 유한한 밀도가 필요합니다.')
    return mass


def remove_rigid_velocity(points,velocities,masses):
    """Orthogonal mass projection, preserving all non-rigid velocity modes."""
    p=np.asarray(points,dtype=float);v=np.asarray(velocities,dtype=float);m=np.asarray(masses,dtype=float)
    if p.shape!=v.shape or p.shape!=(len(m),3) or not np.isfinite(p).all() or not np.isfinite(v).all() or not np.isfinite(m).all() or np.any(m<0) or m.sum()<=0:
        raise ValueError('유효한 제품 좌표, 속도, 절점 질량이 필요합니다.')
    center=np.sum(m[:,None]*p,axis=0)/m.sum();x=p-center
    translation=np.sum(m[:,None]*v,axis=0)/m.sum()
    inertia=sum(w*(np.dot(r,r)*np.eye(3)-np.outer(r,r)) for w,r in zip(m,x))
    if np.linalg.matrix_rank(inertia)!=3:raise ValueError('강체 회전 제거를 위한 관성 텐서가 특이합니다.')
    angular=np.linalg.solve(inertia,np.sum(m[:,None]*np.cross(x,v-translation),axis=0))
    residual=v-translation-np.cross(angular,x)
    energy=lambda value:float(.5*np.sum(m[:,None]*value**2))
    report={'mass_tonne':float(m.sum()),'center':center.tolist(),'removed_translation_mm_s':translation.tolist(),
            'removed_angular_rad_s':angular.tolist(),'kinetic_before_Nmm':energy(v),'kinetic_after_Nmm':energy(residual),
            'residual_linear_momentum':np.sum(m[:,None]*residual,axis=0).tolist(),
            'residual_angular_momentum':np.sum(m[:,None]*np.cross(x,residual),axis=0).tolist()}
    return residual,report


def template_masses(mesh,main):
    """Constant-density C3D8/S4 section masses for Abaqus initial velocities."""
    densities={};sections={};card='';params={};material=None
    for line in expanded_lines(main):
        line=line.strip()
        if not line or line.startswith('**'):continue
        if line.startswith('*'):
            card,params=keyword(line)
            if card=='*SHELL SECTION' and 'COMPOSITE' in params:raise ValueError('복합 쉘 섹션의 질량/Import는 전용 검토가 필요합니다.')
            if card=='*MATERIAL':material=str(params['NAME']).upper()
            if card=='*SOLID SECTION':sections[str(params['ELSET']).upper()]=(str(params['MATERIAL']).upper(),None)
            continue
        if card=='*DENSITY':
            values=[x.strip() for x in line.split(',') if x.strip()]
            if material in densities or len(values)>1:raise ValueError('강체 속도 제거는 온도에 무관한 상수 밀도가 필요합니다.')
            densities[material]=float(values[0].replace('D','E'))
        elif card=='*SHELL SECTION':
            sections[str(params['ELSET']).upper()]=(str(params['MATERIAL']).upper(),float(line.split(',')[0]));card=''
    assignment={}
    for group,section in sections.items():
        for e in mesh.elsets[group]:
            if e in assignment:raise ValueError(f'요소 {e}의 section 중복')
            assignment[e]=section
    masses={n:0. for n in mesh.product_nodes}
    for e,(kind,conn) in mesh.product_elements.items():
        material,thickness=assignment[e];rho=densities[material];p=np.array([mesh.nodes[n] for n in conn])
        if kind in ('C3D8','C3D8R'):weights=brick_masses(p,rho)
        elif kind=='C3D4':
            volume=np.linalg.det((p[1:]-p[0]).T)/6
            if volume<=0:raise ValueError('뒤집힌 C3D4 요소')
            weights=np.full(4,rho*volume/4)
        elif kind=='S3' and thickness and thickness>0:
            weights=np.full(3,rho*thickness*np.linalg.norm(np.cross(p[1]-p[0],p[2]-p[0]))/6)
        elif kind in ('S4','S4R') and thickness and thickness>0:
            # Bilinear shell midsurface, 2x2 integration of areal mass.
            weights=np.zeros(4);signs=np.array([[-1,-1],[1,-1],[1,1],[-1,1]])
            for a in (-1,1):
                for b in (-1,1):
                    f=1+signs*np.array([a,b])/np.sqrt(3);n=np.prod(f,axis=1)/4
                    grad=np.column_stack((signs[:,0]*f[:,1],signs[:,1]*f[:,0]))/4
                    jac=p.T@grad;weights+=rho*thickness*np.linalg.norm(np.cross(jac[:,0],jac[:,1]))*n
        else:raise ValueError(f'누적 안정화 질량 계산에서 {kind}는 아직 지원하지 않습니다. C3D8/C3D8R/C3D4/S3/S4/S4R로 준비하세요.')
        for n,w in zip(conn,weights):masses[n]+=float(w)
    return masses


def state_hash(native):
    h=hashlib.sha256()
    for i,record in enumerate(native.records):
        if i!=native.fields['irstrt']:h.update(len(record).to_bytes(8,'little'));h.update(record)
    return h.hexdigest()


def native_velocity_arrays(r,mesh):
    from .restart import RestartError
    co=r.doubles('co').reshape(-1,3);u=r.doubles('vold').reshape(-1,r.mi[1]+1)
    velocity=r.doubles('veold').reshape(u.shape).copy();mass=np.zeros(len(co))
    rho=r.doubles('rhcon').reshape(r.sizes['nmat'],r.sizes['ntmat'],2)
    counts=r.ints('nrhcon');materials=r.ints('ielmat').reshape(-1,r.mi[2])
    kon=r.ints('kon');ipkon=r.ints('ipkon')
    # Expanded shell physical corners carry mass; dependent midsurface nodes do
    # not receive a duplicate mass. Their velocity still loses the same rigid field.
    for e in mesh.product_elements:
        mat=int(materials[e-1,0])-1
        if counts[mat]!=1:raise RestartError('강체 속도 제거는 상수 밀도가 필요합니다.')
        nodes=kon[int(ipkon[e-1]):int(ipkon[e-1])+8]-1
        np.add.at(mass,nodes,brick_masses(co[nodes],rho[mat,0,1]))
    physical=np.array(sorted(r.product_labels(mesh)))-1
    if np.any(mass[physical]<0) or mass.sum()<=0:raise RestartError('제품 절점 질량 오류')
    return co,u,velocity,mass,physical


def assess_native_release(path,mesh):
    from .restart import NativeRestart
    r=NativeRestart.read(path);co,u,v,m,n=native_velocity_arrays(r,mesh)
    _,report=remove_rigid_velocity((co+u[:,1:4])[n],v[n,1:4],m[n])
    report['max_nodal_speed_mm_s']=float(np.linalg.norm(v[n,1:4],axis=1).max())
    report['total_time_s']=float(r.doubles('ttime')[0])
    report['note']='Energy diagnostics only; residual stress convergence must also be evaluated.'
    return report


def prepare_native_release(source,destination,mesh,alpha=20.):
    from .restart import NativeRestart,RestartError
    if not np.isfinite(alpha) or alpha<0:raise ValueError("감쇠 계수는 유한한 0 이상의 값이어야 합니다.")
    r=NativeRestart.read(source);before=list(r.records);history=r.history_hashes()
    if r.sizes['ntrans'] or 'veold' not in r.fields:raise RestartError('강체 속도 제거는 전역 좌표계 구조 동적 상태가 필요합니다.')
    co,u,velocity,mass,physical=native_velocity_arrays(r,mesh)
    residual,report=remove_rigid_velocity((co+u[:,1:4])[physical],velocity[physical,1:4],mass[physical])
    velocity[physical,1:4]=residual;r.replace('veold',velocity)
    damping=r.doubles('xmodal').copy();damping[:2]=[alpha,0.];r.replace('xmodal',damping)
    changed=[k for k,i in r.fields.items() if before[i]!=r.records[i]]
    if set(changed)-{'veold','xmodal'} or r.history_hashes()!=history:raise RestartError('안정화 전달 중 재료/형상 상태가 변경됐습니다.')
    r.write(destination)
    report.update(source=str(Path(source).resolve()),source_sha256=hashlib.sha256(Path(source).read_bytes()).hexdigest(),
                  prepared_state_sha256=state_hash(r),history_sha256=history,changed_records=changed)
    return report


def release_matches_upstream(source,incoming,folder):
    """Cache/recovery accepts a verified velocity projection, never arbitrary edits."""
    from .restart import NativeRestart,equivalent_except_restart_output
    try:
        source=Path(source);incoming=Path(incoming);audit=Path(folder)/'stabilization_transfer.json'
        if not audit.exists():return equivalent_except_restart_output(source,incoming)
        report=json.loads(audit.read_text());native=NativeRestart.read(incoming)
        return (report['source_sha256']==hashlib.sha256(source.read_bytes()).hexdigest()
                and report['prepared_state_sha256']==state_hash(native)
                and report['history_sha256']==native.history_hashes())
    except (OSError,ValueError,KeyError,TypeError):return False


def abaqus_dashpots(mesh,masses,alpha):
    """Grounded Standard dashpots implement C=alpha*M without material edits."""
    if alpha==0:return []
    lines=['** Stabilization only: grounded mass-proportional dashpots, N s/mm.']
    label=max(mesh.elements)+1000
    for node,mass in masses.items():
        for dof in (1,2,3):
            label+=1;group=f'STAB_D{label}'
            lines.extend([f'*ELEMENT, TYPE=DASHPOT1, ELSET={group}',f'{label}, {node}',
                          f'*DASHPOT, ELSET={group}',f'{dof}',f'{alpha*mass:.12g}'])
    return lines
