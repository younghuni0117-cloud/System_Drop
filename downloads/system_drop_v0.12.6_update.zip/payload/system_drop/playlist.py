"""Explicit result-file playlists; no solver execution or data interpolation."""
from pathlib import Path
from copy import deepcopy
import json
from .timeline import stage_info,read_json


def from_result_file(path):
    path=Path(path).resolve()
    if path.suffix.lower() in ('.frd','.odb'):
        path=path.parent/'results/frames.json'
        if not path.is_file():raise ValueError('변환된 결과 목록이 없습니다. 메인 GUI에서 결과 변환을 완료한 뒤 선택하세요.')
    if path.suffix.lower() not in ('.json','.vtu'):raise ValueError('frames.json, VTU 또는 변환 완료된 FRD/ODB를 선택하세요.')
    folder=path.parent.parent if path.parent.name=='results' else path.parent
    stage=stage_info(folder)
    if path.suffix.lower()=='.json':
        records=read_json(path)
        if not isinstance(records,list) or not records:raise ValueError('비어 있거나 잘못된 프레임 목록입니다.')
        records=deepcopy(records)
        for record in records:
            record['file']=str((path.parent/record['file']).resolve())
            float(record['time'])
            if not Path(record['file']).is_file():raise ValueError('프레임 파일이 없습니다: '+record['file'])
    else:
        if not path.is_file():raise ValueError('VTU 파일이 없습니다.')
        source=next((r for r in stage['records'] if (folder/'results'/r['file']).resolve()==path),{})
        records=[{**source,'file':str(path),'time':source.get('time',0.)}]
        stage['title']+=' · '+path.name
    stage.update(records=records,playlist_id=str(path),playlist_only=True,source_file=str(path))
    return stage


def edit_playlist(parent,stages,add_files=False):
    from PySide6 import QtWidgets as W,QtCore
    dialog=W.QDialog(parent);dialog.setWindowTitle('재생 목록 · 파일 선택 및 순서');dialog.resize(740,480)
    layout=W.QVBoxLayout(dialog);layout.addWidget(W.QLabel('체크한 결과를 표시 순서대로 연속재생합니다. 항목을 드래그해서 순서를 바꿀 수 있습니다.'))
    listing=W.QListWidget();listing.setDragDropMode(W.QAbstractItemView.DragDropMode.InternalMove);layout.addWidget(listing,1)
    def append(stage):
        item=W.QListWidgetItem(stage['title']+'  |  '+stage.get('source_file',stage['folder']),listing)
        item.setData(QtCore.Qt.ItemDataRole.UserRole,deepcopy(stage));item.setFlags(item.flags()|QtCore.Qt.ItemFlag.ItemIsUserCheckable)
        item.setCheckState(QtCore.Qt.CheckState.Checked)
    for stage in stages:append(stage)
    actions=W.QHBoxLayout();layout.addLayout(actions)
    def add():
        paths,_=W.QFileDialog.getOpenFileNames(dialog,'재생할 결과 파일 선택',str(Path(stages[0]['folder']).parent) if stages else '',
                  '해석 결과 (frames.json *.vtu *.frd *.odb);;프레임 목록 (*.json);;모든 파일 (*)')
        failures=[]
        for path in paths:
            try:append(from_result_file(path))
            except (ValueError,OSError,KeyError,TypeError) as exc:failures.append(Path(path).name+': '+str(exc))
        if failures:W.QMessageBox.information(dialog,'결과 파일 확인','\n'.join(failures))
    def mark(drop_only):
        for i in range(listing.count()):
            item=listing.item(i);stage=item.data(QtCore.Qt.ItemDataRole.UserRole)
            item.setCheckState(QtCore.Qt.CheckState.Checked if not drop_only or stage['phase']=='drop' else QtCore.Qt.CheckState.Unchecked)
    for label,action in [('파일 추가',add),('선택 제거',lambda:listing.takeItem(listing.currentRow())),
                         ('드랍만 선택',lambda:mark(True)),('전체 선택',lambda:mark(False))]:
        button=W.QPushButton(label);button.clicked.connect(action);actions.addWidget(button)
    buttons=W.QDialogButtonBox(W.QDialogButtonBox.StandardButton.Ok|W.QDialogButtonBox.StandardButton.Cancel)
    buttons.button(W.QDialogButtonBox.StandardButton.Ok).setText('목록 적용');buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
    if add_files:QtCore.QTimer.singleShot(0,add)
    if dialog.exec()!=W.QDialog.DialogCode.Accepted:return None
    result=[]
    for i in range(listing.count()):
        item=listing.item(i)
        if item.checkState()==QtCore.Qt.CheckState.Checked:
            stage=item.data(QtCore.Qt.ItemDataRole.UserRole);stage.update(playlist_id=f'playlist_{i}',playlist_only=True);result.append(stage)
    return result
