"""CalculiX 2.23 native restart adapter for repeated impacts.

Schema: upstream ccx_2.23/src/restartwrite.f (bundled source archive).
Only floor reference coordinates and next-drop nodal velocities are edited.
Product reference coordinates, displacement, stress, strain, plastic state,
material data, topology, constraints and accumulated time remain native bytes.
Unsupported versions/ABI/layouts fail closed before a solver is started.
"""
from __future__ import annotations

from pathlib import Path
import hashlib
import struct
import numpy as np


class RestartError(ValueError):
    pass


class NativeRestart:
    def __init__(self, payloads):
        self.records = list(payloads)
        self.fields = {}
        self.sizes = {}
        self.cursor = 0
        self._schema()

    @classmethod
    def read(cls, path):
        raw = Path(path).read_bytes()
        records = []
        pos = 0
        while pos < len(raw):
            if pos + 8 > len(raw): raise RestartError('CalculiX restart record is truncated.')
            size = struct.unpack_from('<i', raw, pos)[0]
            if size < 0 or pos + size + 8 > len(raw):
                raise RestartError('Unsupported CalculiX restart ABI (requires little-endian 4-byte records).')
            end = pos + 4 + size
            if struct.unpack_from('<i', raw, end)[0] != size:
                raise RestartError('CalculiX restart record markers do not match.')
            records.append(raw[pos+4:end])
            pos = end + 4
        # A .rout can contain several complete step snapshots. The latest wins,
        # exactly as *RESTART, READ without STEP= does in the upstream reader.
        starts = [i for i, r in enumerate(records) if len(r) == 80 and r.startswith(b'Version ')]
        if not starts: raise RestartError('CalculiX native restart version record is missing.')
        return cls(records[starts[-1]:])

    def take(self, name, size):
        if self.cursor >= len(self.records) or len(self.records[self.cursor]) != size:
            actual = len(self.records[self.cursor]) if self.cursor < len(self.records) else 'EOF'
            raise RestartError(f'Unsupported/corrupt CalculiX restart layout at {name}: {actual} != {size}.')
        self.fields[name] = self.cursor
        self.cursor += 1
        return self.records[self.cursor-1]

    def integer(self, name):
        value = struct.unpack('<i', self.take(name, 4))[0]
        self.sizes[name] = value
        return value

    def array(self, name, count, width=8):
        return self.take(name, int(count)*width)

    def ints(self, name):
        return np.frombuffer(self.records[self.fields[name]], dtype='<i4')

    def doubles(self, name):
        return np.frombuffer(self.records[self.fields[name]], dtype='<f8')

    def replace(self, name, values):
        original = self.records[self.fields[name]]
        payload = np.asarray(values, dtype='<f8').tobytes()
        if len(payload) != len(original) or not np.isfinite(values).all():
            raise RestartError(f'Invalid replacement restart field: {name}')
        self.records[self.fields[name]] = payload

    def _schema(self):
        version = self.take('version', 80).decode('ascii').strip()
        if version != 'Version 2.23':
            raise RestartError(f'누적 연결은 CalculiX 2.23 native restart가 필요합니다: {version}')
        prefix = ('step nset nalset nload nbody nforc nboun nflow nk ne nef nkon').split()
        for key in prefix: self.integer(key)
        mi = self.array('mi', 3, 4)
        self.mi = struct.unpack('<3i', mi)
        for key in ('nmpc mpcend maxlenmpc memmpc nfc ndc nmat ntmat npmat ncmat ndmat nprop '
                    'norien ntrans nam namtot nprint nlabel ntie ncs mcs ne1d ne2d').split(): self.integer(key)
        self.infree = struct.unpack('<4i', self.array('infree', 4, 4))
        self.integer('nmethod')
        self.iperturb = struct.unpack('<2i', self.array('iperturb', 2, 4))
        for key in 'nener iplas ithermal nstate nslavs iprestr mortar'.split(): self.integer(key)
        s = self.sizes
        if s['mortar'] == 1:
            self.integer('ifacecount'); self.integer('nintpoint')
        self.integer('nheading'); self.integer('network')
        self.array('set', s['nset'], 81)
        self.array('istartset', s['nset'], 4); self.array('iendset', s['nset'], 4)
        # Upstream deliberately writes one Fortran record per ialset entry.
        labels = [struct.unpack('<i', self.take(f'ialset_{i}', 4))[0] for i in range(s['nalset'])]
        self.labels = np.asarray(labels)
        self.array('heading', s['nheading'], 66)
        self.array('co', 3*s['nk'])
        self.array('kon', s['nkon'], 4); self.array('ipkon', s['ne'], 4); self.array('lakon', s['ne'], 8)
        for key, width in [('nodeboun',4),('ndirboun',4),('typeboun',1),('xboun',8),('ikboun',4),('ilboun',4)]:
            self.array(key, s['nboun'], width)
        if s['nam']: self.array('iamboun', s['nboun'], 4)
        for key, width in [('nodebounold',4),('ndirbounold',4),('xbounold',8)]: self.array(key,s['nboun'],width)
        for key, width in [('ipompc',4),('labmpc',20),('ikmpc',4),('ilmpc',4),('fmpc',8)]: self.array(key,s['nmpc'],width)
        self.array('nodempc',3*s['mpcend'],4); self.array('coefmpc',s['mpcend'])
        if s['nfc']:
            self.array('coeffc',7*s['nfc']); self.array('ikdc',s['ndc'],4); self.array('edc',12*s['ndc'])
        self.array('nodeforc',2*s['nforc'],4)
        for key,width in [('ndirforc',4),('xforc',8),('ikforc',4),('ilforc',4)]: self.array(key,s['nforc'],width)
        if s['nam']: self.array('iamforc',s['nforc'],4)
        self.array('xforcold',s['nforc'])
        self.array('nelemload',2*s['nload'],4); self.array('sideload',s['nload'],20); self.array('xload',2*s['nload'])
        if s['nam']: self.array('iamload',2*s['nload'],4)
        self.array('xloadold',2*s['nload']); self.array('cbody',s['nbody'],81)
        self.array('ibody',3*s['nbody'],4); self.array('xbody',7*s['nbody']); self.array('xbodyold',7*s['nbody'])
        ng = self.mi[0]*s['ne']
        if s['iprestr']: self.array('prestr',6*ng)
        self.array('prlab',s['nprint'],6); self.array('prset',s['nprint'],81); self.array('filab',s['nlabel'],87)
        self.array('elcon',(s['ncmat']+1)*s['ntmat']*s['nmat']); self.array('nelcon',2*s['nmat'],4)
        if s['ndmat']:
            self.array('dmcon',(s['ndmat']+1)*s['ntmat']*s['nmat']);self.array('ndmcon',2*s['nmat'],4);self.array('dam',ng)
        for key,mul,width in [('rhcon',2*s['ntmat'],8),('nrhcon',1,4),('shcon',4*s['ntmat'],8),('nshcon',1,4),
                              ('cocon',7*s['ntmat'],8),('ncocon',2,4),('alcon',7*s['ntmat'],8),('nalcon',2,4),('alzero',1,8)]:
            self.array(key,mul*s['nmat'],width)
        self.array('physcon',14); self.array('xmodal',11)
        nevdamp = int(self.doubles('xmodal')[10])
        if nevdamp: self.array('xmodal_damping',nevdamp)
        if s['npmat']:
            for key,mul,width in [('plicon',(2*s['npmat']+1)*s['ntmat'],8),('nplicon',s['ntmat']+1,4),
                                  ('plkcon',(2*s['npmat']+1)*s['ntmat'],8),('nplkcon',s['ntmat']+1,4)]:
                self.array(key,mul*s['nmat'],width)
        if s['norien']:
            self.array('orname',s['norien'],80);self.array('orab',7*s['norien']);self.array('ielorien',self.mi[2]*s['ne'],4)
        if s['nprop']: self.array('ielprop',s['ne'],4);self.array('prop',s['nprop'])
        if s['ntrans']: self.array('trab',7*s['ntrans']);self.array('inotr',2*s['nk'],4)
        if s['nam']:
            self.array('amname',s['nam'],80);self.array('namta',3*s['nam']-1,4)
            end = self.integer('namta_end');self.array('amta',2*int(self.ints('namta')[-1]))
        if s['ithermal']:
            self.array('t0',s['nk']);self.array('t1',s['nk'])
            if s['ne1d'] or s['ne2d']:self.array('t0g',2*s['nk']);self.array('t1g',2*s['nk'])
            if s['nam']:self.array('iamt1',s['nk'],4)
            self.array('t1old',s['nk'])
        self.array('matname',s['nmat'],80);self.array('ielmat',self.mi[2]*s['ne'],4)
        self.array('vold',(self.mi[1]+1)*s['nk'])
        if s['nmethod']==4 or (s['nmethod']==1 and self.iperturb[0]>=2):self.array('veold',(self.mi[1]+1)*s['nk'])
        if s['nef']:
            for key in ('vel','velo','veloo'):self.array(key,8*s['nef'])
        if s['ne1d'] or s['ne2d']:
            self.array('iponor',2*s['nkon'],4);self.array('xnor',self.infree[0]);self.array('knor',self.infree[1],4)
            self.array('thicke',self.mi[2]*s['nkon']);self.array('offset',2*s['ne'])
            self.array('iponoel',self.infree[3],4);self.array('inoel',3*(self.infree[2]-1),4)
            self.array('rig',self.infree[3],4);self.array('ne2boun',2*self.infree[3],4)
        if s['ntie']:self.array('tieset',3*s['ntie'],81);self.array('tietol',4*s['ntie'])
        if s['ncs']:self.array('ics',s['ncs'],4)
        if s['mcs']:self.array('cs',17*s['mcs'])
        self.array('sti',6*ng);self.array('eme',6*ng)
        if s['nener']:self.array('ener',2*self.mi[0]*(s['ne']+(s['nslavs'] if s['mortar']!=1 else 0)))
        if s['nstate']:self.array('xstate',s['nstate']*self.mi[0]*(s['ne']+(s['nslavs'] if s['mortar']!=1 else s['nintpoint'])))
        if s['mortar']==1:
            self.array('islavsurf',2*s['ifacecount']+2,4);self.array('pslavsurf',3*s['nintpoint']);self.array('clearini',27*s['ifacecount'])
        self.array('ctrl',52);self.array('qaold',2);self.array('output',1,4);self.array('ttime',1);self.array('irstrt',2,4)
        if self.cursor != len(self.records):raise RestartError('Unexpected data after CalculiX restart snapshot.')

    def nset(self, name):
        names = self.records[self.fields['set']]
        names = [names[i:i+81].decode('ascii').rstrip() for i in range(0,len(names),81)]
        # CCX stores a trailing N to distinguish node sets from element sets.
        target = name.upper()+'N'
        if target not in names:raise RestartError(f'Restart node set is missing: {name}')
        i=names.index(target)
        values=self.labels[self.ints('istartset')[i]-1:self.ints('iendset')[i]]
        result=[]
        for v in values:
            if v>0:result.append(int(v))
            else:
                first,last=result[-2:];result=result[:-2]+list(range(first,last+1,-int(v)))
        return result

    def write(self,path):
        path=Path(path);tmp=path.with_suffix('.tmp')
        with tmp.open('wb') as stream:
            for payload in self.records:
                marker=struct.pack('<i',len(payload));stream.write(marker);stream.write(payload);stream.write(marker)
        tmp.replace(path)

    def physical_coordinates(self, labels):
        co=self.doubles('co').reshape(-1,3)
        u=self.doubles('vold').reshape(-1,self.mi[1]+1)
        return {n:(co[n-1]+u[n-1,1:4]).tolist() for n in labels}

    def product_labels(self,mesh):
        """Original nodes plus physical corners of CCX-expanded shell elements."""
        physical=set(mesh.product_nodes)
        ipkon=self.ints('ipkon');kon=self.ints('kon');lakon=self.records[self.fields['lakon']]
        for e in mesh.product_elements:
            if mesh.elements[e][0] not in ('C3D8','S4'):
                raise RestartError('CalculiX 누적 연결 검증 요소는 C3D8/S4입니다.')
            start=int(ipkon[e-1]);kind=lakon[(e-1)*8:e*8].decode('ascii')
            if start<0 or not kind.startswith('C3D8'):
                raise RestartError(f'Unexpected expanded element {e}: {kind}')
            physical.update(int(n) for n in kon[start:start+8])
        if not physical or min(physical)<1 or max(physical)>self.sizes['nk']:
            raise RestartError('Invalid product node partition in restart.')
        return physical

    def history_hashes(self):
        return {k:hashlib.sha256(self.records[self.fields[k]]).hexdigest()
                for k in ('sti','eme','xstate','ener','dam','plicon','plkcon') if k in self.fields}


def prepare_next_impact(source, destination, mesh, surface, velocity):
    """Reposition the inactive rigid floor and assign a new launch velocity.

    A native snapshot is required; JSON/FRD never reconstruct constitutive state.
    Shell-expanded physical nodes receive the same translational velocity. C3D8I
    incompatible-mode nodes and rigid-body rotational/dummy DOFs receive zero.
    """
    r=NativeRestart.read(source)
    if 'veold' not in r.fields or r.sizes['nef'] or r.sizes['ntrans']:
        raise RestartError('누적 드랍은 구조 동적 재시작과 전역 제품 좌표계를 필요로 합니다.')
    before=list(r.records); history=r.history_hashes()
    for key in ('co','vold','veold','sti','eme','xstate'):
        if key in r.fields and not np.isfinite(r.doubles(key)).all():
            raise RestartError(f'이전 native 상태에 유한하지 않은 값이 있습니다: {key}')
    floor=r.nset('FLOOR_NODES');ref=r.nset('FLOOR_REF');rot=r.nset('FLOOR_ROT')
    if len(floor)!=8 or len(ref)!=1 or len(rot)!=1:
        raise RestartError('CalculiX 누적 바닥은 템플릿의 C3D8 강체 바닥(8 nodes)이 필요합니다.')
    co=r.doubles('co').reshape(-1,3).copy()
    u=r.doubles('vold').reshape(-1,r.mi[1]+1)
    floor_all=np.asarray(floor+ref+rot)-1
    if not np.allclose(u[floor_all,1:4],0,atol=1e-12):
        raise RestartError('고정 강체 바닥에 예상하지 못한 변위가 있습니다.')
    surface=np.asarray(surface,dtype=float);velocity=np.asarray(velocity,dtype=float)
    if surface.shape!=(4,3) or velocity.shape!=(3,):raise RestartError('Invalid floor/velocity geometry.')
    d=-np.cross(surface[1]-surface[0],surface[2]-surface[1]);d/=np.linalg.norm(d)
    co[np.asarray(floor)-1]=np.vstack((surface+10*d,surface))
    co[ref[0]-1]=surface.mean(axis=0);co[rot[0]-1]=0
    # Supported original element types are deliberately checked. Internal shell
    # expansion C3D8I L is handled without launching its incompatible-mode DOFs.
    physical=r.product_labels(mesh)
    if not physical or min(physical)<1 or max(physical)>r.sizes['nk'] or physical.intersection(floor+ref+rot):
        raise RestartError('Invalid product/floor partition in restart.')
    v=np.zeros_like(u);v[:,0]=r.doubles('veold').reshape(u.shape)[:,0]
    v[np.asarray(sorted(physical))-1,1:4]=velocity
    r.replace('co',co);r.replace('veold',v)
    product_rows=np.asarray(sorted(mesh.product_nodes))-1
    if not np.array_equal(co[product_rows],np.frombuffer(before[r.fields['co']],dtype='<f8').reshape(-1,3)[product_rows]):
        raise RestartError('Product reference coordinates changed during transfer.')
    changed=[k for k,i in r.fields.items() if before[i]!=r.records[i]]
    if set(changed)-{'co','veold'} or history!=r.history_hashes():
        raise RestartError('Native material history changed while preparing next drop.')
    r.write(destination)
    return {'solver_version':'2.23','source':str(Path(source).resolve()),
            'source_file_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest(),
            'source_step':r.sizes['step'],'source_total_time':float(r.doubles('ttime')[0]),
            'native_material_history_preserved':True,'changed_records':changed,
            'history_sha256':history,'product_velocity_nodes':len(physical),
            'velocity':velocity.tolist(),'floor_nodes':floor,'floor_ref':ref,'floor_rot':rot}


def disable_restart_overlay(path):
    """Clear only the persisted restart-output flag, never physical history."""
    r=NativeRestart.read(path);flags=r.ints('irstrt').copy()
    if not flags[1]:return False
    before=r.history_hashes();flags[1]=0
    r.records[r.fields['irstrt']]=np.asarray(flags,dtype='<i4').tobytes()
    assert r.history_hashes()==before
    r.write(path);return True


def equivalent_except_restart_output(first,second):
    """Native READ snapshots may differ only in the I/O mode flag."""
    try:
        a=NativeRestart.read(first);b=NativeRestart.read(second)
        return (a.fields.keys()==b.fields.keys() and all(a.records[i]==b.records[b.fields[key]]
                for key,i in a.fields.items() if key!='irstrt'))
    except (OSError,ValueError):return False
