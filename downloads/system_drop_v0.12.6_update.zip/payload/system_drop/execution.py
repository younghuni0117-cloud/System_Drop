"""Solver child environment and local native-crash diagnostics."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,platform,shutil
from . import __version__
from .monitor import tail_text,dat_time,stable_increment


def solver_environment(settings,args,environ=None):
    env=dict(os.environ if environ is None else environ)
    env['OMP_NUM_THREADS']=str(settings.cpus);env['NUMBER_OF_CPUS']=str(settings.cpus)
    env['GFORTRAN_UNBUFFERED_ALL']='1'
    env['PATH']=str(Path(args[0]).parent)+os.pathsep+env.get('PATH','')
    if settings.solver=='calculix':
        # Match the bundled CalculiXWindowsEnvironment.bat. Its build/tests
        # require serial stiffness assembly to avoid multithread convergence issues.
        env['CCX_NPROC_STIFFNESS']='1'
        env['CCX_NPROC_RESULTS']=str(settings.cpus)
        env['PRINTF_EXPONENT_DIGITS']='2'
    return env


def exit_description(code):
    status=int(code)&0xffffffff
    name={0xc0000005:'Windows 접근 위반 (EXCEPTION_ACCESS_VIOLATION)',
          0xc0000017:'Windows 메모리 할당 실패 (STATUS_NO_MEMORY)',
          0xc00000fd:'Windows 스택 오버플로 (STATUS_STACK_OVERFLOW)',
          0xc000001d:'Windows 지원하지 않는 명령 (STATUS_ILLEGAL_INSTRUCTION)',
          0xc0000135:'Windows DLL 누락 (STATUS_DLL_NOT_FOUND)'}.get(status)
    return f'{name}, 0x{status:08X}' if name else f'종료 코드 {code}'


def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


def write_failure_report(folder,settings,stage,args,env,code,telemetry=None):
    folder=Path(folder)
    watched=('OMP_NUM_THREADS','NUMBER_OF_CPUS','CCX_NPROC_RESULTS','CCX_NPROC_STIFFNESS','PRINTF_EXPONENT_DIGITS')
    sizes={name:(folder/name).stat().st_size for name in ('solver.log','job.sta','job.dat','job.frd','job.rout','job.rin') if (folder/name).is_file()}
    inputs={}
    for path in sorted(folder.rglob('*.inp')):
        relative=path.relative_to(folder)
        if any(part.startswith('previous_attempt_') for part in relative.parts):continue
        if len(inputs)>=100:break
        inputs[relative.as_posix()]={'bytes':path.stat().st_size,'sha256':file_hash(path)}
    log=tail_text(folder/'solver.log');dat=tail_text(folder/'job.dat')
    params={name:getattr(settings,name) for name in ('solver','cpus','height','gap','drop_dt','drop_max_dt','drop_time','release_dt','release_max_dt','release_time','release_damping','directions')}
    space=shutil.disk_usage(folder)
    executable=Path(args[0]);binaries={}
    if settings.solver=='calculix' and executable.is_file():
        for path in [executable,*sorted(executable.parent.glob('*.dll'))[:32]]:
            binaries[path.name]={'bytes':path.stat().st_size,'sha256':file_hash(path)}
    report={'manager_version':__version__,'created_utc':datetime.now(timezone.utc).isoformat(),
            'platform':platform.platform(),'stage':stage,'return_code':code,'exit_description':exit_description(code),
            'command':list(map(str,args)),'settings':params,'thread_environment':{k:env[k] for k in watched if k in env},
            'solver_binary_hashes':binaries,
            'disk_free_bytes':space.free,'file_sizes':sizes,'input_hashes':inputs,
            'last_dat_time_s':dat_time(dat),'last_stable_increment_s':stable_increment(log),
            'last_telemetry':telemetry,'solver_log_tail':log[-16384:],
            'note':'A native access violation does not by itself prove an input, RAM or time-step problem. Original outputs are preserved. No automatic rerun.'}
    path=folder/'solver_failure_report.json'
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return path
