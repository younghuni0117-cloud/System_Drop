"""Completed-result timeline and display-only coordinate transforms.

No deformation or stress values are interpolated. Optional direction transitions
reuse the last completed stabilization state with a labeled camera-space rotation.
"""
from pathlib import Path
import json,re
import numpy as np
from .model import NAMES


def read_json(path,default=None):
    try:return json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError,ValueError):return default


def run_root(folder):
    folder=Path(folder).resolve()
    for candidate in (folder,folder.parent):
        if ((candidate/'settings.json').is_file() and (candidate/'checkpoint.json').is_file()) or (candidate/'sequence.json').is_file():return candidate
    return None


def stage_info(folder,settings=None):
    folder=Path(folder);match=re.fullmatch(r'(drop|release)_(\d+)',folder.name)
    phase=match[1] if match else 'result';number=int(match[2]) if match else 1
    drop=folder.parent/f'drop_{number:02d}' if match else folder
    metadata=read_json(drop/'setup.json',{})
    records=read_json(folder/'results/frames.json',[])
    directions=(settings or {}).get('directions',[])
    name=NAMES[directions[number-1]-1] if number<=len(directions) else metadata.get('direction_name','')
    title=f'{number:02d} {name} · '+({'drop':'드랍해석','release':'안정화해석'}.get(phase,'결과'))
    return {'folder':str(folder.resolve()),'phase':phase,'number':number,'drop_folder':str(drop.resolve()),
            'metadata':metadata,'records':records,'title':title}


def collect_stages(folder,sequence=True,include_release=True):
    folder=Path(folder);root=run_root(folder)
    if not sequence or root is None:
        stage=stage_info(folder,read_json(root/'settings.json',{}) if root else {})
        return [stage] if stage['records'] else []
    manifest=read_json(root/'sequence.json',{})
    if manifest:
        result=[]
        for entry in manifest.get('stages',[]):
            stage=stage_info(root/entry['folder'],manifest)
            if stage['records'] and (include_release or stage['phase']!='release'):result.append(stage)
        return result
    settings=read_json(root/'settings.json',{});checkpoint=read_json(root/'checkpoint.json',{})
    result=[]
    for i,row in enumerate(checkpoint.get('records',[]),1):
        for phase in ('drop','release'):
            if row.get(phase)!='done' or (phase=='release' and not include_release):continue
            stage=stage_info(root/f'{phase}_{i:02d}',settings)
            if stage['records']:result.append(stage)
    return result


def build_records(stages,transition_frames=0):
    result=[];previous=None
    for stage in stages:
        if previous and stage['phase']=='drop' and stage['folder']!=previous['folder'] and transition_frames:
            # Even if stabilization is hidden from playback, use its actual last
            # state for the direction transition whenever a completed one exists.
            root=Path(previous['folder']).parent
            release=root/f'release_{previous["number"]:02d}'
            candidate=stage_info(release)
            checkpoint=read_json(root/'checkpoint.json',{})
            rows=checkpoint.get('records',[])
            manifest=read_json(root/'sequence.json',{})
            complete=(previous['number']<=len(rows) and rows[previous['number']-1].get('release')=='done') or any(e.get('folder')==release.name for e in manifest.get('stages',[]))
            if candidate['records'] and complete and not previous.get('playlist_only'):
                source=candidate
            else:source=previous
            source_record=source['records'][-1]
            for j in range(transition_frames):
                result.append({**source_record,'stage':source,'transition_to':stage,
                               'alpha':(j+1)/(transition_frames+1),'kind':'transition'})
        result.extend({**record,'stage':stage,'kind':'result'} for record in stage['records'])
        previous=stage
    return result


def record_key(record):
    return (record['stage'].get('playlist_id',record['stage']['folder']),record['file'],record.get('kind','result'),
            record.get('transition_to',{}).get('folder'),record.get('alpha'))


def floor_basis(metadata):
    points=np.asarray(metadata.get('floor',[]),dtype=float)
    if points.shape!=(4,3):return np.eye(3),np.zeros(3),None
    x=points[1]-points[0];x/=np.linalg.norm(x)
    y=np.cross(points[1]-points[0],points[2]-points[1]);y/=np.linalg.norm(y)
    z=np.cross(x,y);z/=np.linalg.norm(z)
    return np.column_stack((x,y,z)),points.mean(axis=0),points


def matrix_quaternion(r):
    trace=np.trace(r)
    if trace>0:
        s=np.sqrt(trace+1)*2
        q=[.25*s,(r[2,1]-r[1,2])/s,(r[0,2]-r[2,0])/s,(r[1,0]-r[0,1])/s]
    else:
        i=int(np.argmax(np.diag(r)));j=(i+1)%3;k=(i+2)%3
        s=np.sqrt(1+r[i,i]-r[j,j]-r[k,k])*2
        q=[(r[k,j]-r[j,k])/s,0.,0.,0.]
        q[i+1]=.25*s;q[j+1]=(r[j,i]+r[i,j])/s;q[k+1]=(r[k,i]+r[i,k])/s
    return np.array(q)/np.linalg.norm(q)


def rotation_between(a,b,t):
    q0=matrix_quaternion(a);q1=matrix_quaternion(b);dot=float(np.dot(q0,q1))
    if dot<0:q1=-q1;dot=-dot
    if dot>.9995:q=(1-t)*q0+t*q1
    else:
        angle=np.arccos(np.clip(dot,-1,1));q=(np.sin((1-t)*angle)*q0+np.sin(t*angle)*q1)/np.sin(angle)
    w,x,y,z=q/np.linalg.norm(q)
    return np.array([[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],
                     [2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],
                     [2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]])


def center(points):return (np.asarray(points).min(axis=0)+np.asarray(points).max(axis=0))*.5


def display_transform(points,record,mode='center',release_height=None,floor_span=None):
    """Return displayed points, floor and affine (R, offset), row-vector form."""
    points=np.asarray(points);stage=record['stage'];r,anchor,floor=floor_basis(stage.get('metadata',{}));c=center(points)
    if mode=='raw':r=np.eye(3);offset=np.zeros(3)
    elif mode=='center':
        r=np.eye(3);offset=-c
        if record.get('kind')=='transition':
            target=record['transition_to'];r1,anchor1,floor1=floor_basis(target.get('metadata',{}))
            r0,anchor0,floor0=floor_basis(stage.get('metadata',{}));alpha=record['alpha']
            if floor0 is not None and floor1 is not None:
                next_center=np.asarray(target.get('metadata',{}).get('center',c))
                local=(1-alpha)*((floor0-anchor0)@r0)+alpha*((floor1-anchor1)@r1)
                rotation=rotation_between(r0,r1,alpha);direction=-rotation[:,1]
                centered=points-c
                gap0=max(0.,float((anchor0-c)@(-r0[:,1])-np.max(centered@(-r0[:,1]))))
                gap1=max(float(target.get('metadata',{}).get('gap',.001)),0.000001)
                linear=(1-alpha)*(anchor0-c)+alpha*(anchor1-next_center)
                tangent=linear-(linear@direction)*direction
                mid=tangent+direction*(float(np.max(centered@direction))+(1-alpha)*gap0+alpha*gap1)
                floor=local@rotation.T+mid
                return points-c,floor,r,offset
    elif record.get('kind')=='transition':
        target=record['transition_to'];r1,anchor1,_=floor_basis(target.get('metadata',{}))
        r=rotation_between(r,r1,record['alpha'])
        rotated=(points-c)@r
        height=max(-float(rotated[:,1].min())+float(target.get('metadata',{}).get('gap',.001)),.001)
        offset=-c@r+np.array([0,height,0])
    else:
        offset=-anchor@r
        transformed=points@r+offset;mid=center(transformed)
        # Lateral drift is removed to keep the specimen horizontally centered.
        offset-=np.array([mid[0],0,mid[2]])
        if stage['phase']=='release' and release_height is not None:
            offset[1]+=release_height-mid[1]
    displayed=points@r+offset
    if mode=='floor' and floor is not None:
        span=float(floor_span or max(np.linalg.norm(floor[1]-floor[0]),np.linalg.norm(floor[2]-floor[1]))/2)
        floor=np.array([[-span,0,-span],[span,0,-span],[span,0,span],[-span,0,span]])
    elif floor is not None:floor=floor@r+offset
    return displayed,floor,r,offset
