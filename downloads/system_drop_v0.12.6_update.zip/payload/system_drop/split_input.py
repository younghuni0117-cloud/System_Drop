"""Keep Abaqus run decks as main/material/mesh includes; retain old-run support."""
from pathlib import Path
from .assembly import blocks,card
from .inp_format import format_inp


def execution_input(folder,solver):
    folder=Path(folder)
    if solver=='abaqus' and not (folder/'job.inp').exists() and (folder/'abaqus_main.inp').exists():return folder/'abaqus_main.inp'
    return folder/'job.inp'


def publish_abaqus_input(folder):
    folder=Path(folder);staging=folder/'job.inp';text=staging.read_text(encoding='utf-8-sig')
    if any(card(b)=='*IMPORT' for b in blocks(text.splitlines())):
        mesh=[];main=[];in_step=False
        geometry={'*IMPORT','*NODE','*ELEMENT','*NSET','*ELSET','*SURFACE'}
        for block in blocks(text.splitlines()):
            c=card(block)
            if c=='*STEP':in_step=True
            (mesh if not in_step and c in geometry else main).extend(block)
        # Material/section state belongs to the imported native model. Do not
        # redefine it, or redefine imported nodes/elements in the mesh include.
        (folder/'abaqus_material.inp').write_text('** Material and section history retained by *IMPORT, STATE=YES.\n** No material redefinition is required for this continuation.\n',encoding='utf-8')
        (folder/'abaqus_mesh.inp').write_text(format_inp('\n'.join(mesh)+'\n'),encoding='utf-8')
        # Keep HEADING and its data first; include import/sets before main model properties.
        head=next((i for i,l in enumerate(main) if l.strip().startswith('*') and not l.strip().startswith('**') and l.strip().upper()!='*HEADING'),len(main))
        main[head:head]=['*INCLUDE, INPUT=abaqus_material.inp','*INCLUDE, INPUT=abaqus_mesh.inp']
        text='\n'.join(main)+'\n'
    (folder/'abaqus_main.inp').write_text(format_inp(text),encoding='utf-8')
    staging.unlink()
    return folder/'abaqus_main.inp'
