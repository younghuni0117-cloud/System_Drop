"""Fixed-floor thumbnails; the solver still uses the product's current pose."""
import numpy as np
from PySide6 import QtCore,QtGui
from .model import drop_direction


def schematic_geometry(direction,angle=30):
    d=drop_direction(direction,edge_angle=angle)
    down=np.array([0.,-1.,0.]);c=float(np.dot(d,down))
    if c<-1+1e-10:r=np.diag([1.,-1.,-1.])
    elif c>1-1e-10:r=np.eye(3)
    else:
        v=np.cross(d,down)
        k=np.array([[0,-v[2],v[1]],[v[2],0,-v[0]],[-v[1],v[0],0]])
        r=np.eye(3)+k+k@k/(1+c)
    # A floor-normal yaw leaves the physical drop/plane angle unchanged. Avoid
    # looking exactly along the broad face on diagonal and edge thumbnails.
    camera=np.array([1.25,1.1,1.6]);camera/=np.linalg.norm(camera)
    visibility=.55 if direction in (7,8,9,10) else .32
    if direction>=7 and abs(r[:,1]@camera)<visibility:
        for degrees in (30,-30,60,-60,90,-90):
            a=np.radians(degrees);co,si=np.cos(a),np.sin(a)
            yaw=np.array([[co,0,si],[0,1,0],[-si,0,co]])
            if abs((yaw@r)[:,1]@camera)>=visibility:r=yaw@r;break
    body=np.array([[x,y,z] for y in (-8/152,8/152) for z in (-106/152,106/152) for x in (-1,1)])@r.T
    shift=np.array([0.,-.64-float(body[:,1].min()),0.])
    body+=shift
    floor=np.array([[-1.25,-.72,-.95],[1.25,-.72,-.95],[1.25,-.72,.95],[-1.25,-.72,.95]])
    logo=r@np.array([0.,8/152,0.])+shift  # Top-face center, retained for geometry callers.
    return body,floor,logo,r


def direction_icon(direction,angle=30):
    pix=QtGui.QPixmap(96,64);pix.fill(QtCore.Qt.GlobalColor.transparent)
    p=QtGui.QPainter(pix);p.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
    body,floor,logo,r=schematic_geometry(direction,angle)
    camera=np.array([1.25,1.1,1.6]);camera/=np.linalg.norm(camera)
    right=np.cross([0.,1.,0.],camera);right/=np.linalg.norm(right)
    up=np.cross(camera,right)
    def project(v):
        return QtCore.QPointF(48+20*(v@right),35-20*(v@up))
    plane=QtGui.QPolygonF([project(x) for x in floor])
    p.setPen(QtGui.QPen(QtGui.QColor('#ae8544'),1.2));p.setBrush(QtGui.QColor('#e0ba78'));p.drawPolygon(plane)
    # Exact cuboid face normals and one projection basis prevent back faces
    # being painted over front faces. Top/Bottom and Front/Rear have distinct tones.
    faces=[([0,2,3,1],[0,-1,0],'#738da5'),([4,5,7,6],[0,1,0],'#e4edf5'),
           ([0,1,5,4],[0,0,-1],'#728fa9'),([2,6,7,3],[0,0,1],'#bed9e7'),
           ([0,4,6,2],[-1,0,0],'#8da9bf'),([1,3,7,5],[1,0,0],'#a9c4d6')]
    visible=[f for f in faces if (r@np.array(f[1]))@camera>1e-8]
    visible.sort(key=lambda f:float(body[f[0]].mean(axis=0)@camera))
    for face,normal,color in visible:
        p.setBrush(QtGui.QColor(color));p.setPen(QtGui.QPen(QtGui.QColor('#526d84'),1.2))
        p.drawPolygon(QtGui.QPolygonF([project(body[i]) for i in face]))
    center=body.mean(axis=0)
    a=project(center+[0,.45,0]);b=project(center+[0,-.35,0])
    p.setPen(QtGui.QPen(QtGui.QColor('#c25249'),2.6));p.drawLine(a,b)
    p.setBrush(QtGui.QColor('#c25249'));p.drawPolygon(QtGui.QPolygonF([b,QtCore.QPointF(b.x()-3,b.y()-7),QtCore.QPointF(b.x()+3,b.y()-7)]))
    p.end();return QtGui.QIcon(pix)
