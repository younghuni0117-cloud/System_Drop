"""Launch a viewer against this installation, including with a reused Python."""
import sys
from .model import ROOT


def viewer_command(folder,*options):
    # -m depends on the child interpreter's search path. The absolute bootstrap
    # adds the current project first even if this Python lives in an older copy.
    return [sys.executable,str(ROOT/'bootstrap_windows.py'),'--viewer',str(folder),*options]
