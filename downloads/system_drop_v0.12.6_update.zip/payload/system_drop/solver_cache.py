"""Reuse completed native solver output when only postprocessing failed.

New runs record input/output digests. Legacy v0.5.1 runs need a success log,
nonempty FRD/native restart, and output timestamps after every input before
being adopted. Failed/incomplete or changed solver output is never reused.
"""
from pathlib import Path
import hashlib,json
from .solver import completed_successfully

RECEIPT='solver_completed.json'
OUTPUTS=('solver.log','job.frd','job.rout')


def digest(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):value.update(chunk)
    return value.hexdigest()


def inputs(folder):
    folder=Path(folder)
    paths=[p for p in folder.rglob('*.inp')
           if not any(part.startswith('previous_attempt_') for part in p.relative_to(folder).parts)]
    if (folder/'job.rin').is_file():paths.append(folder/'job.rin')
    return sorted(paths)


def fingerprints(folder,paths):
    folder=Path(folder)
    return {p.relative_to(folder).as_posix():digest(p) for p in paths}


def record_completion(folder,legacy=False,upstream=None,recovery=None):
    folder=Path(folder)
    report={'schema':1,'adopted_legacy_completion':legacy,
            'inputs':fingerprints(folder,inputs(folder)),
            'outputs':fingerprints(folder,[folder/n for n in OUTPUTS]),
            'upstream_native_sha256':digest(upstream) if upstream else None,'restart_recovery':recovery}
    target=folder/RECEIPT;tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps(report,indent=2),encoding='utf-8');tmp.replace(target)


def reusable_completion(folder,upstream=None):
    folder=Path(folder)
    if not (folder/'job.inp').is_file():return False
    if any(not (folder/n).is_file() or (folder/n).stat().st_size==0 for n in OUTPUTS):return False
    log_text=(folder/'solver.log').read_text(errors='replace')
    if not completed_successfully(folder,'calculix',log_text):
        from .restart_recovery import overlay_rename_error
        try:
            saved=json.loads((folder/RECEIPT).read_text())
            recovery=saved.get('restart_recovery') or {}
            if not (overlay_rename_error(log_text) and recovery.get('recovered') and recovery.get('native_sha256')==digest(folder/'job.rout')):return False
        except (ValueError,OSError,TypeError):return False
    if upstream:
        upstream=Path(upstream)
        if not upstream.is_file() or not (folder/'job.rin').is_file():return False
        if folder.name.startswith('release_'):
            if digest(upstream)!=digest(folder/'job.rin'):
                from .stabilization import release_matches_upstream
                if not release_matches_upstream(upstream,folder/'job.rin',folder):return False
        else:
            try:
                audit=json.loads((folder/'transfer.json').read_text())
                if 'source_file_sha256' in audit:
                    if audit['source_file_sha256']!=digest(upstream):return False
                elif upstream.stat().st_mtime_ns>(folder/'job.rin').stat().st_mtime_ns:return False
            except (OSError,ValueError,TypeError):return False
    saved=folder/RECEIPT
    if saved.exists():
        try:
            report=json.loads(saved.read_text())
            return (report['schema']==1 and report['inputs']==fingerprints(folder,inputs(folder))
                    and report['outputs']==fingerprints(folder,[folder/n for n in OUTPUTS])
                    and report.get('upstream_native_sha256')==(digest(upstream) if upstream else None))
        except (OSError,ValueError,KeyError,TypeError):return False
    latest_input=max(p.stat().st_mtime_ns for p in inputs(folder))
    if any((folder/n).stat().st_mtime_ns<latest_input for n in OUTPUTS):return False
    record_completion(folder,legacy=True,upstream=upstream)
    return True
