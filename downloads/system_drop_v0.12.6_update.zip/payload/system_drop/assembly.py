"""Flatten ordinary meshed Parts/Instances to a checked flat working deck.

Unknown global keywords pass through. Unsupported local coordinate/property
cards fail explicitly rather than silently losing their physical meaning.
"""
from collections import defaultdict
import re
import numpy as np
from .deck import keyword,tokens,logical_lines,id_lines


def blocks(lines):
    result=[];current=[]
    for line in logical_lines(lines):
        if line.strip().startswith('*') and not line.strip().startswith('**'):
            if current:result.append(current)
            current=[line]
        else:current.append(line)
    if current:result.append(current)
    return result


def card(block):return keyword(block[0])[0] if block and block[0].lstrip().startswith('*') and not block[0].lstrip().startswith('**') else ''
def data(block):return [line.strip() for line in block[1:] if line.strip() and not line.strip().startswith('**')]

def flatten_assembly(lines,return_mapping=False):
    from .deck import mesh_from_lines
    parts={};instances=[];outside=[];active=None;assembly=False;instance=None
    for block in blocks(lines):
        name=card(block);params=keyword(block[0])[1] if name else {}
        if name=='*PART':
            active=str(params['NAME']).upper();parts[active]=[]
        elif name=='*END PART':active=None
        elif active is not None:parts[active].append(block)
        elif name=='*ASSEMBLY':assembly=True
        elif name=='*END ASSEMBLY':assembly=False
        elif name=='*INSTANCE':
            if 'PART' not in params:raise ValueError('독립 orphan INSTANCE는 지원하지 않습니다. PART가 있는 메쉬 인스턴스로 내보내세요.')
            instance={'name':str(params['NAME']).upper(),'part':str(params['PART']).upper(),'placement':data(block)};instances.append(instance)
        elif name=='*END INSTANCE':instance=None
        elif instance is not None:
            if name:raise ValueError('INSTANCE 내부 추가 키워드 '+name+'는 자동 평탄화하지 않습니다. 메쉬 PART로 정리하세요.')
        else:outside.append(block)
    if not instances:raise ValueError('PART/ASSEMBLY에 배치된 INSTANCE가 없습니다.')
    allowed={'*NODE','*ELEMENT','*NSET','*ELSET','*SURFACE','*SOLID SECTION','*SHELL SECTION'}
    for part in parts.values():
        for block in part:
            if card(block) and card(block) not in allowed:raise ValueError('PART 내부 '+card(block)+'는 의미를 보존한 자동 평탄화 대상이 아닙니다. 전역/flat 모델로 내보내세요.')
    maxnode=max([int(tokens(row)[0]) for b in outside if card(b)=='*NODE' for row in data(b)]+[0])
    maxelem=max([int(tokens(row)[0]) for b in outside if card(b)=='*ELEMENT' for row in data(b) if tokens(row)[0].isdigit()]+[0])
    aliases={};mappings={};output=[]
    for inst in instances:
        name=inst['name'];part=inst['part']
        if part not in parts:raise ValueError('INSTANCE PART 정의 누락: '+part)
        mesh=mesh_from_lines([line for b in parts[part] for line in b],False,True)
        nodes={old:maxnode+i+1 for i,old in enumerate(sorted(mesh.nodes))};maxnode+=len(nodes)
        elements={old:maxelem+i+1 for i,old in enumerate(sorted(mesh.elements))};maxelem+=len(elements)
        names={key:(key if len(instances)==1 and key in ('FRAME_ORIGIN','FRAME_X','FRAME_Y') else name.replace('-','_')+'__'+key) for key in set(mesh.nsets)|set(mesh.elsets)}
        for b in parts[part]:
            if card(b)=='*SURFACE':
                local=str(keyword(b[0])[1]['NAME']).upper();names[local]=name.replace('-','_')+'__'+local
        for local,target in names.items():aliases[name+'.'+local]=target
        mappings[name]={'nodes':nodes,'elements':elements,'names':names}
        rotation=np.eye(3);translation=np.zeros(3);axis=np.zeros(3)
        placement=inst['placement']
        if placement:
            first=[float(v) for v in tokens(placement[0]) if v]
            if len(first)!=3:raise ValueError('INSTANCE 첫 배치 행은 3개 병진 값이어야 합니다.')
            translation=np.array(first)
        if len(placement)>1:
            values=[float(v) for v in tokens(placement[1]) if v]
            if len(values)!=7:raise ValueError('INSTANCE 회전 행은 축 두 점과 각도 7개 값이어야 합니다.')
            axis=np.array(values[:3]);direction=np.array(values[3:6])-axis;length=np.linalg.norm(direction)
            if length==0:raise ValueError('INSTANCE 회전 축 길이가 0입니다.')
            u=direction/length;angle=np.deg2rad(values[6]);cross=np.array([[0,-u[2],u[1]],[u[2],0,-u[0]],[-u[1],u[0],0]])
            rotation=np.cos(angle)*np.eye(3)+(1-np.cos(angle))*np.outer(u,u)+np.sin(angle)*cross
        if len(placement)>2:raise ValueError('INSTANCE 배치 행이 너무 많습니다.')
        output.append('*NODE')
        for old,p in mesh.nodes.items():
            value=rotation@(np.array(p)+translation-axis)+axis
            output.append(str(nodes[old])+', '+', '.join(format(float(v),'.15g') for v in value))
        grouped=defaultdict(list)
        for old,(kind,conn) in mesh.elements.items():grouped[(kind,mesh.element_groups.get(old))].append((old,conn))
        for (kind,group),items in grouped.items():
            output.append('*ELEMENT, TYPE='+kind+(', ELSET='+names[group] if group else ''))
            output.extend(str(elements[e])+', '+', '.join(str(nodes[n]) for n in conn) for e,conn in items)
        for kind,sets,labels in (('NSET',mesh.nsets,nodes),('ELSET',mesh.elsets,elements)):
            for local,ids in sets.items():output.extend(['*'+kind+', '+kind+'='+names[local],id_lines(labels[i] for i in ids)])
        for b in parts[part]:
            c=card(b)
            if c not in ('*SURFACE','*SOLID SECTION','*SHELL SECTION'):continue
            line=b[0]
            for local,target in sorted(names.items(),key=lambda p:-len(p[0])):
                line=re.sub(r'(?i)(?<![\w.-])'+re.escape(local)+r'(?![\w.-])',target,line)
            output.append(line)
            if c=='*SURFACE':
                params=keyword(b[0])[1];lookup=nodes if str(params.get('TYPE','ELEMENT')).upper()=='NODE' else elements
                for row in data(b):
                    values=tokens(row);label=values[0].upper()
                    values[0]=str(lookup[int(label)]) if label.isdigit() else names[label]
                    output.append(', '.join(values))
            else:output.extend(b[1:])
    def replace_qualified(line,node=True):
        for source,target in sorted(aliases.items(),key=lambda p:-len(p[0])):
            line=re.sub(r'(?i)(?<![\w.-])'+re.escape(source)+r'(?![\w.-])',target,line)
        def numeric(m):
            prefix=m[1].upper();label=int(m[2])
            if prefix not in mappings:return m[0]
            return str(mappings[prefix]['nodes' if node else 'elements'][label])
        return re.sub(r'(?i)([A-Z_][\w-]*)\.(\d+)\b',numeric,line)
    for b in outside:
        c=card(b);params=keyword(b[0])[1] if c else {}
        if c in ('*NSET','*ELSET') and 'INSTANCE' in params:
            inst=str(params['INSTANCE']).upper();lookup=mappings[inst]['nodes' if c=='*NSET' else 'elements'];values=[]
            for row in data(b):
                fields=[v for v in tokens(row) if v]
                if 'GENERATE' in params:
                    nums=list(map(int,fields));values.extend(range(nums[0],nums[1]+1,nums[2] if len(nums)>2 else 1))
                else:values.extend(int(v) for v in fields)
            output.extend([c+', '+c.lstrip('*')+'='+str(params[c.lstrip('*')]),id_lines(lookup[v] for v in values)])
        else:
            node=c not in ('*ELSET','*DLOAD') and not(c=='*SURFACE' and str(params.get('TYPE','ELEMENT')).upper()!='NODE')
            output.extend(replace_qualified(line,node) for line in b)
    report={'instances':{name:{'nodes':m['nodes'],'elements':m['elements'],'names':m['names']} for name,m in mappings.items()},'note':'Geometry transformed; global opaque keywords retained; unsupported local PART cards rejected.'}
    return (output,report) if return_mapping else output
