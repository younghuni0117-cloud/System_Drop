"""Portable MJPEG AVI writer using Qt's existing JPEG codec, no ffmpeg install."""
from pathlib import Path
import os,struct,uuid
import numpy as np
from PySide6 import QtCore,QtGui


def chunk(tag,payload):return tag+struct.pack('<I',len(payload))+payload+(b'\0' if len(payload)%2 else b'')


class AviWriter:
    def __init__(self,path,width,height,fps=10):
        self.path=Path(path);self.width=int(width);self.height=int(height);self.fps=int(fps)
        self.temp=self.path.with_name(self.path.name+'.'+uuid.uuid4().hex+'.partial')
        self.stream=self.temp.open('xb');self.index=[];self.closed=False
        self.stream.write(self.header(0,0,0))
        self.movi_start=self.stream.tell();self.stream.write(b'LIST\0\0\0\0movi')

    def header(self,frames,riff_size,movi_size):
        avih=struct.pack('<14I',round(1e6/self.fps),0,0,0x10,frames,0,1,self.width*self.height*3,self.width,self.height,0,0,0,0)
        strh=struct.pack('<4s4sIHHIIIIIIIIhhhh',b'vids',b'MJPG',0,0,0,0,1,self.fps,0,frames,self.width*self.height*3,0xffffffff,0,0,0,self.width,self.height)
        strf=struct.pack('<IiiHH4sIiiII',40,self.width,self.height,1,24,b'MJPG',self.width*self.height*3,0,0,0,0)
        hdrl=chunk(b'LIST',b'hdrl'+chunk(b'avih',avih)+chunk(b'LIST',b'strl'+chunk(b'strh',strh)+chunk(b'strf',strf)))
        return b'RIFF'+struct.pack('<I',riff_size)+b'AVI '+hdrl

    def add(self,rgb):
        rgb=np.ascontiguousarray(rgb[:,:,:3],dtype=np.uint8)
        if rgb.shape!=(self.height,self.width,3):raise ValueError('동영상 저장 중 화면 크기가 변경됐습니다.')
        image=QtGui.QImage(rgb.data,self.width,self.height,rgb.strides[0],QtGui.QImage.Format.Format_RGB888)
        data=QtCore.QByteArray();buffer=QtCore.QBuffer(data);buffer.open(QtCore.QIODevice.OpenModeFlag.WriteOnly)
        if not image.save(buffer,'JPG',90):raise RuntimeError('Qt JPEG 인코딩 실패')
        payload=bytes(data);position=self.stream.tell()
        if position+len(payload)>0xffffff00:raise ValueError('AVI 4GB 한도입니다. 프레임 수/크기를 줄여 분할 저장하세요.')
        self.stream.write(chunk(b'00dc',payload));self.index.append((position-(self.movi_start+8),len(payload)))

    def close(self):
        if self.closed:return
        try:
            if not self.index:raise ValueError('저장할 프레임이 없습니다.')
            end=self.stream.tell();movi_size=end-self.movi_start-8
            idx=b''.join(struct.pack('<4sIII',b'00dc',0x10,offset,size) for offset,size in self.index)
            self.stream.write(chunk(b'idx1',idx));size=self.stream.tell()
            self.stream.seek(0);self.stream.write(self.header(len(self.index),size-8,movi_size))
            self.stream.seek(self.movi_start+4);self.stream.write(struct.pack('<I',movi_size))
            self.stream.flush();self.stream.close();os.replace(self.temp,self.path);self.closed=True
        except Exception:self.abort();raise

    def abort(self):
        if not self.closed:
            self.stream.close();self.temp.unlink(missing_ok=True);self.closed=True


class GifWriter:
    """Streaming GIF: retain only one frame in memory."""
    def __init__(self,path,width,height,fps=10):
        from PIL import Image,GifImagePlugin
        self.Image=Image;self.plugin=GifImagePlugin;self.path=Path(path);self.width=width;self.height=height;self.fps=fps
        self.temp=self.path.with_name(self.path.name+'.'+uuid.uuid4().hex+'.partial');self.stream=self.temp.open('xb');self.count=0;self.closed=False
    def add(self,rgb):
        frame=self.Image.fromarray(np.ascontiguousarray(rgb[:,:,:3],dtype=np.uint8)).quantize(colors=256)
        if frame.size!=(self.width,self.height):raise ValueError('동영상 화면 크기가 변경됐습니다.')
        if not self.count:
            header,_=self.plugin.getheader(frame,info={'loop':0})
            for part in header:self.stream.write(part)
        for part in self.plugin.getdata(frame,duration=max(10,round(100/self.fps)*10),disposal=2,include_color_table=True):self.stream.write(part)
        self.count+=1
    def close(self):
        if self.closed:return
        if not self.count:self.abort();raise ValueError('저장할 프레임이 없습니다.')
        self.stream.write(b';');self.stream.close();os.replace(self.temp,self.path);self.closed=True
    def abort(self):
        if not self.closed:self.stream.close();self.temp.unlink(missing_ok=True);self.closed=True


class QtMp4Writer:
    """Qt's existing multimedia codecs: no external ffmpeg installation."""
    def __init__(self,path,width,height,fps=10):
        from PySide6 import QtMultimedia as M
        import time
        if not hasattr(M,'QVideoFrameInput'):raise RuntimeError('MP4 저장에는 PySide6 6.8.2 이상이 필요합니다.')
        self.M=M;self.time=time;self.path=Path(path);self.width=width;self.height=height;self.fps=fps;self.count=0
        self.closed=False;self.stopping=False;self.cancelled=False;self.error='';self.changed=time.monotonic()
        self.temp=self.path.with_name(self.path.stem+'.'+uuid.uuid4().hex+'.partial.mp4')
        self.session=M.QMediaCaptureSession();self.recorder=M.QMediaRecorder();self.input=M.QVideoFrameInput()
        self.session.setRecorder(self.recorder);self.session.setVideoFrameInput(self.input)
        media=M.QMediaFormat(M.QMediaFormat.FileFormat.MPEG4);codecs=media.supportedVideoCodecs(M.QMediaFormat.ConversionMode.Encode)
        supported=next((c for c in (M.QMediaFormat.VideoCodec.H264,M.QMediaFormat.VideoCodec.MPEG4) if c in codecs),None)
        if supported is None:raise RuntimeError('Qt에서 사용할 MP4 비디오 인코더가 없습니다.')
        media.setVideoCodec(supported);self.recorder.setMediaFormat(media);self.recorder.setVideoResolution(width,height);self.recorder.setVideoFrameRate(fps)
        self.recorder.setOutputLocation(QtCore.QUrl.fromLocalFile(str(self.temp.resolve())))
        self.recorder.errorOccurred.connect(lambda code,message:setattr(self,'error',message))
        self.recorder.record()
    def check(self):
        if self.error:raise RuntimeError('MP4 인코딩: '+self.error)
        if self.time.monotonic()-self.changed>30:raise RuntimeError('MP4 인코더 응답 대기 시간을 초과했습니다.')
    def add(self,rgb):
        self.check();rgb=np.ascontiguousarray(rgb[:,:,:3],dtype=np.uint8)
        if rgb.shape!=(self.height,self.width,3):raise ValueError('동영상 화면 크기가 변경됐습니다.')
        image=QtGui.QImage(rgb.data,self.width,self.height,rgb.strides[0],QtGui.QImage.Format.Format_RGB888).copy()
        frame=self.M.QVideoFrame(image);frame.setStartTime(round(self.count*1000000/self.fps));frame.setEndTime(round((self.count+1)*1000000/self.fps))
        if not self.input.sendVideoFrame(frame):return False
        self.count+=1;self.changed=self.time.monotonic();return True
    def close(self):
        if self.closed:return True
        self.check()
        if not self.stopping:self.stopping=True;self.changed=self.time.monotonic();self.recorder.stop()
        if self.recorder.recorderState()!=self.M.QMediaRecorder.RecorderState.StoppedState:return False
        if not self.temp.exists() or not self.temp.stat().st_size:raise RuntimeError('MP4 출력 파일이 비어 있습니다.')
        os.replace(self.temp,self.path);self.closed=True;return True
    def abort(self):
        if self.closed:return
        self.cancelled=True;self.recorder.stop();self.closed=True
        def cleanup():
            try:self.temp.unlink(missing_ok=True)
            except OSError:QtCore.QTimer.singleShot(100,cleanup)
        QtCore.QTimer.singleShot(100,cleanup)


def movie_writer(path,width,height,fps):
    suffix=Path(path).suffix.lower()
    factory={'.avi':AviWriter,'.gif':GifWriter,'.mp4':QtMp4Writer}.get(suffix)
    if factory is None:raise ValueError('AVI, MP4 또는 GIF 확장자를 사용하세요.')
    return factory(path,width,height,fps)
