"""CalculiX integration-point stress, kept distinct from FRD nodal averages."""
from pathlib import Path
import re
import numpy as np
from .results import numbers


def read_element_stress(path,ordered=False):
    datasets={};sequence=[];time=None;active=False
    if not Path(path).exists():return [] if ordered else datasets
    with Path(path).open(errors='replace') as stream:
        for line in stream:
            if 'stresses (elem, integ.pnt.' in line.lower() and 'time' in line.lower():
                match=re.search(r'\btime\s+([-+0-9.eEdD]+)',line,re.I)
                time=float(match[1].replace('D','E')) if match else None
                if time is not None:
                    if ordered:sequence.append((time,{}));datasets[time]=sequence[-1][1]
                    else:datasets.setdefault(time,{})
                active=time is not None;continue
            if active:
                pieces=line.split()
                if pieces and pieces[0].isdigit():
                    if not (len(pieces)==8 or (len(pieces)==9 and pieces[8].startswith('_shell_'))):raise ValueError(f'CalculiX DAT stress row needs element, IP and six stresses: {line.strip()}')
                    def value(token):
                        token=token.replace('D','E').replace('d','e')
                        if 'E' not in token.upper():token=re.sub(r'([0-9.])([+-]\d{3})$',r'\1E\2',token)
                        return float(token)
                    vals=[value(p) for p in pieces[:8]]
                    if not np.isfinite(vals).all():raise ValueError('CalculiX DAT stress contains nonfinite values.')
                    tensor=np.array([vals[i] for i in (2,3,4,5,7,6)])
                    entry=datasets[time].setdefault(int(vals[0]),[np.zeros(6),0,0.])
                    entry[0]+=tensor;entry[1]+=1
                    xx,yy,zz,xy,yz,zx=tensor
                    peak=float(np.sqrt(.5*((xx-yy)**2+(yy-zz)**2+(zz-xx)**2)+3*(xy*xy+yz*yz+zx*zx)))
                    entry[2]=max(entry[2],peak)
                elif line.strip():active=False
    summarized=lambda data:{e:(v[0]/v[1],v[2]) for e,v in data.items()}
    if ordered:return [(t,summarized(data)) for t,data in sequence]
    return {t:summarized(data) for t,data in datasets.items()}


def attach_element_stress(grid,time,datasets):
    if not datasets:return False
    closest=min(datasets,key=lambda t:abs(t-time))
    if abs(closest-time)>max(1e-12,abs(time)*2e-6):return False
    data=datasets[closest];ids=grid.cell_data['Element ID']
    if not all(int(e) in data for e in ids):return False
    grid.cell_data['Stress IP mean']=np.array([data[int(e)][0] for e in ids])
    grid.cell_data['S IP max Mises']=np.array([data[int(e)][1] for e in ids])
    grid.field_data['Stress source']=np.array(['CalculiX: arithmetic mean of integration-point tensors per element; no inter-element averaging'])
    return True
