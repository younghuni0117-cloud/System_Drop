@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\python311\python.exe" (
    "runtime\python311\python.exe" bootstrap_windows.py --launch
    if errorlevel 1 goto failed
    exit /b 0
)
if exist "offline\wheels" (
    if not exist "runtime\python311\python.exe" (
        powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\prepare_runtime.ps1"
        if errorlevel 1 goto failed
    )
    "runtime\python311\python.exe" bootstrap_windows.py --offline --launch
    if errorlevel 1 goto failed
    exit /b 0
)
if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" bootstrap_windows.py --launch
    goto finished
)
where py >nul 2>nul
if errorlevel 1 (
    python bootstrap_windows.py --launch
) else (
    py -3 bootstrap_windows.py --launch
)
:finished
if errorlevel 1 goto failed
exit /b 0

:failed
pause
exit /b 1
