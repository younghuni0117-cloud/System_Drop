import json
import numpy as np
import pytest
from system_drop.model import ROOT


def test_actual_18_direction_report_finished_36_native_steps():
    data=json.loads((ROOT/'examples/cumulative/validation_18.json').read_text())
    assert data['success'] and data['directions']==list(range(1,19))
    assert data['drop_time']==1e-6 and data['release_time']==1
    assert len(data['drops'])==18 and not data['errors'] and data['seed_first'] is None
    for i,drop in enumerate(data['drops'],1):
        assert drop['impact']['native_step']==i*2-1
        assert drop['stabilization']['native_step']==i*2
        assert drop['stabilization']['total_time']==pytest.approx(i*1.000001)
        for stage in ('impact','stabilization'):
            assert drop[stage]['coordinates_finite'] and drop[stage]['velocities_finite']
        if i>1:
            assert drop['transfer']['native_material_history_preserved']
            assert 'xstate' in drop['transfer']['history_sha256']


def test_actual_second_impact_kept_prior_plasticity_and_rebounded():
    data=json.loads((ROOT/'examples/cumulative/validation_impact.json').read_text())
    assert data['success'] and data['directions']==[1,2] and data['drop_time']==6e-5
    first,second=data['drops']
    assert first['stabilization']['max_peeq']>0
    assert second['stabilization']['max_peeq']>=first['stabilization']['max_peeq']
    assert second['transfer']['native_material_history_preserved']
    # Bottom Face launch goes towards -Y; positive final Y confirms rebound.
    assert second['transfer']['velocity'][1]<0
    assert second['impact']['mean_body_velocity_mm_s'][1]>0
    assert second['stabilization']['force_reference_n']==1
    assert second['stabilization']['residual_tolerance_n']==.005
    assert second['stabilization']['total_time']==pytest.approx(2.000120)


@pytest.mark.parametrize('name',['impact_02','stabilization_02','sequence_18_final'])
def test_packaged_cumulative_viewer_frames_are_finite(name):
    import pyvista as pv
    folder=ROOT/'examples/cumulative'/name/'results'
    records=json.loads((folder/'frames.json').read_text())
    grid=pv.read(folder/records[-1]['file'])
    assert np.isfinite(grid.points).all()
    for variable in ('DISP','VELO','STRESS','PE'):
        assert np.isfinite(grid[variable]).all()
