import importlib.util
from pathlib import Path
import math
import numpy as np
from system_drop.model import ROOT

spec=importlib.util.spec_from_file_location('odb_export',ROOT/'tools/export_odb.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


def test_odb_local_shell_tensor_is_rotated_to_global_before_averaging():
    c=math.sqrt(.5)
    class Value:
        data=(100.,0.,0.,0.,0.,0.)
        localCoordSystem=((c,c,0),(-c,c,0),(0,0,1))
    tensor=module.tensor_global(Value(),['S11','S22','S33','S12','S13','S23'])
    np.testing.assert_allclose(tensor,[50,50,0,50,0,0],atol=1e-12)


def test_odb_tensor_component_order_is_normalized():
    class Value:
        data=(1,2,3,4,5,6)
        localCoordSystem=None
    assert module.tensor_global(Value(),['S11','S22','S33','S12','S13','S23'])==[1,2,3,4,6,5]


def test_export_keeps_nodal_velocity_rotation_parts_and_ip_peak(tmp_path,monkeypatch):
    import sys,json,types
    from types import SimpleNamespace as Obj
    import pyvista as pv
    out=tmp_path/'results';out.mkdir()
    (out/'part_index.json').write_text(json.dumps({'names':['LOGO'],'elements':{'5':0}}))
    instance=Obj(name='PART',elementSets={},elements=[Obj(label=5,type='S4',connectivity=[1,2,3,4])],
                 nodes=[Obj(label=i+1,coordinates=p) for i,p in enumerate([(0,0,0),(1,0,0),(1,1,0),(0,1,0)])])
    class Field:
        def __init__(self,values,nodal=False):self.values=values;self.nodal=nodal;self.componentLabels=('S11','S22','S33','S12','S13','S23')
        def getSubset(self,position):
            assert not self.nodal,'nodal fields must not be requested at integration points'
            return self
    nodal=lambda xyz:[Obj(instance=instance,nodeLabel=n,data=xyz) for n in range(1,5)]
    sv=[Obj(instance=instance,elementLabel=5,data=(v,0,0,0,0,0),mises=100.,localCoordSystem=None) for v in (100.,-100.)]
    fields={'U':Field(nodal((0.,0.,0.)),True),'V':Field(nodal((1.,2.,3.)),True),
            'VR':Field(nodal((4.,5.,6.)),True),'S':Field(sv),
            'PEEQ':Field([Obj(instance=instance,elementLabel=5,data=.01)])}
    frame=Obj(frameValue=.1,fieldOutputs=fields)
    odb=Obj(rootAssembly=Obj(instances={'PART':instance}),steps={'DROP':Obj(frames=[frame])},close=lambda:None)
    monkeypatch.setitem(sys.modules,'odbAccess',Obj(openOdb=lambda **kwargs:odb))
    monkeypatch.setitem(sys.modules,'abaqusConstants',Obj(INTEGRATION_POINT='IP'))
    module.export('dummy.odb',str(out))
    grid=pv.read(out/'frame_0000.vtu')
    assert grid.cell_data['S IP max Mises'][0]==100
    assert not np.any(grid.cell_data['Stress IP mean'])
    state=json.loads((out/'state.json').read_text())
    assert state['velocities']['1']==[1.,2.,3.,4.,5.,6.]
    assert json.loads((out/'parts.json').read_text())==['LOGO']
