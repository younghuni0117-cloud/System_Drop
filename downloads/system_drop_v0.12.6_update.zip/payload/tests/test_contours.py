import numpy as np
import pyvista as pv
from system_drop.contours import contour_grid
from system_drop.parts import ensure_parts


def two_cells():
    # Two quads sharing two nodes, with discontinuous uniaxial stress.
    grid=pv.UnstructuredGrid([4,0,1,2,3,4,1,4,5,2],[9,9],
        np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[2,0,0],[2,1,0]],dtype=float))
    grid.cell_data['Stress IP mean']=np.array([[10.,0,0,0,0,0],[100.,0,0,0,0,0]])
    grid.point_data['Node ID']=np.arange(6);grid.cell_data['Element ID']=[1,2]
    ensure_parts(grid);return grid


def test_none_simple_and_thresholded_advanced_are_distinct_and_do_not_modify_raw():
    original=two_cells()
    none,a,_=contour_grid(original,'S Mises (MPa)','None')
    simple,b,_=contour_grid(original,'S Mises (MPa)','Simple')
    advanced,c,_=contour_grid(original,'S Mises (MPa)','Advanced',10)
    assert a=='cell' and np.array_equal(none.cell_data['Contour'],[10,100])
    assert b=='point' and simple.point_data['Contour'][1]==55
    assert c=='point' and advanced.n_points==8
    assert set(advanced.point_data['Contour'])=={10,100}
    assert 'Contour' not in original.array_names
    assert np.array_equal(original.cell_data['Stress IP mean'][:,0],[10,100])


def test_tensor_averaging_precedes_mises_and_keeps_sign_of_components():
    grid=two_cells();grid.cell_data['Stress IP mean'][1,0]=-10
    out,_,_=contour_grid(grid,'S Mises (MPa)','Simple')
    assert out.point_data['Contour'][1]==0
    source,_,_=contour_grid(grid,'S11','None')
    assert source.cell_data['Contour'][1]==-10


def test_signed_principal_stresses_from_tensor_including_shear():
    from system_drop.contours import stress_value
    tensor=np.array([[0.,0,0,20,0,0],[10,20,30,0,0,0]])
    np.testing.assert_allclose(stress_value(tensor,'Max. Principal Stress'),[20,30])
    np.testing.assert_allclose(stress_value(tensor,'Min. Principal Stress'),[-20,10])
    np.testing.assert_allclose(stress_value(tensor,'Von-Mises Stress'),stress_value(tensor,'S Mises (MPa)'))


def test_principal_stresses_use_the_selected_averaged_tensor():
    grid=two_cells()
    grid.cell_data['Stress IP mean'][:]=[[10.,0,0,0,0,0],[0,20,0,0,0,0]]
    averaged,_,_=contour_grid(grid,'Max. Principal Stress','Simple')
    assert averaged.point_data['Contour'][1]==10  # eig([5,10,0]), not mean([10,20]).
    minimum,_,_=contour_grid(grid,'Min. Principal Stress','None')
    np.testing.assert_array_equal(minimum.cell_data['Contour'],[0,0])


def test_new_von_mises_label_preserves_original_exported_source_values():
    grid=two_cells();grid.cell_data['S Mises (MPa)']=[25.,125.]
    source,association,_=contour_grid(grid,'Von-Mises Stress','Source')
    assert association=='cell'
    np.testing.assert_array_equal(source.cell_data['Contour'],[25,125])


def test_missing_principal_tensor_is_ignored_without_failing_other_elements():
    from system_drop.contours import stress_value
    tensor=np.array([[np.nan,0,0,0,0,0],[1,2,3,0,0,0]])
    values=stress_value(tensor,'Max. Principal Stress')
    assert np.isnan(values[0]) and values[1]==3
