from pathlib import Path
from types import SimpleNamespace
import hashlib,json,zipfile
import pytest
import offline_setup as off


def fixture(root):
    base=root/'offline';(base/'wheels').mkdir(parents=True)
    archive=base/'python.zip'
    with zipfile.ZipFile(archive,'w') as z:z.writestr('python.exe',b'Windows Python placeholder for setup tests')
    wheel=base/'wheels/pkg.whl';wheel.write_bytes(b'local wheel test bytes')
    report={'python_archive':'python.zip','pins':{'numpy':'1.26.4'},'files':{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (archive,wheel)}}
    (base/'manifest.json').write_text(json.dumps(report));return base


def test_only_local_wheels_and_only_missing_packages_are_requested(tmp_path):
    fixture(tmp_path);calls=[]
    def run(args,**kwargs):calls.append(args);return SimpleNamespace(returncode=0)
    assert off.install(tmp_path,'python.exe',['numpy>=1.24'],run)==0
    assert calls==[['python.exe',str(tmp_path/'tools/install_local_wheels.py'),'numpy==1.26.4']]
    script=(Path(__file__).parents[1]/'tools/install_local_wheels.py').read_text()
    assert '--no-index' in script and '--find-links' in script
    assert '--upgrade' not in script and '--force-reinstall' not in script


def test_missing_or_corrupt_copy_is_reported_before_install(tmp_path):
    base=fixture(tmp_path);off.verify(tmp_path)
    (base/'wheels/pkg.whl').write_bytes(b'corrupt')
    with pytest.raises(RuntimeError,match='손상'):off.verify(tmp_path)
    (base/'wheels/pkg.whl').unlink()
    with pytest.raises(RuntimeError,match='누락'):off.verify(tmp_path)


def test_portable_python_uses_relative_site_packages_and_project_paths(tmp_path):
    fixture(tmp_path);exe=off.prepare_python(tmp_path)
    assert exe.exists()
    content=(exe.parent/'python311._pth').read_text()
    assert '../..' in content and 'Lib/site-packages' in content and 'import site' in content
    assert off.prepare_python(tmp_path)==exe


def test_complete_environment_never_runs_pip_or_reinstalls(tmp_path,monkeypatch):
    monkeypatch.setattr(off,'install',lambda *args:(_ for _ in ()).throw(AssertionError('No install expected')))
    monkeypatch.setattr(off,'runtime_check',lambda *args:SimpleNamespace(returncode=0))
    assert off.guide(tmp_path,'python.exe',[])==0


def test_setup_guide_retries_until_install_succeeds(tmp_path,monkeypatch):
    attempts=[]
    def install(*args):attempts.append(1);return 1 if len(attempts)==1 else 0
    monkeypatch.setattr(off,'install',install)
    monkeypatch.setattr(off,'runtime_check',lambda *args:SimpleNamespace(returncode=0))
    monkeypatch.setattr(off.sys,'stdin',SimpleNamespace(isatty=lambda:True))
    monkeypatch.setattr('builtins.input',lambda *args:'r')
    assert off.guide(tmp_path,'python.exe',['numpy>=1.24'])==0
    assert len(attempts)==2
