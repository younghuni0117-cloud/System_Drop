import os
os.environ.setdefault("QT_QPA_PLATFORM","offscreen")
from PySide6 import QtWidgets
from system_drop.gui import Window,STYLE


def test_solver_switch_sequence_order_and_step_gating():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    app.setStyleSheet(STYLE)
    w=Window(preferences_path=False)
    assert w.buttons[(0,"setup")].isEnabled()
    assert not w.buttons[(0,"drop")].isEnabled()
    assert not w.buttons[(1,"setup")].isEnabled()
    w.scenario.setCurrentText("18-Side Drop Sequence 2")
    assert w.directions[:4]==[7,8,9,10]
    w.solver.setCurrentText("Abaqus 2025")
    assert w.viewer.isEnabled()
    assert w.template.text().endswith("template_abaqus")
    w.solver.setCurrentText("CalculiX 2.23 (Open-Source)")
    assert not w.viewer.isEnabled()
    w.scenario.setCurrentText("Custom");w.custom_count.setValue(3)
    w.direction_combos[1].setCurrentIndex(6);w.direction_combos[2].setCurrentIndex(6)
    assert w.directions==[1,7,7]
    assert w.overall.format()=="진행률 0.0%"
    assert w.table.item(0,1).text()=="Top Face"
    w.scenario.setCurrentText("18-Side Drop Sequence 1")
    assert not w.custom_count.isHidden()
    assert not w.custom_count.isEnabled() and w.custom_count.value()==18
    assert not w.direction_combos
    w.scenario.setCurrentText("Custom")
    assert w.directions==[1,7,7]
    assert w.drop_height.decimals()==3 and w.gap.decimals()==3
    assert w.drop_dt.value()==1e-7
    assert w.drop_dt.text()=="0.0000001"
    assert w.expected_frames.text()=="예상 Frame : 60개"
    assert w.details.isAncestorOf(w.release_damping)
    assert not w.table.item(0,1).icon().isNull()
    assert all(x.decimals()==15 for x in (w.drop_time,w.release_dt,w.release_max,w.release_time))
    assert w.details.isAncestorOf(w.template)
    assert w.width()==1080 and w.height()==720
    w.close()


def test_compact_layout_and_sequence_check_are_not_solver_results():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False);w.resize(940,600);w.show();app.processEvents()
    assert w.left_scroll.horizontalScrollBar().maximum()==0
    assert w.left_scroll.widget().minimumSizeHint().width()<=w.left_scroll.viewport().width()
    w.sequence_check.setChecked(True)
    assert not w.mode_notice.isHidden()
    assert "실제 Solver 실행" in w.mode_notice.text()
    assert not hasattr(w,"mode")
    assert w.details.isAncestorOf(w.sequence_check)
    assert w.details.isAncestorOf(w.gap)
    assert not hasattr(w,"auto_scroll")
    assert not hasattr(w,"detect_button")
    assert w.details.isAncestorOf(w.ccx_path)
    assert w.left_scroll.isAncestorOf(w.details_button)
    assert w.table.horizontalHeaderItem(4).text()=="3. 안정화해석"
    w.close()


def test_completed_buttons_and_solver_browse_remain_available_after_failure(tmp_path):
    from system_drop.engine import Engine
    from system_drop.model import Settings
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False);w.engine=Engine(Settings(),workflow=True)
    w.engine.records[0]={"setup":"done","drop":"failed","release":"pending"}
    w.update_controls()
    w.engine.durations[(0,'setup')]=300;w.update_controls()
    assert w.buttons[(0,"setup")].text()=="완료(5min)"
    assert w.buttons[(0,"setup")].isEnabled()
    assert w.ccx_browse.isEnabled()
    assert not w.buttons[(0,"release")].isEnabled()
    w.close()


def test_solver_path_and_custom_rows_are_remembered_on_next_launch(tmp_path):
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    pref=tmp_path/"user_settings.json"
    first=Window(preferences_path=pref)
    first.ccx_command.setText('"C:/Solvers/ccx_2.23.exe" -i {job}')
    first.scenario.setCurrentText("Custom");first.custom_count.setValue(2)
    first.direction_combos[1].setCurrentIndex(6)
    first.close()
    second=Window(preferences_path=pref)
    assert second.ccx_command.text()=='"C:/Solvers/ccx_2.23.exe" -i {job}'
    assert second.directions==[1,7]
    second.close()


def test_all_18_rows_fit_and_single_gauge_while_observation_is_visible():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False);w.show()
    w.live.setText('PID 123 | 경과 60초 | CPU 100% | t=0.00002s\n해석 시간 진행 확인')
    app.processEvents()
    assert not hasattr(w,'current')
    last=w.table.visualItemRect(w.table.item(17,0))
    assert last.bottom()<=w.table.viewport().height()
    from PySide6.QtCore import Qt
    assert w.table.item(0,0).textAlignment() & Qt.AlignmentFlag.AlignHCenter
    assert w.details.isAncestorOf(w.drop_dt) is False  # retained internally, not displayed
    assert w.drop_dt.isHidden()
    w.close()


def test_verified_impact_preset_and_adjustable_maximum_increment():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False);w.apply_impact_preset()
    s=w.settings()
    assert s.directions==[1] and s.cpus==4 and s.gap==.001 and s.drop_time==.000060
    assert s.height==1000 and not w.sequence_check.isChecked()
    w.drop_max_dt.setValue(1e-8)
    s=w.settings();s.validate()
    assert s.drop_dt<=s.drop_max_dt==1e-8
    w.close()


def test_next_calculix_setup_enabled_after_previous_stabilization():
    from system_drop.engine import Engine
    from system_drop.model import Settings
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False)
    w.engine=Engine(Settings())
    w.engine.records[0]=dict.fromkeys(('setup','drop','release'),'done')
    w.update_controls()
    assert w.start.isEnabled()
    assert w.buttons[(1,'setup')].isEnabled()
    assert not w.buttons[(1,'drop')].isEnabled()
    w.close()


def test_postprocessing_replaces_99_percent_with_phase_and_waits_for_validation():
    from system_drop.engine import Engine
    from system_drop.model import Settings
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False);w.engine=Engine(Settings())
    w.engine.records[0]['drop']='running'
    w.on_event('processing',{'index':0,'stage':'drop','phase':'FRD 검사','percent':32.5})
    assert '결과 변환' in w.buttons[(0,'drop')].text()
    assert 'FRD 검사' in w.live.text()
    w.on_event('processing',{'index':0,'stage':'drop','phase':'최종 상태 검증','percent':100.})
    assert w.buttons[(0,'drop')].text()=='최종 검증 중'
    assert w.engine.records[0]['drop']=='running'
    w.engine.records[0]['drop']='done';w.engine.durations[(0,'drop')]=60
    w.update_controls()
    assert w.buttons[(0,'drop')].text()=='완료(1min)'
    w.close()


def test_saved_foreign_output_path_is_rebased_to_current_program_runs():
    from system_drop.model import ROOT,Settings
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False)
    w.apply_settings(Settings(output_root='Z:/old computer/System_Drop/runs'))
    assert w.output.text()==str(ROOT/'runs') and w.output.isReadOnly()
    assert w.settings().output_root==str(ROOT/'runs')
    w.close()


def test_cumulative_preset_restores_18_directions_from_previous_custom_choice():
    app=QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w=Window(preferences_path=False)
    w.apply_impact_preset();w.apply_cumulative_preset()
    s=w.settings()
    assert s.directions==list(range(1,19))
    assert s.drop_time==.000060 and s.release_time==1 and s.gap==.001
    assert not w.sequence_check.isChecked()
    w.close()
