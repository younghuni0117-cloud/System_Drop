import math
import numpy as np
import pytest

from system_drop.model import frame, drop_direction, impact_velocity, floor_geometry, SCENARIOS


def test_frame_from_flat_reference_points_and_rigid_rotation():
    p=np.array([[-152,8,106],[152,8,106],[-152,8,-106]])
    assert np.allclose(frame(*p),np.eye(3))
    angle=.73
    r=np.array([[math.cos(angle),-math.sin(angle),0],[math.sin(angle),math.cos(angle),0],[0,0,1]])
    q=p@r.T+[23,-15,44]
    assert np.allclose(frame(*q),r)
    assert np.linalg.det(frame(*q))==pytest.approx(1)


def test_degenerate_frame_rejected():
    with pytest.raises(ValueError): frame(np.zeros(3),np.ones(3),np.ones(3)*2)


@pytest.mark.parametrize("direction",range(1,19))
def test_all_directions_have_unit_length_and_consistent_floor(direction):
    d=drop_direction(direction)
    assert np.linalg.norm(d)==pytest.approx(1)
    points=np.array([[x,y,z] for x in (-152,152) for y in (-8,8) for z in (-106,106)])
    floor=floor_geometry(points,d,1,shell_allowance=0)
    assert np.allclose(floor@d, np.max(points@d)+1)
    normal=np.cross(floor[1]-floor[0],floor[2]-floor[1])
    assert np.dot(normal,d)<0


def test_corner_uses_product_diagonal_and_thickness_edge():
    d=drop_direction(7)
    assert d[1]==0
    assert d[0]/d[2]==pytest.approx(304/212)
    assert d[0]>0 and d[2]>0


@pytest.mark.parametrize("direction",range(11,19))
def test_edge_broad_plane_angle_is_30_degrees(direction):
    d=drop_direction(direction)
    assert math.degrees(math.acos(abs(d[1])))==pytest.approx(30)


def test_gap_speed_preserves_impact_energy():
    for gap in (0,1,10,999,1000):
        speed=np.linalg.norm(impact_velocity(1000,gap,[.2,.3,.4]))
        assert speed**2+2*9810*gap==pytest.approx(2*9810*1000)
    with pytest.raises(ValueError): impact_velocity(1000,1001,[1,0,0])


def test_shell_contact_offset_is_not_added_to_solid_faces():
    from system_drop.deck import read_mesh,contact_allowances
    from system_drop.model import ROOT
    main=ROOT/"template_calculix/calculix_main.inp"
    mesh=read_mesh(ROOT/"template_calculix/calculix_mesh.inp")
    coords=mesh.product_nodes
    side=drop_direction(3)
    allowances=contact_allowances(mesh,coords,main,side)
    floor=floor_geometry(list(coords.values()),side,1,allowances)
    assert np.allclose(floor[:,0],153.)
    top=drop_direction(1)
    allowances=contact_allowances(mesh,coords,main,top)
    floor=floor_geometry(list(coords.values()),top,1,allowances)
    assert np.allclose(floor[:,1],9.)


def test_scenarios_are_independent_permutations():
    for name,ids in SCENARIOS.items():
        if name!="Custom": assert sorted(ids)==list(range(1,19))
    assert SCENARIOS["18-Side Drop Sequence 2"][:4]==[7,8,9,10]
    assert SCENARIOS["18-Side Drop Sequence 3"][:8]==list(range(11,19))
