from pathlib import Path
from types import SimpleNamespace
import json
from system_drop.model import Settings
from system_drop.execution import solver_environment,exit_description,write_failure_report


def test_calculix_child_matches_bundled_thread_setup_without_mutating_parent():
    original={'PATH':'parent-bin','CCX_NPROC_STIFFNESS':'64','CCX_NPROC_RESULTS':'32','TOKEN':'private'}
    env=solver_environment(Settings(cpus=4),['C:/solver/ccx_MT.exe'],original)
    assert original['CCX_NPROC_STIFFNESS']=='64'
    assert env['OMP_NUM_THREADS']==env['NUMBER_OF_CPUS']==env['CCX_NPROC_RESULTS']=='4'
    assert env['CCX_NPROC_STIFFNESS']=='1' and env['PRINTF_EXPONENT_DIGITS']=='2'
    assert env['PATH'].endswith('parent-bin')
    single=solver_environment(Settings(cpus=1),['ccx'],{})
    assert single['CCX_NPROC_RESULTS']==single['CCX_NPROC_STIFFNESS']=='1'


def test_abaqus_environment_does_not_add_calculix_specific_tuning():
    env=solver_environment(Settings(solver='abaqus',cpus=8),['abaqus'],{})
    assert env['OMP_NUM_THREADS']=='8'
    assert 'CCX_NPROC_STIFFNESS' not in env and 'CCX_NPROC_RESULTS' not in env


def test_unsigned_and_signed_access_violation_codes_have_same_explanation():
    assert exit_description(3221225477)==exit_description(-1073741819)
    assert '0xC0000005' in exit_description(3221225477)
    assert '접근 위반' in exit_description(3221225477)
    assert '메모리 할당 실패' in exit_description(0xc0000017)
    assert exit_description(-11)=='종료 코드 -11'


def test_crash_report_preserves_outputs_and_records_reproducible_inputs(tmp_path):
    (tmp_path/'job.inp').write_text('input bytes')
    (tmp_path/'job.frd').write_bytes(b'partial output')
    (tmp_path/'job.rout').write_bytes(b'partial restart')
    (tmp_path/'job.dat').write_text('displacements for set FRAME_ORIGIN and time 0.000123\n')
    (tmp_path/'solver.log').write_text('SELECTED time increment (based on contact): 0.00000004\ncrash\n')
    before={p.name:p.read_bytes() for p in tmp_path.iterdir()}
    s=Settings(cpus=4,drop_max_dt=.00001,drop_time=.001)
    env=solver_environment(s,['ccx_MT.exe'],{'TOKEN':'private'})
    report=write_failure_report(tmp_path,s,'drop',['ccx_MT.exe','-i','job'],env,3221225477)
    data=json.loads(report.read_text())
    assert data['settings']['drop_time']==.001 and data['settings']['drop_max_dt']==.00001
    assert data['stage']=='drop' and data['return_code']==3221225477
    assert data['thread_environment']['CCX_NPROC_STIFFNESS']=='1'
    assert data['last_dat_time_s']==.000123 and data['last_stable_increment_s']==.00000004
    assert data['file_sizes']['job.rout']==len(b'partial restart')
    assert len(data['input_hashes']['job.inp']['sha256'])==64
    assert 'TOKEN' not in data['thread_environment'] and 'private' not in report.read_text()
    for name,contents in before.items():assert (tmp_path/name).read_bytes()==contents


def test_native_crash_is_failed_and_reported_without_converting_partial_results(tmp_path,monkeypatch):
    from system_drop.engine import Engine
    s=Settings(directions=[1],cpus=4,drop_time=.001,drop_max_dt=.00001,output_root=str(tmp_path))
    e=Engine(s);e.execute(automatic=False)
    class FailedProcess:
        pid=99999999
        def poll(self):return 3221225477
        def wait(self):return 3221225477
    def popen(args,cwd,stdout,env):
        stdout.write(b'Native access violation simulation\n')
        return FailedProcess()
    monkeypatch.setattr('system_drop.engine.popen',popen)
    e.execute(automatic=False)
    assert e.records[0]['drop']=='failed' and e.records[0]['release']=='pending'
    folder=e.run/'drop_01'
    data=json.loads((folder/'solver_failure_report.json').read_text())
    assert data['return_code']==3221225477
    assert not (folder/'results/state.json').exists()
