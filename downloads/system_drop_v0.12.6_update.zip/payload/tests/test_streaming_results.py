from pathlib import Path
import json,numpy as np,pytest
from system_drop.results import read_frd,convert_frd
from system_drop.stream_results import index_frd,load_frd_frame,index_dat,load_dat_frame
from system_drop.element_results import read_element_stress
from test_frd_windows import example


def test_frd_index_and_seeks_retain_same_rounded_frames_and_all_fields(tmp_path):
    path=tmp_path/'job.frd';mesh=example(path)
    text=path.read_bytes();path.write_bytes(text*3)
    old=read_frd(path,mesh);indices=index_frd(path,mesh)
    assert len(indices)==len(old)==3
    assert all(set(i)=={'time','start','stop'} for i in indices)
    for i,meta in enumerate(indices):
        frame=load_frd_frame(path,mesh,meta)
        assert frame[0]==old[i][0] and frame[2:]==old[i][2:]
        for name in old[i][1].point_data:
            np.testing.assert_array_equal(frame[1].point_data[name],old[i][1].point_data[name])


def test_dat_seek_preserves_repeated_times_ip_averages_and_shear_order(tmp_path):
    path=tmp_path/'job.dat'
    path.write_text(''.join(' stresses (elem, integ.pnt.,sxx,syy,szz,sxy,sxz,syz) for set X and time 1.0E-6\n'
        f' 1 1 {value} 2 3 4 5 6\n 1 2 {-value} 2 3 4 5 6 _shell_0000000001\n\n' for value in (10,20,30)))
    old=read_element_stress(path,ordered=True);index=index_dat(path)
    assert len(index)==3
    for i,meta in enumerate(index):
        data=load_dat_frame(path,meta)
        np.testing.assert_array_equal(data[1][0],old[i][1][1][0])
        assert data[1][1]==old[i][1][1][1]
        assert 'data' not in meta


def test_conversion_does_not_use_eager_readers_and_progress_is_monotone(tmp_path,monkeypatch):
    path=tmp_path/'job.frd';mesh=example(path)
    def forbidden(*args,**kwargs):raise AssertionError('Raw frame history must not be retained')
    monkeypatch.setattr('system_drop.results.read_frd',forbidden)
    monkeypatch.setattr('system_drop.element_results.read_element_stress',forbidden)
    events=[]
    state=convert_frd(path,mesh,tmp_path/'results',progress=events.append)
    assert state.exists()
    assert [e['percent'] for e in events]==sorted(e['percent'] for e in events)
    assert events[0]['percent']==0 and events[-1]['percent']==100
    mode=json.loads((state.parent/'conversion_mode.json').read_text())
    assert mode['mode']=='streamed_index_then_selected_frames' and mode['all_raw_values_validated']


def test_corrupt_unselected_frame_is_not_silently_discarded(tmp_path):
    path=tmp_path/'job.frd';mesh=example(path)
    good=path.read_bytes()
    bad=good.replace(b'1.00000E-003',b'         NaN',1)
    assert bad!=good
    path.write_bytes(good+bad+good)
    with pytest.raises(ValueError,match='FRD'):
        convert_frd(path,mesh,tmp_path/'results',output_schedule={'period':2e-5,'interval':2e-5})


def test_truncated_later_frd_block_remains_an_error(tmp_path):
    path=tmp_path/'job.frd';mesh=example(path);text=path.read_bytes()
    path.write_bytes(text+text.rsplit(b' -3',1)[0])
    with pytest.raises(ValueError,match='종료'):
        index_frd(path,mesh)


def test_stream_scan_can_be_cancelled_without_modifying_native_inputs(tmp_path):
    path=tmp_path/'job.frd';mesh=example(path);original=path.read_bytes()
    def cancelled(event):raise RuntimeError('test cancellation')
    with pytest.raises(RuntimeError,match='test cancellation'):
        convert_frd(path,mesh,tmp_path/'results',progress=cancelled)
    assert path.read_bytes()==original
