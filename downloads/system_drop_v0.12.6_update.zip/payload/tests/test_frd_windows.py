"""Regression for legacy Windows CRT %12.5E exponent-width expansion."""
from pathlib import Path
import re
import numpy as np
import pytest
from system_drop.deck import Mesh
from system_drop.results import read_frd,frd_values,convert_frd,validate_physical_state,read_state


def windows_number(value):
    text=re.sub(r'([Ee][+-])(\d+)',lambda m:m[1]+m[2].zfill(3),f'{value:.5E}')
    return text.rjust(12)


def example(path,broken=False):
    mesh=Mesh(nodes={i:[i,0.,0.] for i in range(1,9)},elements={1:('C3D8',list(range(1,9)))})
    lines=['  100CL  101'+windows_number(2e-5)+'         8']
    for name,count in [('DISP',3),('VELO',3),('STRESS',6),('PE',1)]:
        lines.append(f' -4  {name:<12}{count:3d}    1')
        lines += [f' -5  C{i}          1    2    {i}    0' for i in range(1,count+1)]
        for n in range(1,9):
            # Signs vary by node, so the old 12-character reader returned
            # ragged per-node arrays instead of consistently three/six entries.
            values=[((-1)**(n+i))*((i+1)*.001) for i in range(count)]
            if name=='PE':values=[.001*n]
            if broken and name=='STRESS' and n==2:values.pop()
            lines.append(f' -1{n:10d}'+''.join(map(windows_number,values)))
        lines.append(' -3')
    path.write_bytes(('\r\n'.join(lines)+'\r\n').encode())
    return mesh


def test_windows_three_digit_exponents_and_crlf_convert_all_fields(tmp_path):
    path=tmp_path/'job.frd';mesh=example(path)
    frames=read_frd(path,mesh)
    assert len(frames)==1 and frames[0][0]==2e-5
    grid=frames[0][1]
    assert grid['STRESS'].shape==(8,6) and grid['VELO'].shape==(8,3)
    np.testing.assert_allclose(grid['DISP'][0],[-.001,.002,-.003])
    convert_frd(path,mesh,tmp_path/'results')
    validate_physical_state(read_state(tmp_path/'results/state.json'),mesh)


def test_positive_adjacent_windows_values_do_not_merge_exponent_digits():
    values=frd_values('1.23456E-0061.00000E+003-4.00000E-003',3,'node 360')
    assert values==pytest.approx([1.23456e-6,1000,-.004])
    mixed=frd_values('1.23456E-061.00000E-103-4.00000E-03',3,'mixed exponent widths')
    np.testing.assert_array_equal(mixed,[1.23456e-6,1e-103,-.004])


def test_truncated_or_nonfinite_field_reports_dataset_and_node(tmp_path):
    path=tmp_path/'bad.frd';mesh=example(path,broken=True)
    with pytest.raises(ValueError,match='STRESS, node 2'):read_frd(path,mesh)
    with pytest.raises(ValueError,match='비유한'):
        frd_values('         NaN'*3,3,'VELO, node 4')


def test_continuation_lines_are_combined_before_component_validation(tmp_path):
    path=tmp_path/'long.frd';mesh=example(path)
    extra=['  100CL  101'+windows_number(2e-5)+'         8',' -4  STATE       7    1']
    extra += [f' -5  C{i}          1    1    {i}    0' for i in range(1,8)]
    for n in range(1,9):
        extra += [f' -1{n:10d}'+''.join(windows_number(i) for i in range(1,7)),
                  ' -2'+windows_number(7)]
    extra.append(' -3')
    with path.open('a') as stream:stream.write('\n'.join(extra)+'\n')
    grid=read_frd(path,mesh)[0][1]
    assert grid['STATE'].shape==(8,7)
    np.testing.assert_equal(grid['STATE'][0],np.arange(1,8))


def test_same_rounded_frd_time_retains_distinct_animation_frames(tmp_path):
    path=tmp_path/'job.frd';mesh=example(path)
    text=path.read_text();path.write_text(text+text)
    frames=read_frd(path,mesh)
    assert len(frames)==2 and frames[0][0]==frames[1][0]


def test_drop13_windows_frd_rounding_and_native_endpoint_convert_without_rerun(tmp_path):
    import json,hashlib
    path=tmp_path/'job.frd';mesh=example(path);template=path.read_text()
    end=np.nextafter(12.00078,-np.inf);start=end-.00006
    blocks=[]
    for i,time in enumerate(np.linspace(start+.000001,end,60)):
        block=template.replace(windows_number(2e-5),windows_number(float(time)),1)
        block=block.replace(windows_number(-.001),windows_number(-.001*(i+1)))
        blocks.append(block)
    path.write_text(''.join(blocks));before=hashlib.sha256(path.read_bytes()).hexdigest()
    folder=tmp_path/'results'
    convert_frd(path,mesh,folder,output_schedule={'period':.00006,'interval':.000001,'offset':start,'end_time':end})
    records=json.loads((folder/'frames.json').read_text())
    assert len(records)==60 and [r['source_frame_index'] for r in records]==list(range(60))
    assert np.all(np.diff([r['time'] for r in records])>=0)
    assert records[-1]['time']==end and records[-1]['reported_time']>end
    assert read_state(folder/'state.json')['coordinates'][1][0]==pytest.approx(.94)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==before
    audit=json.loads((folder/'time_reconciliation.json').read_text())
    assert audit['corrected_frames']>0
