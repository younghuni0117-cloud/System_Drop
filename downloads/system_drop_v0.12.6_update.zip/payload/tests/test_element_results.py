import numpy as np
from system_drop.element_results import read_element_stress,attach_element_stress
from system_drop.results import grid_from_mesh
from system_drop.deck import Mesh


def test_element_stress_mean_tensor_and_ip_peak_are_separate(tmp_path):
    path=tmp_path/'job.dat'
    path.write_text(' stresses (elem, integ.pnt.,sxx,syy,szz,sxy,sxz,syz) for set X and time 1.0E-6\n\n'
                    ' 1 1 100. 0. 0. 0. 0. 0.\n 1 2 -100. 0. 0. 0. 0. 0.\n')
    result=read_element_stress(path)
    assert np.array_equal(result[1e-6][1][0],np.zeros(6))
    assert result[1e-6][1][1]==100
    mesh=Mesh(nodes={1:[0.,0.,0.],2:[1.,0.,0.],3:[1.,1.,0.],4:[0.,1.,0.]},elements={1:('S4',[1,2,3,4])})
    grid=grid_from_mesh(mesh)
    assert attach_element_stress(grid,1e-6,result)
    assert grid.cell_data['S IP max Mises'][0]==100


def test_dat_shear_order_is_converted_to_xx_yy_zz_xy_yz_zx(tmp_path):
    path=tmp_path/'job.dat'
    path.write_text(' stresses (elem, integ.pnt.,sxx,syy,szz,sxy,sxz,syz) for set X and time 1.0E-6\n\n'
                    ' 1 1 1 2 3 4 5 6 _shell_0000000001\n')
    mean,_=read_element_stress(path)[1e-6][1]
    np.testing.assert_equal(mean,[1,2,3,4,6,5])
