import json,shutil,hashlib
from pathlib import Path
import numpy as np
import pytest
from system_drop.output_schedule import reconcile_frame_times,select_frame_indices
from system_drop.engine import Engine
from system_drop.model import ROOT,Settings,bundled_calculix
from system_drop.solver_cache import record_completion


def test_drop13_rounding_reproduces_old_failure_and_recovers_without_sorting():
    end=np.nextafter(12.00078,-np.inf)
    reported=np.round(np.linspace(12.0007202,12.00078,263),5)
    old=reported.copy();old[-1]=end
    assert np.any(np.diff(old)<0)
    corrected,audit=reconcile_frame_times(reported,7,offset=end-.00006,end_time=end)
    assert np.all(np.diff(corrected)>=0) and corrected[-1]==end
    indices,_=select_frame_indices(corrected,.00006,.000001,end-.00006)
    assert len(indices)==len(set(indices))==60 and indices==sorted(indices)
    assert indices[-1]==262 and audit['corrected_frames']>0
    assert audit['max_correction_s']<=.000005100001


def test_mixed_header_precision_can_be_reconciled_but_real_reverse_cannot():
    corrected,_=reconcile_frame_times([12.0008,12.00078],[6,7],end_time=12.00078)
    assert corrected==[12.00078,12.00078]
    with pytest.raises(ValueError,match='역행'):
        reconcile_frame_times([12.00078,12.00060],7)
    with pytest.raises(ValueError,match='종료 시간'):
        reconcile_frame_times([12.00060],7,end_time=12.00078)
    with pytest.raises(ValueError):reconcile_frame_times([float('nan')],7)


def test_copy_complete_run_and_resume_only_drop13_postprocessing(tmp_path,monkeypatch):
    settings=Settings(directions=list(range(1,19)),output_root=str(tmp_path/'old'),
        calculix_path='Z:/removed/system_drop/solvers/calculix/bin/ccx_MT.exe')
    engine=Engine(settings);engine.initialize()
    for i in range(12):engine.records[i]={'setup':'done','drop':'done','release':'done'}
    engine.records[12]={'setup':'done','drop':'failed','release':'pending'};engine.save()
    upstream=engine.run/'release_12';upstream.mkdir();(upstream/'job.rout').write_bytes(b'unchanged release 12 state')
    folder=engine.run/'drop_13';folder.mkdir()
    (folder/'job.inp').write_text('*RESTART, READ\n*STEP\n*END STEP\n')
    (folder/'job.rin').write_bytes((upstream/'job.rout').read_bytes())
    (folder/'transfer.json').write_text(json.dumps({'source_file_sha256':hashlib.sha256((upstream/'job.rout').read_bytes()).hexdigest()}))
    (folder/'job.frd').write_bytes(b'preserved frame data');(folder/'job.rout').write_bytes(b'preserved drop 13 material state')
    (folder/'solver.log').write_text('Job finished\nTotal CalculiX Time: 430.688739\n')
    (folder/'conversion_error.txt').write_text('ValueError: 결과 프레임 시간이 역순입니다.')
    record_completion(folder,upstream=upstream/'job.rout')
    copied=tmp_path/'new_version/runs'/engine.run.name;shutil.copytree(engine.run,copied)
    # The original installation can be absent; the copied run is self-contained.
    shutil.rmtree(engine.run)
    resumed=Engine.restore(copied);calls=[]
    assert resumed.next_stage()==(12,'drop')
    assert resumed.settings.calculix_path==str(bundled_calculix())
    def no_solver(*args,**kwargs):raise AssertionError('Completed drop 13 must never rerun')
    monkeypatch.setattr('system_drop.engine.popen',no_solver)
    monkeypatch.setattr('system_drop.engine.resolve_solver_command',no_solver)
    monkeypatch.setattr(resumed,'convert_results',lambda i,s,f:calls.append((i,s)))
    resumed.execute(automatic=False)
    assert calls==[(12,'drop')] and resumed.next_stage()==(12,'release')
    assert all(row=={'setup':'done','drop':'done','release':'done'} for row in resumed.records[:12])
    assert (copied/'drop_13/job.rout').read_bytes()==b'preserved drop 13 material state'
    assert not list((copied/'drop_13').glob('previous_attempt_*'))
    # If a copied input was edited, stop rather than silently recompute.
    (copied/'drop_13/job.inp').write_text('changed input')
    with pytest.raises(RuntimeError,match='자동 재계산을 중단'):
        resumed.run_stage(12,'drop')
    (copied/'drop_13/job.rout').unlink()
    with pytest.raises(RuntimeError,match='자동 재계산을 중단'):
        resumed.run_stage(12,'drop')
