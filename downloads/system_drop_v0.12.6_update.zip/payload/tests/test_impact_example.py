from pathlib import Path
import json
import copy
import pytest
from system_drop.model import ROOT
from system_drop.deck import read_mesh
from system_drop.results import read_state,validate_physical_state,validate_preview_fields


def test_completed_impact_and_stabilization_example_has_finite_native_results():
    root=ROOT/'examples/top_face_impact'
    report=json.loads((root/'summary.json').read_text())
    assert report['success'] and report['increments']==25216
    assert report['mean_body_y_velocity_mm_s']<0
    assert report['max_equivalent_plastic_strain']>0
    assert report['stabilization']['success']
    assert report['stabilization']['final_total_time_s']==pytest.approx(1.00006)
    mesh=read_mesh(root/'drop/calculix_mesh.inp')
    for phase in ('drop','stabilization'):
        state=read_state(root/phase/'results/state.json')
        validate_physical_state(state,mesh)
        validate_preview_fields(root/phase/'results')


def test_bad_state_cannot_be_treated_as_completed_analysis():
    root=ROOT/'examples/top_face_impact/drop'
    mesh=read_mesh(root/'calculix_mesh.inp');state=read_state(root/'results/state.json')
    first=next(iter(state['coordinates']))
    bad=copy.deepcopy(state);bad['coordinates'][first][0]=float('nan')
    with pytest.raises(ValueError,match='비유한'):validate_physical_state(bad,mesh)
    bad=copy.deepcopy(state);bad['velocities'].pop(first)
    with pytest.raises(ValueError,match='속도'):validate_physical_state(bad,mesh)
