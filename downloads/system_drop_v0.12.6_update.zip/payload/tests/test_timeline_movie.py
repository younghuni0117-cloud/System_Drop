from pathlib import Path
import json,subprocess,shutil
import numpy as np
from system_drop.timeline import display_transform,rotation_between,collect_stages,build_records
from system_drop.movie import AviWriter


def stage(number,phase='drop',normal=1):
    # +Y-facing plane at y=10, or -Y-facing plane after changing direction.
    floor=[[-20,10,-20],[-20,10,20],[20,10,20],[20,10,-20]]
    if normal==-1:floor=list(reversed(floor))
    return {'folder':str(Path('/tmp')/f'{phase}_{number:02d}'),'phase':phase,'number':number,
            'metadata':{'floor':floor,'gap':.001},'records':[{'file':'frame.vtu','time':number}], 'title':phase}


def test_floor_fixed_and_product_center_transforms_preserve_distances():
    points=np.array([[-2,11,-3],[2,15,3]],dtype=float)
    for mode in ['center','floor']:
        values,floor,r,offset=display_transform(points,{'stage':stage(1),'kind':'result'},mode,floor_span=30)
        assert np.linalg.norm(values[1]-values[0])==np.linalg.norm(points[1]-points[0])
        if mode=='center':np.testing.assert_allclose((values.min(0)+values.max(0))/2,0)
        else:np.testing.assert_allclose(floor[:,1],0)


def test_center_transition_keeps_product_fixed_and_floor_outside_product():
    points=np.array([[-2,-1,-3],[2,1,3]],float)
    source=stage(1);target=stage(2,normal=-1)
    record={'stage':source,'transition_to':target,'kind':'transition','alpha':.5}
    shown,floor,_,_=display_transform(points,record,'center')
    np.testing.assert_allclose(shown,points)
    normal=np.cross(floor[1]-floor[0],floor[2]-floor[1]);normal/=np.linalg.norm(normal)
    assert np.min((shown-floor.mean(axis=0))@normal)>0


def test_half_turn_transition_is_a_proper_rotation():
    a=np.eye(3);b=np.diag([-1,-1,1])
    for t in [0,.25,.5,.75,1]:
        r=rotation_between(a,b,t)
        np.testing.assert_allclose(r.T@r,np.eye(3),atol=1e-12)
        assert np.linalg.det(r)>0.999999
    np.testing.assert_allclose(rotation_between(a,b,1),b,atol=1e-12)


def test_only_completed_stages_are_played_and_transitions_are_labeled(tmp_path):
    (tmp_path/'settings.json').write_text(json.dumps({'directions':[1,2]}))
    (tmp_path/'checkpoint.json').write_text(json.dumps({'records':[{'drop':'done','release':'done'},{'drop':'done','release':'running'}]}))
    for i in [1,2]:
        drop=tmp_path/f'drop_{i:02d}';drop.mkdir();(drop/'setup.json').write_text('{}')
        for name in [f'drop_{i:02d}',f'release_{i:02d}']:
            p=tmp_path/name/'results';p.mkdir(parents=True,exist_ok=True);(p/'frames.json').write_text('[{"time":0,"file":"f.vtu"}]')
    stages=collect_stages(tmp_path);assert len(stages)==3
    records=build_records(stages,4);assert len(records)==7
    assert sum(r['kind']=='transition' for r in records)==4
    assert all(r['time']==0 for r in records)


def test_avi_is_decodable_and_cancel_preserves_previous_file(tmp_path):
    path=tmp_path/'motion.avi'
    writer=AviWriter(path,64,48,5)
    for i in range(3):writer.add(np.full((48,64,3),i*70,dtype=np.uint8))
    writer.close()
    assert path.read_bytes()[:4]==b'RIFF'
    if shutil.which('ffprobe'):
        data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-of','json',str(path)]))
        stream=data['streams'][0];assert stream['codec_name']=='mjpeg' and stream['nb_frames']=='3'
        assert stream['width']==64 and stream['height']==48
    original=path.read_bytes();writer=AviWriter(path,64,48,5);writer.add(np.zeros((48,64,3),dtype=np.uint8));writer.abort()
    assert path.read_bytes()==original and not writer.temp.exists()


def test_streaming_gif_preserves_frame_count_and_cancelled_target(tmp_path):
    from system_drop.movie import GifWriter
    from PIL import Image
    path=tmp_path/'motion.gif';writer=GifWriter(path,64,48,5)
    for i in range(3):writer.add(np.full((48,64,3),i*70,dtype=np.uint8))
    writer.close()
    with Image.open(path) as result:
        assert result.n_frames==3 and result.info['duration']==200
    original=path.read_bytes();writer=GifWriter(path,64,48,5)
    writer.add(np.zeros((48,64,3),dtype=np.uint8));writer.abort()
    assert path.read_bytes()==original and not writer.temp.exists()
