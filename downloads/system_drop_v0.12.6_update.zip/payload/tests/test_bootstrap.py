from pathlib import Path
from types import SimpleNamespace
import pytest
import bootstrap_windows as boot


def test_no_missing_packages_never_calls_pip():
    def fail(*args,**kwargs): raise AssertionError("pip must not run")
    assert boot.ensure_requirements(Path("python.exe"),[],run=fail)==0


def test_install_only_missing_packages_without_upgrade_or_reinstall():
    commands=[]
    def run(args,**kwargs):
        commands.append(args);return SimpleNamespace(returncode=0)
    assert boot.ensure_requirements(Path("python.exe"),["pyvistaqt>=0.11"],run=run)==0
    assert commands==[["python.exe","-m","pip","install","pyvistaqt>=0.11"]]


def test_reuses_complete_existing_environment_instead_of_installing(monkeypatch):
    paths=[Path("current/python.exe"),Path("old_version/.venv/python.exe")]
    monkeypatch.setattr(boot,"candidate_interpreters",lambda root:iter(paths))
    selected,missing=boot.select_interpreter(Path("project"),probe=lambda p:["PySide6>=6.6"] if p==paths[0] else [])
    assert selected==paths[1] and missing==[]


def test_virtualenv_interpreter_symlink_is_not_resolved_to_base_python(tmp_path,monkeypatch):
    base=tmp_path/"base_python";base.write_text("binary")
    venv=tmp_path/".venv/bin/python";venv.parent.mkdir(parents=True)
    try: venv.symlink_to(base)
    except OSError: pytest.skip("Symlink permission not available")
    monkeypatch.delenv("SYSTEM_DROP_PYTHON",raising=False)
    monkeypatch.setattr(boot.sys,"executable",str(venv))
    assert next(boot.candidate_interpreters(tmp_path))==venv


def test_isolated_python_can_import_local_offline_helper_from_another_directory(tmp_path):
    import subprocess, sys, shutil
    project=tmp_path/'누적 드랍'/'system_drop'
    project.mkdir(parents=True)
    source=Path(boot.__file__)
    shutil.copy2(source,project/source.name)
    shutil.copy2(source.with_name('offline_setup.py'),project/'offline_setup.py')
    code="import runpy,sys; runpy.run_path(sys.argv[1],run_name='isolated_bootstrap'); import offline_setup; print(offline_setup.__file__)"
    result=subprocess.run([sys.executable,'-I','-c',code,str(project/source.name)],cwd=tmp_path,capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    assert str(project/'offline_setup.py') in result.stdout


def test_isolated_gui_child_resolves_moved_project_without_pth_or_pythonpath(tmp_path):
    import subprocess, sys, shutil
    project=tmp_path/'누적 드랍'/'system_drop'
    package=project/'system_drop'
    package.mkdir(parents=True)
    (package/'__init__.py').write_text('')
    (package/'gui.py').write_text("import argparse,sys\nargparse.ArgumentParser().parse_args()\nassert sys.argv[0].endswith('gui.py')\nprint('ISOLATED_GUI_FOUND')")
    shutil.copy2(Path(boot.__file__),project/'bootstrap_windows.py')
    result=subprocess.run([sys.executable,'-I',str(project/'bootstrap_windows.py'),'--gui'],cwd=tmp_path,capture_output=True,text=True)
    assert result.returncode==0,result.stderr+result.stdout
    assert 'ISOLATED_GUI_FOUND' in result.stdout


def test_portable_path_repair_preserves_already_installed_packages(tmp_path,monkeypatch):
    target=tmp_path/'runtime/python311'
    packages=target/'Lib/site-packages'
    packages.mkdir(parents=True)
    installed=packages/'installed_package.py'
    installed.write_text('KEEP=1')
    pth=target/'python311._pth'
    pth.write_text('python311.zip\n.\nimport site\n')
    monkeypatch.setattr(boot.sys,'executable',str(target/'python.exe'))
    monkeypatch.setattr(boot.sys,'path',list(boot.sys.path))
    boot.configure_portable_paths(tmp_path)
    assert '../..' in pth.read_text()
    assert 'Lib/site-packages' in pth.read_text()
    assert str(packages) in boot.sys.path
    assert installed.read_text()=='KEEP=1'
    before=pth.stat().st_mtime_ns
    boot.configure_portable_paths(tmp_path)
    assert pth.stat().st_mtime_ns==before


def test_path_repair_does_not_modify_system_or_virtual_environment(tmp_path,monkeypatch):
    target=tmp_path/'runtime/python311'
    target.mkdir(parents=True)
    pth=target/'python311._pth'
    pth.write_text('unchanged')
    monkeypatch.setattr(boot.sys,'executable',str(tmp_path/'other/python.exe'))
    boot.configure_portable_paths(tmp_path)
    assert pth.read_text()=='unchanged'


def test_isolated_viewer_resolves_current_copy_and_preserves_viewer_arguments(tmp_path):
    import subprocess,sys,shutil,json
    project=tmp_path/'현재 복사본'/'system_drop'
    package=project/'system_drop';package.mkdir(parents=True)
    (package/'__init__.py').write_text('')
    (package/'viewer.py').write_text("import argparse,json,sys\np=argparse.ArgumentParser()\np.add_argument('folder')\np.add_argument('--setup',action='store_true')\np.add_argument('--workflow',action='store_true')\np.add_argument('--screenshot')\na=p.parse_args()\nprint(json.dumps({'file':__file__,'folder':a.folder,'setup':a.setup,'workflow':a.workflow,'screenshot':a.screenshot,'program':sys.argv[0]}))")
    shutil.copy2(Path(boot.__file__),project/'bootstrap_windows.py')
    old=tmp_path/'old_runtime';old.mkdir()
    folder=tmp_path/'해석 결과'/'drop_06';shot=tmp_path/'그림.png'
    result=subprocess.run([sys.executable,'-I',str(project/'bootstrap_windows.py'),'--viewer',str(folder),'--setup','--workflow','--screenshot',str(shot)],cwd=old,capture_output=True,text=True)
    assert result.returncode==0,result.stdout+result.stderr
    output=json.loads(result.stdout)
    assert output['file']==str(package/'viewer.py')
    assert output['folder']==str(folder) and output['setup'] and output['workflow']
    assert output['screenshot']==str(shot)
    assert output['program'].endswith('viewer.py')


def test_viewer_command_uses_current_absolute_launcher_with_an_old_interpreter(tmp_path,monkeypatch):
    from system_drop import launching
    root=tmp_path/'new copy';old=tmp_path/'old copy/runtime/python311/python.exe'
    monkeypatch.setattr(launching,'ROOT',root)
    monkeypatch.setattr(launching.sys,'executable',str(old))
    args=launching.viewer_command(tmp_path/'drop_06','--setup')
    assert args==[str(old),str(root/'bootstrap_windows.py'),'--viewer',str(tmp_path/'drop_06'),'--setup']
