from pathlib import Path
import pytest
from system_drop.solver import resolve_solver_command


def test_default_ccx_command_resolves_but_preserves_arguments(tmp_path,monkeypatch):
    exe=tmp_path/"with spaces"/"ccx.exe";exe.parent.mkdir();exe.write_bytes(b"binary")
    monkeypatch.setattr("system_drop.solver.shutil.which",lambda *args:None)
    monkeypatch.setattr("system_drop.solver.bundled_calculix",lambda:exe)
    assert resolve_solver_command(["ccx","-i","job"],"calculix")==[str(exe),"-i","job"]


def test_missing_solver_explains_winerror_2_and_keeps_deck_separate(monkeypatch):
    monkeypatch.setattr("system_drop.solver.shutil.which",lambda *args:None)
    monkeypatch.setattr("system_drop.solver.bundled_calculix",lambda:Path('/not-present/ccx_MT.exe'))
    with pytest.raises(FileNotFoundError,match="입력 파일 오류가 아니라 Solver 경로 설정"):
        resolve_solver_command(["ccx","-i","job"],"calculix")


def test_release_contains_real_windows_solver_and_its_dlls():
    import json,hashlib
    from system_drop.model import ROOT,bundled_calculix,Settings
    p=bundled_calculix()
    assert p.read_bytes()[:2]==b'MZ'
    assert p.stat().st_size>1_000_000
    for name in ('pthreadGC2.dll','libgcc_s_seh-1.dll','libgfortran-3.dll','libwinpthread-1.dll','libquadmath-0.dll'):
        assert (p.parent/name).read_bytes()[:2]==b'MZ'
    manifest=json.loads((ROOT/'solvers/calculix/manifest.json').read_text())
    assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest['files'][p.name]
    from system_drop.solver import command_args
    assert command_args(Settings().calculix_command,job='job')[0]==str(p)


def test_explicit_external_solver_path_overrides_bundled_one(tmp_path):
    exe=tmp_path/'custom solver'/'ccx.exe';exe.parent.mkdir();exe.write_bytes(b'MZ fixture')
    assert resolve_solver_command([str(exe),'-i','job'],'calculix')[0]==str(exe)
