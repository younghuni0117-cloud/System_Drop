from pathlib import Path
import json,shutil
import pytest
from system_drop.model import ROOT,Settings
from system_drop.engine import Engine
from system_drop.solver import setup_drop
from system_drop.output_schedule import configure_output
from system_drop.template_adapter import set_dynamic_times


def test_output_requests_preserve_scope_options_variables_and_remove_conflicts():
    text='*STEP\n*OUTPUT, FIELD, VARIABLE=PRESELECT, NUMBER INTERVAL=20\n*OUTPUT, HISTORY,\n ** comment\n FREQUENCY=5, FILTER=ANTIALIASING\n*NODE OUTPUT, NSET=WATCH\nU1, V1\n*ENERGY OUTPUT\nALLKE\n*END STEP\n'
    out=configure_output(text,'abaqus',.007,.00001)
    assert 'VARIABLE=PRESELECT' in out and 'FILTER=ANTIALIASING' in out
    assert out.count('TIME INTERVAL=0.00001')==2
    assert 'FREQUENCY=' not in out and 'NUMBER INTERVAL=' not in out
    assert '*NODE OUTPUT, NSET=WATCH\nU1, V1' in out
    assert configure_output(out,'abaqus',.007,.00001)==out
    assert configure_output(text,'abaqus',.007,0)==text


def test_keyword_continuation_comments_scaling_and_fixed_mode_handling():
    text='*DYNAMIC,\n EXPLICIT, ELEMENT BY ELEMENT\n** times\n, .02, .8, .000001\n'
    out=set_dynamic_times(text,', 0.007, , 0.00001',solver='abaqus')
    assert 'ELEMENT BY ELEMENT' in out and ', 0.007, .8, 0.00001' in out
    fixed=set_dynamic_times('*DYNAMIC, EXPLICIT, DIRECT USER CONTROL\n.001,.02\n',', 0.007, , 0.00001',solver='abaqus')
    assert 'DIRECT USER CONTROL' not in fixed
    assert ', 0.007, , 0.00001' in fixed
    continued=set_dynamic_times('*DYNAMIC,\n EXPLICIT,\n FIXED TIME INCREMENTATION\n, .02\n',', 0.007, , 0.00001',solver='abaqus')
    assert 'FIXED TIME INCREMENTATION' not in continued and continued.count('0.007')==1
    assert ', .02' not in continued


@pytest.mark.parametrize('maximum,period',[(.00001,.001),(.000003,.007),(0,.02)])
def test_actual_execution_input_reflects_gui_without_abaqus_and_preserves_source(tmp_path,maximum,period):
    source=tmp_path/'template';shutil.copytree(ROOT/'template_abaqus',source)
    before={p.name:p.read_bytes() for p in source.iterdir()}
    s=Settings(solver='abaqus',template=str(source),directions=[1],drop_dt=0,drop_max_dt=maximum,drop_time=period,output_root=str(tmp_path/'runs'))
    e=Engine(s);e.initialize();folder=setup_drop(s,e.run,0,e.log)
    report=json.loads((folder/'input_settings.json').read_text())
    assert report['passed'] and report['actual']['period_s']==period and report['actual']['maximum_increment_s']==maximum
    if maximum:assert all(float(p['TIME INTERVAL'])==maximum for p in report['actual']['output_requests'])
    assert before=={p.name:p.read_bytes() for p in source.iterdir()}
    assert (folder/'README_INPUT.txt').exists()


def test_missing_history_request_is_added_without_replacing_field_variables():
    result=configure_output('*STEP\n*OUTPUT, FIELD\n*NODE OUTPUT\nU1\n*END STEP\n','abaqus',.001,.00001)
    assert '*NODE OUTPUT\nU1' in result
    assert '*OUTPUT, HISTORY, TIME INTERVAL=0.00001' in result
