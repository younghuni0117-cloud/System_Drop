import gzip,struct,os,json
from pathlib import Path
import pytest
from system_drop.restart import NativeRestart
from system_drop.restart_recovery import recover_overlay_error,without_overlay,overlay_rename_error
from system_drop.solver_cache import record_completion,reusable_completion
from system_drop.model import ROOT

ERROR='Error opening source file: 2\n*ERROR in restartwrite:\n Temporary restart file with name\n temporaryrestartfile cannot be renamed\nJob finished\n'


@pytest.fixture
def failed(tmp_path):
    folder=tmp_path/'drop_02';folder.mkdir()
    raw=gzip.decompress((Path(__file__).parent/'fixtures/plastic_release_223.rout.gz').read_bytes())
    incoming=folder/'job.rin';incoming.write_bytes(raw)
    native=NativeRestart.read(incoming);native.records[native.fields['step']]=struct.pack('<i',3)
    native.replace('ttime',[float(native.doubles('ttime')[0])+2e-5])
    (folder/'job.inp').write_text('*RESTART, READ\n*STEP\n*DYNAMIC, EXPLICIT=2\n1e-7, 2e-5, 1e-12, 1e-6\n*RESTART, WRITE, OVERLAY, FREQUENCY=1\n*END STEP\n')
    (folder/'calculix_mesh.inp').write_bytes((ROOT/'tests/fixtures/legacy_calculix/calculix_mesh.inp').read_bytes())
    native.write(folder/'job.rout');(folder/'job.frd').write_text('FRD placeholder for cache test')
    (folder/'solver.log').write_text(ERROR)
    return folder


def test_complete_rout_recovers_known_error_without_changing_material_bytes(failed):
    before=(failed/'job.rout').read_bytes();report=recover_overlay_error(failed)
    assert report['recovered'] and report['step']==3
    assert (failed/'job.rout').read_bytes()==before
    assert (failed/'solver.log').read_text()==ERROR
    record_completion(failed,recovery=report)
    assert reusable_completion(failed)


def test_complete_temporary_file_is_copied_and_preserved(failed):
    (failed/'job.rout').rename(failed/'temporaryrestartfile')
    report=recover_overlay_error(failed)
    assert report['source']=='temporaryrestartfile'
    assert (failed/'job.rout').read_bytes()==(failed/'temporaryrestartfile').read_bytes()


@pytest.mark.parametrize('kind',['stale_time','stale_step','truncated','other_error','input_changed'])
def test_incomplete_or_unrelated_error_never_counts_as_completion(failed,kind):
    if kind in ('stale_time','stale_step'):
        r=NativeRestart.read(failed/'job.rout')
        if kind=='stale_time':r.replace('ttime',[1.00006])
        else:r.records[r.fields['step']]=struct.pack('<i',2)
        r.write(failed/'job.rout')
    elif kind=='truncated':(failed/'job.rout').write_bytes((failed/'job.rout').read_bytes()[:-4])
    elif kind=='other_error':(failed/'solver.log').write_text(ERROR+'*ERROR: invalid material\n')
    else:
        future=(failed/'solver.log').stat().st_mtime+10;os.utime(failed/'job.inp',(future,future))
    assert recover_overlay_error(failed) is None
    assert not reusable_completion(failed)


def test_only_write_overlay_flag_is_removed():
    text='** OVERLAY note\n*RESTART, READ\n*RESTART, WRITE, FREQUENCY=1, OVERLAY\n'
    out=without_overlay(text)
    assert '** OVERLAY note' in out and '*RESTART, READ' in out
    assert '*RESTART, WRITE, FREQUENCY=1\n' in out
    assert overlay_rename_error(ERROR)


def test_persisted_overlay_flag_clears_without_changing_any_physical_record(failed):
    from system_drop.restart import disable_restart_overlay,equivalent_except_restart_output
    source=failed/'job.rout';r=NativeRestart.read(source)
    flags=r.ints('irstrt').copy();flags[1]=1;r.records[r.fields['irstrt']]=flags.astype('<i4').tobytes();r.write(source)
    dest=failed/'next.rin';dest.write_bytes(source.read_bytes())
    original=NativeRestart.read(source)
    assert disable_restart_overlay(dest)
    current=NativeRestart.read(dest)
    assert current.ints('irstrt')[1]==0 and original.ints('irstrt')[1]==1
    assert equivalent_except_restart_output(source,dest)
    assert current.history_hashes()==original.history_hashes()
    assert not disable_restart_overlay(dest)
