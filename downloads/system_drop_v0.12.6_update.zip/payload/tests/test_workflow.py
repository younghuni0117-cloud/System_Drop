from pathlib import Path
import json
import threading
import numpy as np
import pytest

from system_drop.deck import read_mesh, template_defaults
from system_drop.engine import Engine
from system_drop.model import Settings, ROOT, new_run
from system_drop.solver import command_args, progress_from_sta, prepare_release, setup_drop


@pytest.mark.parametrize("solver",["abaqus","calculix"])
def test_templates_and_product_labels(solver):
    p=ROOT/f"template_{solver}"
    mesh=read_mesh(p/f"{solver}_main.inp")
    assert len(mesh.product_elements)==384
    assert len(mesh.product_nodes)==585
    values=template_defaults(p/f"{solver}_main.inp")
    assert values["drop_time"]==(.000060 if solver=='calculix' else .02)
    assert values["drop_dt"]==(1e-7 if solver=="calculix" else 0)
    assert values["drop_max_dt"]==1e-6
    assert len(mesh.reference_points())==3


def test_snapshot_setup_preserves_model_and_updates_all_product_sets(tmp_path):
    s=Settings(directions=[7],output_root=str(tmp_path),gap=3,drop_time=.015)
    engine=Engine(s,workflow=True);engine.initialize()
    folder=setup_drop(s,engine.run,0,engine.log,workflow=True)
    original=(Path(s.template)/"calculix_main.inp").read_text()
    output=(folder/"job.inp").read_text()
    for token in ("*SOLID SECTION, ELSET=BODY_1", "*CONTACT PAIR"):
        assert output.count(token)==original.count(token)==1
    assert "0.015" in output
    data=json.loads((folder/"setup.json").read_text())
    assert data["direction"][1]==0
    assert np.linalg.norm(data["velocity"])**2==pytest.approx(2*9810*997)
    assert (folder/"calculix_material.inp").read_bytes()==(Path(s.template)/"calculix_material.inp").read_bytes()
    mesh=read_mesh(folder/"job.inp")
    assert set(mesh.elsets["AUTO_PRODUCT_ELEMENTS"])==set(mesh.product_elements)


def test_workflow_sequence_duplicates_and_checkpoint(tmp_path):
    s=Settings(directions=[1,7,7],output_root=str(tmp_path))
    events=[]
    e=Engine(s,workflow=True,emit=lambda t,d:events.append((t,d)))
    e.execute()
    assert all(all(status=="done" for status in row.values()) for row in e.records)
    assert e.next_stage() is None
    assert (e.run/"release_03/results/state.json").exists()
    assert not list(e.run.rglob("*.frd"))
    assert not list(e.run.rglob("*.odb"))
    state=json.loads((e.run/"release_03/results/state.json").read_text())
    assert state["workflow_only"]
    restored=Engine.restore(e.run)
    assert restored.records==e.records and restored.workflow
    assert restored.durations==e.durations
    assert len(e.durations)==9 and all(t>=0 for t in e.durations.values())
    assert [d["overall"] for t,d in events if t=="progress"][-1]==100


def test_pause_only_after_current_stage_and_manual_resume(tmp_path):
    e=Engine(Settings(directions=[1],output_root=str(tmp_path)),workflow=True)
    def emit(name,data):
        if name=="status" and data["status"]=="running": e.stop_after.set()
    e.emit=emit; e.execute()
    assert e.next_stage()==(0,"drop")
    e.emit=lambda *args:None
    e.execute(automatic=False)
    assert e.next_stage()==(0,"release")
    e.execute(automatic=False)
    assert e.next_stage() is None


def test_missing_executable_fails_without_advancing(tmp_path):
    e=Engine(Settings(directions=[1,2],output_root=str(tmp_path),calculix_command="/missing/ccx -i {job}"))
    e.execute(automatic=False);e.execute(automatic=False)
    assert e.records[0]=={"setup":"done","drop":"failed","release":"pending"}
    assert e.records[1]["setup"]=="pending"


def test_calculix_release_uses_native_restart_and_removes_contact(tmp_path):
    import gzip,shutil
    from system_drop.restart import NativeRestart
    s=Settings(directions=[1]); run=tmp_path
    shutil.copytree(ROOT/'tests/fixtures/legacy_calculix',run/'template_snapshot')
    (run/"drop_01").mkdir();(run/"drop_01/job.rout").write_bytes(gzip.decompress((Path(__file__).parent/'fixtures/plastic_release_223.rout.gz').read_bytes()))
    folder=prepare_release(s,run,0,lambda *args:None)
    assert NativeRestart.read(folder/'job.rin').history_hashes()==NativeRestart.read(run/'drop_01/job.rout').history_hashes()
    assert NativeRestart.read(folder/'job.rin').doubles('xmodal')[0]==20
    text=(folder/"job.inp").read_text()
    assert "*RESTART, READ" in text
    assert "*MODEL CHANGE, TYPE=CONTACT PAIR, REMOVE" in text
    assert "GRAV, 0." in text
    assert "*CONTROLS, PARAMETERS=FIELD" in text
    assert "0.005, 0.01, , 1., 0.02, 0.005" in text
    assert "*INITIAL CONDITIONS" not in text
    assert "0.01, 1, 0.0000000001, 0.01" in text


def test_bad_settings_and_non_overwriting_runs(tmp_path):
    s=Settings(gap=1001)
    with pytest.raises(ValueError): s.validate()
    s=Settings(release_dt=.02,release_max_dt=.01)
    with pytest.raises(ValueError): s.validate()
    a=new_run(tmp_path,"calculix");b=new_run(tmp_path,"calculix")
    assert a!=b and a.name.endswith("r01") and b.name.endswith("r02")


def test_command_paths_with_spaces_are_single_arguments():
    args=command_args('"C:/Program Files/ccx.exe" -i {job}',job="drop 01")
    assert args==["C:/Program Files/ccx.exe","-i","drop 01"]
    args=command_args("abaqus job={job} {oldjob} interactive",job="job",previous_job="C:/runs/drop 01/job")
    assert args==["abaqus","job=job","oldjob=C:/runs/drop 01/job","interactive"]


def test_status_progress_uses_step_time_and_caps_before_validation():
    assert progress_from_sta("  2 10 1 3  1.500  .500  .01", "calculix",1)==50
    assert progress_from_sta("  2 10 1 3  9.000  1.000  .01", "calculix",1)==99.9
    assert progress_from_sta("  100  .010  .010  00:00:01 .00001 1 1", "abaqus",.02)==50
    assert progress_from_sta("  1 10 1 0 1 1 1.50 .50 .01", "abaqus",1,"release")==50


def test_calculix_accepts_actual_multiple_direction_sequence():
    Settings(directions=[1,2,7,11]).validate_runtime_scope(True,False)


def test_abaqus_native_import_removes_rigid_velocity_without_tie(tmp_path):
    from system_drop.solver import prepare_bridge
    from system_drop.deck import expanded_lines
    s=Settings(solver="abaqus",template=str(ROOT/"template_abaqus"),directions=[1,7],output_root=str(tmp_path))
    e=Engine(s,workflow=True);e.initialize()
    setup_drop(s,e.run,0,e.log,workflow=True)
    mesh=read_mesh(ROOT/"template_abaqus/abaqus_mesh.inp")
    coords={n:[p[0]+12,p[1]-8,p[2]+3] for n,p in mesh.product_nodes.items()}
    velocities={n:[11,22,33,0,0,0] for n in mesh.product_nodes}
    results=e.run/"drop_01/results";results.mkdir()
    (results/"state.json").write_text(json.dumps({"coordinates":coords,"velocities":velocities}))
    folder=prepare_release(s,e.run,0,e.log)
    text='\n'.join(expanded_lines(folder/'abaqus_main.inp'))
    assert "*IMPORT, UPDATE=YES, STATE=YES" in text
    assert "APPLICATION=QUASI-STATIC" in text
    assert text.count("*TIE")==0
    assert "*MATERIAL" not in text and "*SOLID SECTION" not in text
    assert "FLOOR_SURFACE" not in text and "*DLOAD" not in text
    audit=json.loads((folder/'stabilization_transfer.json').read_text())
    assert audit['kinetic_after_Nmm']<1e-20
    assert '*DASHPOT, ELSET=' in text
    assert '*ELEMENT, TYPE=DASHPOT1' in text
    next_results=e.run/"release_01/results";next_results.mkdir()
    (next_results/"state.json").write_text((results/"state.json").read_text())
    drop=setup_drop(s,e.run,1,e.log,workflow=False)
    text='\n'.join(expanded_lines(drop/'abaqus_main.inp'))
    assert text.count("*TIE")==0
    assert "*IMPORT, UPDATE=YES, STATE=YES" in text
    assert "*RIGID BODY" in text
    assert text.count("*CONTACT PAIR")==1
    metadata=json.loads((drop/"setup.json").read_text())
    assert metadata["origin"]==coords[mesh.nsets["FRAME_ORIGIN"][0]]


def test_user_drop_increment_and_edge_angle_reach_generated_deck(tmp_path):
    s=Settings(directions=[11],drop_dt=2e-8,drop_max_dt=5e-7,edge_angle=40,output_root=str(tmp_path))
    e=Engine(s,workflow=True);e.initialize()
    folder=setup_drop(s,e.run,0,e.log,workflow=True)
    text=(folder/"job.inp").read_text()
    assert '0.00000002, 0.00006, 0.000000000001, 0.0000005' in text
    data=json.loads((folder/"setup.json").read_text())
    assert abs(data['direction'][1])==pytest.approx(np.cos(np.radians(40)))


def test_abaqus_automatic_increment_uses_fourth_field_maximum_only():
    from system_drop.solver import drop_time_line
    s=Settings(solver='abaqus',drop_dt=0,drop_max_dt=5e-7)
    s.drop_time=.02
    assert drop_time_line(s)==', 0.02, , 0.0000005'


def test_moved_cumulative_run_resumes_from_its_frozen_template(tmp_path):
    import shutil
    template=tmp_path/'original_template'
    shutil.copytree(ROOT/'template_calculix',template)
    e=Engine(Settings(template=str(template),directions=[1,7],output_root=str(tmp_path/'runs')),workflow=True)
    e.execute(automatic=False)
    shutil.rmtree(template)
    moved=tmp_path/'moved_run';shutil.move(str(e.run),moved)
    resumed=Engine.restore(moved)
    resumed.execute()
    assert resumed.next_stage() is None
    assert Path(resumed.settings.template)==moved/'template_snapshot'
