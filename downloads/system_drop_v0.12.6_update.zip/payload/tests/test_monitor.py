import os
import time
import pytest
from system_drop.monitor import cpu_seconds,dat_time,dat_increment,stable_increment,SolverMonitor


def test_actual_calculix_dat_headers_and_stable_step():
    text='INCREMENT 1000\n displacements (vx,vy,vz) for set FRAME_ORIGIN and time 0.2379520E-05\n'
    assert dat_increment(text)==1000
    assert dat_time(text)==pytest.approx(2.37952e-6)
    assert dat_time('velocities for set X and time 2.5000D-05')==2.5e-5
    assert stable_increment('SELECTED time increment (based on contact):2.379520e-09')==pytest.approx(2.37952e-9)
    assert dat_time('header only') is None


def test_cpu_time_of_running_process_is_measured_not_fabricated():
    a=cpu_seconds(os.getpid())
    if a is None:pytest.skip('OS does not expose process CPU time')
    until=time.monotonic()+.04
    while time.monotonic()<until:pass
    b=cpu_seconds(os.getpid())
    assert b>=a


def test_monitor_reads_real_time_without_frd_and_respects_restart_offset(tmp_path):
    (tmp_path/'job.dat').write_text('INCREMENT 500\n velocities for set X and time 0.020001\n')
    (tmp_path/'solver.log').write_text('SELECTED time increment:2.e-9\n')
    m=SolverMonitor(os.getpid(),tmp_path)
    data=m.sample(1.,offset=.02)
    assert data['state']=='해석 시간 진행 확인'
    assert data['sim_time']==pytest.approx(1e-6)
    assert data['increment']==500
    assert data['mean_dt']==pytest.approx(2e-9)
    assert data['percent']==pytest.approx(.0001)
    assert data['estimated_increments']==500_000_000


def test_cpu_activity_alone_is_not_reported_as_time_progress(tmp_path,monkeypatch):
    values=iter([1.,2.])
    monkeypatch.setattr('system_drop.monitor.cpu_seconds',lambda pid:next(values))
    m=SolverMonitor(123,tmp_path);m.previous_wall-=1
    data=m.sample(.02)
    assert data['cpu_percent']>0
    assert data['sim_time'] is None and data['percent'] is None
    assert '출력 대기' in data['state']


def test_quiet_process_is_not_automatically_claimed_to_be_running_analysis(tmp_path,monkeypatch):
    monkeypatch.setattr('system_drop.monitor.cpu_seconds',lambda pid:0.)
    m=SolverMonitor(123,tmp_path);m.last_advance-=31
    data=m.sample(.02)
    assert '진행 근거 없음' in data['state']
    assert data['percent'] is None


def test_observation_output_does_not_duplicate_user_prints():
    from system_drop.solver import observation_output
    text='*STEP\n*DYNAMIC, EXPLICIT=2\n1e-7,.02\n*NODE FILE, FREQUENCY=7500\nU,V\n*END STEP\n'
    output=observation_output(text)
    assert '*NODE PRINT, NSET=FRAME_ORIGIN, FREQUENCY=500' in output
    assert observation_output(output)==output
    user='*NODE PRINT, NSET=USER_SET\nU\n*END STEP\n'
    assert observation_output(user)==user
