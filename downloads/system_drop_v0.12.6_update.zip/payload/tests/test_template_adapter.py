from pathlib import Path
import json,shutil
import numpy as np
import pytest
from system_drop.model import ROOT,Settings
from system_drop.solver import snapshot_template,setup_drop,prepare_release
from system_drop.deck import read_mesh,expanded_lines,keyword,logical_lines
from system_drop.template_adapter import validate_contract
from system_drop.abaqus_audit import audit_abaqus
from system_drop.assembly import flatten_assembly


def make_template(tmp_path):
    source=tmp_path/'template';shutil.copytree(ROOT/'template_abaqus',source)
    path=source/'abaqus_main.inp';path.write_text('\n'.join(line for line in path.read_text().splitlines() if not line.strip().startswith('** AUTO:'))+'\n')
    return source


def test_marker_free_deck_retains_material_properties_and_custom_interaction(tmp_path):
    source=make_template(tmp_path);main=source/'abaqus_main.inp'
    main.write_text(main.read_text().replace('FLOOR_CONTACT','CUSTOM_CONTACT').replace('*DYNAMIC, EXPLICIT\n','*dynamic,\n explicit\n** user comment before time data\n'))
    material=source/'abaqus_material.inp';material.write_text(material.read_text()+'*EXPANSION\n0.000023\n')
    before=material.read_bytes();run=tmp_path/'run';run.mkdir();settings=Settings(solver='abaqus',template=str(source),directions=[1])
    snap=snapshot_template(settings,run);assert validate_contract(snap,'abaqus')['product_elements']==384
    assert (snap/'abaqus_material.inp').read_bytes()==before
    folder=setup_drop(settings,run,0,lambda *a:None,True)
    text='\n'.join(expanded_lines(folder/'abaqus_main.inp'));assert 'CUSTOM_CONTACT' in text and '** user comment before time data' in text
    assert audit_abaqus(folder/'abaqus_main.inp')['passed']
    state=folder/'results';state.mkdir();mesh=read_mesh(snap/'abaqus_mesh.inp')
    (state/'state.json').write_text(json.dumps({'coordinates':mesh.product_nodes,'velocities':{n:[0,0,0] for n in mesh.product_nodes}}))
    release=prepare_release(settings,run,0,lambda *a:None);assert audit_abaqus(release/'abaqus_main.inp')['passed']


def test_profile_surface_alias_does_not_rename_same_named_material(tmp_path):
    source=make_template(tmp_path)
    main=source/'abaqus_main.inp';mesh=source/'abaqus_mesh.inp';mat=source/'abaqus_material.inp'
    main.write_text(main.read_text().replace('ALUMINUM','CUSTOM_SURF').replace('PRODUCT_CONTACT','CUSTOM_SURF'))
    mesh.write_text(mesh.read_text().replace('PRODUCT_CONTACT','CUSTOM_SURF').replace('FRAME_X','LOCAL_X'))
    mat.write_text(mat.read_text().replace('ALUMINUM','CUSTOM_SURF'))
    (source/'template_profile.json').write_text(json.dumps({'product_surface':'CUSTOM_SURF','frame_x':'LOCAL_X'}))
    run=tmp_path/'run';run.mkdir();snap=snapshot_template(Settings(solver='abaqus',template=str(source)),run)
    assert 'MATERIAL=CUSTOM_SURF' in (snap/'abaqus_main.inp').read_text()
    assert 'NAME=CUSTOM_SURF' in (snap/'abaqus_material.inp').read_text()
    validate_contract(snap,'abaqus')


def test_nested_external_case_insensitive_quoted_include_is_frozen(tmp_path):
    source=make_template(tmp_path);external=tmp_path/'External,Material.INP';external.write_bytes((source/'abaqus_material.inp').read_bytes())
    (source/'abaqus_material.inp').write_text('*include,\n input="../external,material.inp"\n')
    run=tmp_path/'run';run.mkdir();snap=snapshot_template(Settings(solver='abaqus',template=str(source)),run)
    external.unlink()
    assert any('*MATERIAL' in line.upper() for line in expanded_lines(snap/'abaqus_material.inp'))
    validate_contract(snap,'abaqus')


def test_general_contact_and_standard_model_data_are_preserved(tmp_path):
    source=make_template(tmp_path);main=source/'abaqus_main.inp'
    text=main.read_text().replace('*CONTACT PAIR, INTERACTION=FLOOR_CONTACT, MECHANICAL CONSTRAINT=PENALTY\nPRODUCT_CONTACT, FLOOR_SURFACE', '*CONTACT, OP=NEW\n*CONTACT INCLUSIONS, ALL EXTERIOR\n*CONTACT PROPERTY ASSIGNMENT\n, , FLOOR_CONTACT')
    main.write_text(text);run=tmp_path/'run';run.mkdir();settings=Settings(solver='abaqus',template=str(source),directions=[1])
    snap=snapshot_template(settings,run);validate_contract(snap,'abaqus')
    folder=setup_drop(settings,run,0,lambda *a:None,True);(folder/'results').mkdir();mesh=read_mesh(snap/'abaqus_mesh.inp')
    (folder/'results/state.json').write_text(json.dumps({'coordinates':mesh.product_nodes,'velocities':{n:[0,0,0] for n in mesh.product_nodes}}))
    release=prepare_release(settings,run,0,lambda *a:None);text='\n'.join(expanded_lines(release/'abaqus_main.inp'))
    assert text.index('*CONTACT PROPERTY ASSIGNMENT')<text.index('*STEP')
    assert '*CONTACT, OP=NEW' not in text
    assert audit_abaqus(release/'abaqus_main.inp')['passed']


def test_ordinary_part_instances_transform_geometry_and_share_sets():
    lines='''*PART, NAME=P
*NODE
1,0,0,0
2,1,0,0
3,1,1,0
4,0,1,0
5,0,0,1
6,1,0,1
7,1,1,1
8,0,1,1
*ELEMENT, TYPE=C3D8R, ELSET=BODY
1,1,2,3,4,
5,6,7,8
*NSET,NSET=FRAME_ORIGIN
5
*NSET,NSET=FRAME_X
6
*NSET,NSET=FRAME_Y
8
*SOLID SECTION,ELSET=BODY,MATERIAL=AL
*END PART
*ASSEMBLY,NAME=A
*INSTANCE,NAME=I,PART=P
10,20,30
0,0,0,0,0,1,90
*END INSTANCE
*END ASSEMBLY'''.splitlines()
    from system_drop.deck import mesh_from_lines
    result,mapping=flatten_assembly(lines,True);mesh=mesh_from_lines(result)
    np.testing.assert_allclose(mesh.nodes[1],[-20,10,30],atol=1e-12)
    assert mesh.elements[1][0]=='C3D8R' and 'I__BODY' in mesh.elsets
    assert mapping['instances']['I']['nodes'][1]==1


def test_unknown_local_part_cards_are_not_silently_discarded():
    with pytest.raises(ValueError,match='PART 내부'):
        flatten_assembly(['*PART,NAME=P','*USER ELEMENT,TYPE=U1','*END PART','*ASSEMBLY,NAME=A','*INSTANCE,NAME=I,PART=P','*END INSTANCE','*END ASSEMBLY'])
    assert list(logical_lines(['*DYNAMIC,',' EXPLICIT',' ,0.02']))==['*DYNAMIC,EXPLICIT',' ,0.02']
    assert keyword('*INCLUDE, INPUT="mesh, A.inp"')[1]['INPUT']=='mesh, A.inp'


def test_entire_part_assembly_template_is_prepared_without_source_changes(tmp_path):
    import re
    source=make_template(tmp_path);main=source/'abaqus_main.inp';text=main.read_text()
    sections=re.findall(r'\*SOLID SECTION, ELSET=BODY_[12], MATERIAL=\w+',text)
    for row in sections:text=text.replace(row,'')
    mesh=source/'abaqus_mesh.inp'
    mesh.write_text('*PART, NAME=LAPTOP\n'+mesh.read_text()+'\n'+'\n'.join(sections)+'\n*END PART\n*ASSEMBLY, NAME=A\n*INSTANCE, NAME=UNIT, PART=LAPTOP\n10,20,30\n*END INSTANCE\n*END ASSEMBLY\n')
    main.write_text(text);original=mesh.read_bytes();run=tmp_path/'run';run.mkdir()
    snap=snapshot_template(Settings(solver='abaqus',template=str(source)),run)
    assert validate_contract(snap,'abaqus')['product_nodes']==585
    assert mesh.read_bytes()==original
    assert '*PART,' not in (snap/'abaqus_mesh.inp').read_text()
    assert audit_abaqus(snap/'abaqus_main.inp')['passed']
