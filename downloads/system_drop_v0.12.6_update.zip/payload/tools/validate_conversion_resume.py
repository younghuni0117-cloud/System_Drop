"""Resume an actual completed drop after a synthetic MemoryError, no solver."""
from pathlib import Path
import sys,shutil,json,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import ROOT
from system_drop.engine import Engine
import system_drop.engine as engine_module
source=next((ROOT/'artifacts/time_settings_review/case_01').glob('doe_*'))
target=ROOT/'artifacts/resume0124'/source.name
assert not target.exists(),'Keep existing validation output'
for p in source.rglob('*'):
 rel=p.relative_to(source)
 if 'results' in rel.parts:continue
 dest=target/rel
 if p.is_dir():dest.mkdir(parents=True,exist_ok=True)
 else:
  dest.parent.mkdir(parents=True,exist_ok=True)
  if p.name in ('job.frd','job.dat','job.rout'):dest.hardlink_to(p)
  else:shutil.copy2(p,dest)
checkpoint=json.loads((target/'checkpoint.json').read_text());checkpoint['records']=[{'setup':'done','drop':'failed','release':'pending'}]
(target/'checkpoint.json').write_text(json.dumps(checkpoint))
(target/'drop_01/conversion_error.txt').write_text('MemoryError: previous eager conversion failed\n')
before={n:(target/'drop_01'/n).stat().st_mtime_ns for n in ('job.frd','job.dat','job.rout')}
def no_solver(*args,**kwargs):raise AssertionError('Completed solver output must not be recalculated')
engine_module.popen=no_solver;engine_module.resolve_solver_command=no_solver
events=[];e=Engine.restore(target,emit=lambda event,data:events.append((event,data)))
start=time.monotonic();e.execute(automatic=False)
assert e.records==[{'setup':'done','drop':'done','release':'pending'}],events[-5:]
assert before=={n:(target/'drop_01'/n).stat().st_mtime_ns for n in before}
assert not list((target/'drop_01').glob('previous_attempt_*'))
assert any(event=='processing' and data.get('phase')=='최종 상태 검증' for event,data in events)
mode=json.loads((target/'drop_01/results/conversion_mode.json').read_text())
report={'success':True,'solver_rerun':False,'actual_completed_run':str(source),'resume_folder':str(target),'raw_files_unchanged':True,'records':e.records,'elapsed_s':time.monotonic()-start,'conversion':mode}
(ROOT/'artifacts/resume0124_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
