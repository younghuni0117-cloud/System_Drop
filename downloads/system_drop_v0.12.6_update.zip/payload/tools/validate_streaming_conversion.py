"""Reconvert actual large CCX output and compare every saved field; no solver."""
from pathlib import Path
import sys,json,time,resource,hashlib
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import ROOT
from system_drop.deck import read_mesh
from system_drop.results import convert_frd,validate_physical_state,validate_preview_fields,read_state
from system_drop.restart import NativeRestart
folder=next((ROOT/'artifacts/time_settings_review/case_07_full').glob('*/drop_01'))
output=ROOT/'artifacts/streaming0124_results';output.mkdir(exist_ok=True)
mesh=read_mesh(folder/'calculix_main.inp')
end=float(NativeRestart.read(folder/'job.rout').doubles('ttime')[0])
original_stat={n:(folder/n).stat().st_mtime_ns for n in ('job.frd','job.dat','job.rout')}
events=[];started=time.monotonic()
convert_frd(folder/'job.frd',mesh,output,output_schedule={'period':.00006,'interval':.00001,'offset':0.,'end_time':end},progress=events.append)
elapsed=time.monotonic()-started
validate_physical_state(read_state(output/'state.json'),mesh);validate_preview_fields(output)
old=json.loads((folder/'results/frames.json').read_text());new=json.loads((output/'frames.json').read_text())
assert old==new
assert json.loads((folder/'results/state.json').read_text())==json.loads((output/'state.json').read_text())
import pyvista as pv
arrays=0
for record in new:
 a=pv.read(folder/'results'/record['file']);b=pv.read(output/record['file'])
 np.testing.assert_array_equal(a.points,b.points)
 for source,target in ((a.point_data,b.point_data),(a.cell_data,b.cell_data)):
  assert set(source)==set(target)
  for name in source:np.testing.assert_array_equal(source[name],target[name]);arrays+=1
assert original_stat=={n:(folder/n).stat().st_mtime_ns for n in original_stat}
assert [e['percent'] for e in events]==sorted(e['percent'] for e in events)
report={'success':True,'solver_rerun':False,'source_frd_bytes':(folder/'job.frd').stat().st_size,'source_dat_bytes':(folder/'job.dat').stat().st_size,'saved_frames':len(new),'arrays_identical_to_previous_converter':arrays,'state_identical':True,'raw_files_unchanged':True,'peak_rss_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,'elapsed_s':elapsed,'progress_events':len(events),'mode':json.loads((output/'conversion_mode.json').read_text())}
(ROOT/'artifacts/streaming0124_summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
