param([string]$InstallPath)
$ErrorActionPreference = 'Stop'
$patchRoot = Split-Path $PSScriptRoot -Parent
$payload = Join-Path $patchRoot 'payload'
$backedUp = @()
$created = @()
$backupRoot = $null
try {
    Write-Host 'System Drop update. Close the Manager and all result viewers first.'
    if ([string]::IsNullOrWhiteSpace($InstallPath)) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = 'Select the EXISTING system_drop folder containing start_windows.bat.'
        $dialog.ShowNewFolderButton = $false
        if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Write-Host 'Update cancelled.'; exit 0 }
        $InstallPath = $dialog.SelectedPath
    }
    $targetRoot = (Get-Item -LiteralPath $InstallPath).FullName
    foreach ($required in @('start_windows.bat','bootstrap_windows.py','system_drop\gui.py','solvers\calculix\bin\ccx_MT.exe')) {
        if (!(Test-Path -LiteralPath (Join-Path $targetRoot $required))) { throw "This is not the installed Manager folder. Missing: $required" }
    }
    if (!(Test-Path -LiteralPath (Join-Path $payload 'system_drop\mouse_controls.py'))) { throw 'Update payload is incomplete. Extract the entire update ZIP.' }
    $manifest = Get-Content -LiteralPath (Join-Path $patchRoot 'update_manifest.json') -Raw | ConvertFrom-Json
    if ($manifest.version -notmatch '^\d+\.\d+\.\d+$') { throw 'Unexpected update version.' }
    $updateVersion = [Version]$manifest.version
    $versionText = Get-Content -LiteralPath (Join-Path $targetRoot 'system_drop\__init__.py') -Raw
    if ($versionText -notmatch '__version__\s*=\s*"([0-9.]+)"') { throw 'Cannot identify installed version.' }
    $installedVersion = [Version]$Matches[1]
    if ($installedVersion -lt [Version]$manifest.supported_from -or $installedVersion -gt $updateVersion) { throw 'The installed version is outside this patch supported range.' }
    $files = @(Get-ChildItem -LiteralPath $payload -File -Recurse)
    if ($files.Count -ne @($manifest.files.PSObject.Properties).Count) { throw 'Unexpected or missing payload files.' }
    # Validate every payload byte before touching the installation.
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($payload.Length + 1).Replace('\','/')
        if ($relative -match '^(runs|offline/|runtime/python311/Lib/)') { throw "Protected path in update: $relative" }
        $expected = $manifest.files.PSObject.Properties[$relative].Value
        if (!$expected -or (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLower() -ne $expected) { throw "Damaged update file: $relative" }
    }
    # Update built-in templates only when all three files are known originals
    # (or already match this patch). Preserve customized/company templates.
    $templateKnown = $true
    if ($manifest.template_baseline) {
        foreach ($entry in $manifest.template_baseline.PSObject.Properties) {
            $path = Join-Path $targetRoot $entry.Name
            if (!(Test-Path -LiteralPath $path)) { $templateKnown = $false; continue }
            $currentHash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()
            $newHash = $manifest.files.PSObject.Properties[$entry.Name].Value
            if ($currentHash -ne $entry.Value -and $currentHash -ne $newHash) { $templateKnown = $false }
        }
    } else { $templateKnown = $false }
    if (!$templateKnown) {
        $files = @($files | Where-Object { !$_.FullName.Substring($payload.Length + 1).Replace('\','/').StartsWith('template_') })
        Write-Host 'Customized templates preserved. Updated example: update ZIP/payload/template_abaqus'
    } else { Write-Host 'Updating the recognized built-in Abaqus template (backed up first).' }
    $backupRoot = Join-Path $targetRoot ('backups\before_v' + $manifest.version + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
    New-Item -ItemType Directory -Path $backupRoot | Out-Null
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($payload.Length + 1)
        $destination = Join-Path $targetRoot $relative
        if (Test-Path -LiteralPath $destination) {
            $backup = Join-Path $backupRoot $relative
            New-Item -ItemType Directory -Force -Path (Split-Path $backup -Parent) | Out-Null
            Copy-Item -LiteralPath $destination -Destination $backup
            $backedUp += $relative
        } else { $created += $relative }
        New-Item -ItemType Directory -Force -Path (Split-Path $destination -Parent) | Out-Null
        Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
    }
    Write-Host 'Update completed. Run start_windows.bat in your existing installation.' -ForegroundColor Green
    Write-Host ('Backup: ' + $backupRoot)
    Write-Host 'Libraries, solver, customized templates, settings and runs were preserved.'
    exit 0
} catch {
    Write-Host ('Update failed: ' + $_.Exception.Message) -ForegroundColor Red
    $rollbackFailed = $false
    foreach ($relative in $backedUp) {
        try { Copy-Item -LiteralPath (Join-Path $backupRoot $relative) -Destination (Join-Path $targetRoot $relative) -Force }
        catch { $rollbackFailed = $true; Write-Host ('Could not restore: ' + $relative) -ForegroundColor Red }
    }
    foreach ($relative in $created) {
        try { $path = Join-Path $targetRoot $relative; if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force } }
        catch { $rollbackFailed = $true; Write-Host ('Could not remove new file: ' + $relative) -ForegroundColor Red }
    }
    if ($rollbackFailed) { Write-Host ('Restore manually from backup: ' + $backupRoot) -ForegroundColor Yellow }
    elseif ($backupRoot) { Write-Host 'Changed files were restored from backup.' }
    Write-Host 'No libraries or solver packages were installed.'
    exit 1
}
