"""Build a source/BAT Windows release with the GPL solver and genuine examples."""
from pathlib import Path
import hashlib,json,sys,argparse
from zipfile import ZipFile,ZIP_DEFLATED
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop import __version__
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--offline',action='store_true');args=parser.parse_args()
archive=root/(f'system_drop_v{__version__}_windows'+('_offline.zip' if args.offline else '.zip'))
selected={'test_report_v012.txt','viewer012_summary.json','viewer_v012.png','viewer_v012_display.png','directions_v012.png','gui_v012.png','test_report_v011.txt','two_material011_summary.json','viewer011_summary.json','gui_v011.png','viewer_v011.png','offline011_summary.json','abaqus_review_v011_summary.json','test_report_v101.txt','time_recovery_v101_summary.json','test_report_v100.txt','viewer100_summary.json','viewer_v100.png','test_report_v090.txt','output090_summary.json','playlist090_summary.json','gui_v090.png','viewer_v090.png','abaqus_review_v090_summary.json','test_report_v080.txt','stabilization_full080_summary.json','gui_v080.png','viewer_v080.png','abaqus_review_v080_summary.json','test_report_v070.txt','viewer_v070_summary.json','viewer_v070.png','recovery_v070_summary.json','half_logo_v070_summary.json','test_report_v060.txt','viewer_global_v060_summary.json','viewer_v060.png','viewer_controls_v060_summary.json','refined_v060_summary.json','viewer_impact_v060_summary.json','abaqus_review_v060_summary.json','test_report_v052.txt','recovery_v052_summary.json','windows_format_repro_before.txt','gui_v051.png','test_report_v051.txt','gui_v040.png','details_v040.png','impact_mises_v040.png','test_report_v040.txt',
          'performance_v031.json','windows_binary_dependencies_v030.json',
          'gui_complete_v050.png','details_v050.png','cumulative_mises_v050.png','test_report_v050.txt',
          'gui_native_v050_summary.json'}
excluded={'.venv','__pycache__','.pytest_cache','runs','.git','backups','template_calculix_reference'}
with ZipFile(archive,'w',ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(root)
        if rel.parts[0] in ('offline','runtime') and not args.offline:continue
        if rel.parts[0]=='runtime' and ('site-packages' in rel.parts or p.suffix=='.pyc'):continue
        if rel.parts[0]=='logs':continue
        if any(x in excluded or x.endswith('.egg-info') for x in rel.parts):continue
        if p.name in {'.python_path','user_settings.json','viewer.log'}:continue
        if len(rel.parts)==1 and p.suffix=='.zip':continue
        if rel.parts[0]=='artifacts' and (len(rel.parts)!=2 or p.name not in selected):continue
        z.write(p,'system_drop/'+rel.as_posix())
with ZipFile(archive) as z:
    assert z.testzip() is None
    names=z.namelist()
    for path in ['start_windows.bat','system_drop/restart.py','system_drop/output_schedule.py','system_drop/playlist.py','system_drop/stabilization.py','system_drop/restart_recovery.py','system_drop/movie.py','system_drop/timeline.py','system_drop/annotation.py','system_drop/gui.py',
                 'solvers/calculix/bin/ccx_MT.exe','solvers/calculix/bin/pthreadGC2.dll',
                 'template_calculix/calculix_main.inp','template_abaqus/abaqus_main.inp',
                 'examples/two_material/sequence.json','offline_setup.py','system_drop/template_adapter.py','system_drop/assembly.py','examples/three_body/sequence.json','examples/three_body/demo.mp4','examples/three_body/demo.gif','examples/sequence_movie/sequence.json','examples/sequence_movie/demo.avi','examples/cumulative/validation_18.json','examples/cumulative/validation_impact.json']:
        assert 'system_drop/'+path in names,path
    if args.offline:
        for required in ('offline/manifest.json','offline/python-3.11.9-embed-amd64.zip','offline/vc_redist.x64.exe','runtime/python311/python.exe','tools/install_local_wheels.py'):
            assert 'system_drop/'+required in names,required
        assert any('/offline/wheels/' in n and 'vtk-' in n for n in names)
    assert any('/sources/' in p and p.endswith('.zip') for p in names)
    assert any('/cumulative/impact_02/results/' in p and p.endswith('.vtu') for p in names)
    assert any('/cumulative/sequence_18_final/results/' in p and p.endswith('.vtu') for p in names)
print(json.dumps({'archive':str(archive),'files':len(names),'bytes':archive.stat().st_size,
                  'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'integrity':'passed'},indent=2))
