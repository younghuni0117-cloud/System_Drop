"""Actual isolated child viewer launches while an independent process is active."""
from pathlib import Path
from types import SimpleNamespace
import sys,subprocess,tempfile,shutil,time,json,os
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets
from system_drop.gui import Window,STYLE
import system_drop.gui as gui
from system_drop.model import ROOT,Settings
from system_drop.engine import Engine
from system_drop.solver import popen
app=QtWidgets.QApplication([]);app.setQuitOnLastWindowClosed(False);app.setStyleSheet(STYLE)
art=ROOT/'artifacts/viewer_launch0122';art.mkdir(exist_ok=True)
children=[];results=[]

def launch(args,cwd,stdout,env=None):
    assert args[1]==str(ROOT/'bootstrap_windows.py') and args[2]=='--viewer',args
    shot=art/f'viewer_{len(children):02d}.png'
    args=[args[0],'-I',*args[1:],'--screenshot',str(shot)]
    child_env=os.environ.copy();child_env.pop('PYTHONPATH',None)
    process=popen(args,cwd,stdout,child_env)
    children.append((process,shot,args));return process

def wait_last():
    process,shot,args=children[-1];end=time.monotonic()+30
    while process.poll() is None and time.monotonic()<end:app.processEvents();time.sleep(.02)
    if process.poll() is None:process.kill();raise AssertionError('Viewer launch timed out')
    assert process.returncode==0,(args,process.returncode)
    assert shot.exists() and shot.stat().st_size>10000
    results.append({'arguments':args,'exit_code':process.returncode,'screenshot':shot.name})

old=gui.popen;gui.popen=launch
worker=subprocess.Popen([sys.executable,'-c','import time; time.sleep(90)'])
with tempfile.TemporaryDirectory() as tmp:
    run=Path(tmp)/'이동한 프로그램 결과'
    shutil.copytree(ROOT/'examples/two_material',run)
    preview=next((ROOT/'artifacts/time_settings_review/case_07_full').glob('*/drop_01/preview'))
    shutil.copytree(preview,run/'drop_01/preview')
    w=Window(preferences_path=False);w.directions=[1,2];w.refresh_table()
    e=Engine(Settings(directions=[1,2]));e.run=run;e.process=worker
    e.records=[{'setup':'done','drop':'done','release':'done'},{'setup':'done','drop':'running','release':'pending'}]
    w.engine=e;w.worker=SimpleNamespace(isRunning=lambda:True);w.show();w.update_controls();app.processEvents()
    try:
        for stage in ('setup','drop','release'):
            assert w.buttons[(0,stage)].isEnabled()
            w.buttons[(0,stage)].click();wait_last()
            assert worker.poll() is None and e.process is worker
        w.all_results.click();wait_last();assert worker.poll() is None
        w.open_example();wait_last();assert worker.poll() is None
        assert not e.cancel_now.is_set() and not e.stop_after.is_set()
    finally:
        w.worker=None;w.engine=None;w.close();gui.popen=old
        for process,_,_ in children:
            if process.poll() is None:process.kill();process.wait()
        worker.terminate();worker.wait()
summary={'success':True,'real_qt_vtk_children':True,'isolated_python':True,'no_pythonpath':True,'busy_completed_buttons_enabled':True,'independent_process_uninterrupted':True,'launches':results,'native_windows_execution':False}
(ROOT/'artifacts/viewer_launch0122_summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
