"""Regenerate the shipped example templates. Never called by the GUI."""
from pathlib import Path
import sys
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from system_drop.deck import id_lines
from system_drop.model import ROOT, floor_geometry, impact_velocity


def make_mesh(nx=12,nz=8,ny=4):
    nodes = {}
    def nid(i, k, j):
        return 1 + i + (nx+1)*k + (nx+1)*(nz+1)*j
    for j in range(ny+1):
        for k in range(nz+1):
            for i in range(nx+1):
                nodes[nid(i,k,j)] = [-152 + 304*i/nx, -8+16*j/ny, 106-212*k/nz]
    elements = {}
    all_faces = []
    for j in range(ny):
        for k in range(nz):
            for i in range(nx):
                e = len(elements)+1
                elements[e] = [nid(i,k,j),nid(i+1,k,j),nid(i+1,k+1,j),nid(i,k+1,j),
                               nid(i,k,j+1),nid(i+1,k,j+1),nid(i+1,k+1,j+1),nid(i,k+1,j+1)]
                if j == 0: all_faces.append((e,"S1"))
                if j == ny-1:
                    all_faces.append((e,"S2"))
                if k == 0: all_faces.append((e,"S3"))
                if i == nx-1: all_faces.append((e,"S4"))
                if k == nz-1: all_faces.append((e,"S5"))
                if i == 0: all_faces.append((e,"S6"))
    lines = ["** ============================================================",
             "** PRODUCT MESH | mm, tonne, s, N | 304 x 212 x 16 mm",
             "** Refined AUTOMATION EXAMPLE; not a validated laptop model.",
             "** Update this file from HyperMesh; retain the three FRAME sets.",
             "** ============================================================", "*NODE"]
    for n, p in nodes.items(): lines.append(f"{n}, " + ", ".join(f"{x:.9g}" for x in p))
    groups=max(1,ny//2)
    for layer in range(groups):
        lines.append(f"*ELEMENT, TYPE=C3D8, ELSET=BODY_{layer+1}")
        for e, conn in elements.items():
            if (e-1)//(nx*nz*2)==layer:lines.append(f"{e}, " + ", ".join(map(str,conn)))
    for name, ids in [("FRAME_ORIGIN",[nid(0,0,ny)]),("FRAME_X",[nid(nx,0,ny)]),
                      ("FRAME_Y",[nid(0,nz,ny)]),("PRODUCT_NODES",nodes.keys())]:
        lines.extend([f"*NSET, NSET={name}",id_lines(ids)])
    lines.extend(["*ELSET, ELSET=PRODUCT_ELEMENTS", ", ".join(f"BODY_{i+1}" for i in range(groups)),
                  "** Shared-node material blocks, two C3D8 rows per block.",
                  "** Only the exterior impact surface remains; no logo/tie surfaces.",
                  "*SURFACE, NAME=PRODUCT_CONTACT, TYPE=ELEMENT"])
    lines.extend(f"{e}, {face}" for e,face in all_faces)
    return "\n".join(lines)+"\n", nodes


from system_drop.floor import floor_text
from system_drop.inp_format import format_inp
from system_drop.output_schedule import configure_output,decimal_text


def generate():
    mesh, nodes = make_mesh()
    material = """** ============================================================
** MATERIALS | EXAMPLE ONLY, replace with measured true stress /
** plastic strain data. Density tonne/mm^3; E and stress N/mm^2.
** ============================================================
*MATERIAL, NAME=ALUMINUM
*DENSITY
2.7e-9
*ELASTIC
70000., 0.33
*PLASTIC
150., 0.
180., 0.01
220., 0.05
260., 0.15
*MATERIAL, NAME=PLASTIC
** Generic polymer example, not a calibrated material.
*DENSITY
1.2e-9
*ELASTIC
2300., 0.35
*PLASTIC
35., 0.
40., 0.02
50., 0.08
60., 0.20
** Floor material is required only by the CalculiX C3D8 rigid mesh.
*MATERIAL, NAME=FLOOR_MATERIAL
*DENSITY
7.8e-9
*ELASTIC
210000., 0.3
"""
    for solver in ("abaqus", "calculix"):
        gap=.001 if solver=='calculix' else 1.
        period=.000060 if solver=='calculix' else .02
        surface=floor_geometry(list(nodes.values()),[0,1,0],gap)
        folder = ROOT/f"template_{solver}"
        folder.mkdir(exist_ok=True)
        (folder/f"{solver}_mesh.inp").write_text(format_inp(mesh,"00SYSTEM_DROP MESH"),encoding="utf-8")
        (folder/f"{solver}_material.inp").write_text(format_inp(material,"00SYSTEM_DROP MATERIAL"),encoding="utf-8")
        contact = ("*SURFACE INTERACTION, NAME=FLOOR_CONTACT\n*SURFACE BEHAVIOR, PRESSURE-OVERCLOSURE=HARD\n*FRICTION\n0.\n"
                   "") if solver == "abaqus" else (
                   "*SURFACE INTERACTION, NAME=FLOOR_CONTACT\n*SURFACE BEHAVIOR, PRESSURE-OVERCLOSURE=LINEAR\n1.e5\n** Frictionless: omit *FRICTION (CalculiX rejects coefficient zero).\n"
                   "*CONTACT PAIR, INTERACTION=FLOOR_CONTACT, TYPE=SURFACE TO SURFACE\nPRODUCT_CONTACT, FLOOR_SURFACE")
        bc = "FLOOR_REF, 1, 6" if solver == "abaqus" else "FLOOR_REF, 1, 3\nFLOOR_ROT, 1, 3"
        floor_section = "" if solver == "abaqus" else "*SOLID SECTION, ELSET=FLOOR_ELEMENTS, MATERIAL=FLOOR_MATERIAL\n"
        speed = impact_velocity(1000,gap,[0,1,0])[1]
        output = ("*RESTART, WRITE, NUMBER INTERVAL=1\n*OUTPUT, FIELD, TIME INTERVAL=0.000001\n*NODE OUTPUT\nU, V, UR, VR\n*ELEMENT OUTPUT\nS, PE, PEEQ\n*OUTPUT, HISTORY, TIME INTERVAL=0.000001\n*ENERGY OUTPUT\nALLKE, ALLIE, ALLAE") if solver=="abaqus" else (
                  "*RESTART, WRITE, FREQUENCY=1\n*NODE FILE, OUTPUT=2D, FREQUENCY=5\nU, V\n*EL FILE, OUTPUT=2D, FREQUENCY=5\nS, PEEQ, ENER\n*EL PRINT, GLOBAL=YES, ELSET=PRODUCT_ELEMENTS, FREQUENCY=5\nS\n** Structural output requests share their increment interval.\n*NODE PRINT, NSET=FRAME_ORIGIN, FREQUENCY=5\nU, V")
        step = ("*STEP, NAME=DROP, NLGEOM=YES\n*DYNAMIC, EXPLICIT\n, 0.02, , 0.000001" if solver=="abaqus" else
                f"*STEP, NLGEOM, INC=100000000\n*DYNAMIC, EXPLICIT=2\n0.0000001, {decimal_text(period)}, 0.000000000001, 0.000001")
        text = f"""** SYSTEM_DROP_DEFAULT_GAP={gap:.12g}
*HEADING
System Drop | Top Face example | height 1000 mm | gap {gap:g} mm | period {decimal_text(period)} s
** Solver-specific example period; choose evaluation duration for each direction.
** ============================================================
** 01 MODEL: replace mesh/material includes, retain AUTO markers.
** ============================================================
*INCLUDE, INPUT={solver}_material.inp
*INCLUDE, INPUT={solver}_mesh.inp
** AUTO:BEGIN FLOOR
{floor_text(solver,surface,max(nodes)+100)}
** AUTO:END FLOOR
** ============================================================
** 02 SECTIONS: aluminum / polymer shared-node blocks; no tie.
** ============================================================
{floor_section}*SOLID SECTION, ELSET=BODY_1, MATERIAL=ALUMINUM
*SOLID SECTION, ELSET=BODY_2, MATERIAL=PLASTIC
** ============================================================
** 03 FRICTIONLESS CONTACT AND FIXED RIGID FLOOR
** ============================================================
{contact}
*BOUNDARY
{bc}
** AUTO:BEGIN VELOCITY
*INITIAL CONDITIONS, TYPE=VELOCITY
PRODUCT_NODES, 1, 0.
PRODUCT_NODES, 2, {speed:.12g}
PRODUCT_NODES, 3, 0.
** AUTO:END VELOCITY
** ============================================================
** 04 EXPLICIT DROP: GUI reads this period as its default.
** ============================================================
** AUTO:BEGIN DROP_STEP
{step}
{('*CONTACT PAIR, INTERACTION=FLOOR_CONTACT, MECHANICAL CONSTRAINT=PENALTY'+chr(10)+'PRODUCT_CONTACT, FLOOR_SURFACE') if solver=='abaqus' else ''}
*DLOAD
PRODUCT_ELEMENTS, GRAV, 9810., 0., 1., 0.
{output}
*END STEP
** AUTO:END DROP_STEP
"""
        (folder/f"{solver}_main.inp").write_text(format_inp(configure_output(text,solver,period,0.000001)),encoding="utf-8")


if __name__ == "__main__":
    generate()
