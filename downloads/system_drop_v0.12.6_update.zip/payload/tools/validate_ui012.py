"""Exercise the real Qt/VTK viewer without starting a solver."""
from pathlib import Path
import sys,json,re,numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets,QtCore,QtGui,QtTest
from system_drop.viewer import Viewer
from system_drop.gui import Window,STYLE
from system_drop.model import ROOT,NAMES
from system_drop.schematic import direction_icon
app=QtWidgets.QApplication([]);app.setQuitOnLastWindowClosed(False);app.setStyleSheet(STYLE)
w=Window(preferences_path=False);w.show();app.processEvents()
assert w.table.rowHeight(0)==23
assert w.table.visualItemRect(w.table.item(17,0)).bottom()<=w.table.viewport().height()
w.grab().save(str(ROOT/'artifacts/gui_v012.png'));w.close()
v=Viewer(ROOT/'examples/two_material');v.show();app.processEvents()
assert v.viewer_title.text()=='Calculix - PyVista (Open-Source)'
assert not hasattr(v,'mouse') and not hasattr(v,'pause')
labels=[v.scalar.itemText(i) for i in range(v.scalar.count())]
for label in ('Displacement (mm)','Velocity (mm/s)','Von-Mises Stress (MPa)','Max. Principal Stress (MPa)','Min. Principal Stress (MPa)'):assert label in labels
assert 'STRESS' not in labels and 'DISP' not in labels and 'VELO' not in labels
v.scalar.setCurrentText('Von-Mises Stress (MPa)');v.show_max.setChecked(True);app.processEvents()
assert re.fullmatch(r'Max -?\d+\.\d{3} MPa',v.annotation.text.GetInput())
assert v.annotation.text.GetLayerNumber()>v.annotation.leader.GetLayerNumber()
assert v.annotation.text.GetTextProperty().GetBackgroundOpacity()==1
assert v.minimum.decimals()==v.maximum.decimals()==3
v.lock_range.setChecked(True);v.minimum.setValue(-1.12345);v.maximum.setValue(12.54321)
assert v.minimum.value()==-1.123 and v.maximum.value()==12.543
v.lock_range.setChecked(False)
v.edges.setChecked(False);app.processEvents()
assert any(n.startswith('feature_') for n in v.plotter.actors)
assert np.allclose(v.plotter.renderer.GetBackground(),[1,1,1])
v.shading.setValue(10);low=next(a for n,a in v.plotter.actors.items() if n.startswith('product_')).prop.ambient
v.shading.setValue(90);high=next(a for n,a in v.plotter.actors.items() if n.startswith('product_')).prop.ambient
assert low>high
v.shading.setValue(65)
# Playing/pausing updates both icons and a varying time never resizes controls.
positions=[(b.x(),b.width()) for b in (v.play,v.continuous_play,v.slider,v.fps,v.frame_step,v.frame_label)]
for i in (0,len(v.records)-1,1):
 v.slider.setValue(i);app.processEvents()
 assert positions==[(b.x(),b.width()) for b in (v.play,v.continuous_play,v.slider,v.fps,v.frame_step,v.frame_label)]
v.play.click();assert v.timer.isActive() and v.play.toolTip()=='멈춤'
v.play.click();assert not v.timer.isActive() and v.play.toolTip()=='재생'
v.continuous_play.click();assert v.timer.isActive() and v.continuous_play.toolTip()=='멈춤'
v.continuous_play.click();assert not v.timer.isActive()
# Verify the Ctrl+left/right mappings affect the real camera.
viewport=v.plotter.interactor
for button in (QtCore.Qt.MouseButton.LeftButton,QtCore.Qt.MouseButton.RightButton):
 before=np.array([v.plotter.camera.position,v.plotter.camera.focal_point,v.plotter.camera.up])
 start=QtCore.QPoint(viewport.width()//2,viewport.height()//2)
 QtTest.QTest.mousePress(viewport,button,QtCore.Qt.KeyboardModifier.ControlModifier,start)
 QtTest.QTest.mouseMove(viewport,start+QtCore.QPoint(55,35));app.processEvents()
 QtTest.QTest.mouseRelease(viewport,button,QtCore.Qt.KeyboardModifier.ControlModifier,start+QtCore.QPoint(55,35))
 after=np.array([v.plotter.camera.position,v.plotter.camera.focal_point,v.plotter.camera.up])
 assert not np.allclose(before,after),str(button)

# Ctrl+MMB rectangle zoom, and click-to-fit through the installed event filter.
viewport=v.plotter.interactor;start=QtCore.QPoint(viewport.width()//3,viewport.height()//3);end=start+QtCore.QPoint(100,70)
cam_before=v.plotter.camera.view_angle
QtTest.QTest.mousePress(viewport,QtCore.Qt.MouseButton.MiddleButton,QtCore.Qt.KeyboardModifier.ControlModifier,start)
QtTest.QTest.mouseMove(viewport,end)
QtTest.QTest.mouseRelease(viewport,QtCore.Qt.MouseButton.MiddleButton,QtCore.Qt.KeyboardModifier.ControlModifier,end)
assert v.plotter.camera.view_angle<cam_before
assert not v.classic_mouse.rubber.isVisible()
QtTest.QTest.mouseClick(viewport,QtCore.Qt.MouseButton.MiddleButton,QtCore.Qt.KeyboardModifier.ControlModifier,start)
# Confirm the annotation remains a single pair, including when target is inside its box.
for i in range(3):v.show_max.setChecked(False);v.show_max.setChecked(True)
renderer=v.plotter.renderer
assert renderer.HasViewProp(v.annotation.text) and renderer.HasViewProp(v.annotation.leader)
v.option_tabs.setCurrentIndex(1);v.scalar.setCurrentText('Max. Principal Stress (MPa)');app.processEvents()
v.grab().save(str(ROOT/'artifacts/viewer_v012.png'))
v.option_tabs.setCurrentIndex(2);app.processEvents();v.grab().save(str(ROOT/'artifacts/viewer_v012_display.png'))
# Same viewer updates branding as the active solver changes.
stage={**v.records[0]['stage'],'metadata':{'solver':'abaqus'}}
v.update_solver_title(stage,v.load_grid(0));assert v.viewer_title.text()=='Abaqus - PyVista (Open-Source)'
# Readability and consistent perspective of all 18 larger direction thumbnails.
sheet=QtGui.QPixmap(720,390);sheet.fill(QtGui.QColor('white'));p=QtGui.QPainter(sheet)
for i,name in enumerate(NAMES,1):
 x=((i-1)%6)*120;y=((i-1)//6)*130
 p.drawPixmap(x+12,y+4,direction_icon(i).pixmap(96,64));p.drawText(QtCore.QRect(x,y+72,120,45),QtCore.Qt.AlignmentFlag.AlignHCenter|QtCore.Qt.TextFlag.TextWordWrap,f'{i:02d} {name}')
p.end();sheet.save(str(ROOT/'artifacts/directions_v012.png'))
summary={'success':True,'real_qt_vtk':True,'solver_branding':True,'principal_stresses':True,'max_label':'value with three decimals and units only','opaque_box_above_leader':True,'range_decimals':3,'two_play_pause_toggles':True,'stable_playback_geometry':True,'classic_control_middle_region_zoom':True,'white_background':True,'shading_adjustable':True,'feature_lines':True,'all_18_rows_visible':True,'no_new_dependencies':True}
(ROOT/'artifacts/viewer012_summary.json').write_text(json.dumps(summary,indent=2))
# Check the changed playback lifecycle also survives actual GIF export.
v.records=v.records[:5];v.slider.setRange(0,4);v.frame_step.setValue(2)
loop=QtCore.QEventLoop();errors=[]
v.movie_saved.connect(lambda *_:loop.quit());v.movie_failed.connect(lambda e:(errors.append(e),loop.quit()))
v.begin_export(ROOT/'artifacts/viewer_v012_stride.gif')
QtCore.QTimer.singleShot(15000,loop.quit);loop.exec()
assert not errors and v.export_state is None,errors
from PIL import Image
with Image.open(ROOT/'artifacts/viewer_v012_stride.gif') as gif:assert gif.n_frames==3
summary['gif_export_stride_2_frames_3']=True
(ROOT/'artifacts/viewer012_summary.json').write_text(json.dumps(summary,indent=2))
v.close();print(json.dumps(summary,indent=2))
