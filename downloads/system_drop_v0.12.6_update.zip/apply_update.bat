@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\apply_update.ps1"
set "result=%errorlevel%"
pause
exit /b %result%
