"""Create a cumulative source-only patch; never include user models or wheels."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json,sys,ast
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from system_drop import __version__
files=list((root/'system_drop').glob('*.py'))
files += [root/name for name in ('bootstrap_windows.py','offline_setup.py','start_windows.bat','start_windows.cmd','install_windows.bat','install_windows.cmd','pyproject.toml','README.md','tools/export_odb.py','tools/package_windows.py','tools/package_update.py','tools/validate_ui012.py','tools/validate_viewer_launch.py','tools/apply_update.ps1','docs/CHANGES_0.12.md','docs/CHANGES_0.12.1.md','docs/CHANGES_0.12.2.md','docs/CHANGES_0.12.3.md','docs/OFFLINE_WINDOWS.md')]
files += list((root/'tests').glob('test_*.py'))+list((root/'tests/fixtures/legacy_calculix').glob('*.inp'))
files += list((root/'assets').glob('*.svg'))
payload={p.relative_to(root).as_posix():p.read_bytes() for p in files}
for name,data in payload.items():
    assert not name.startswith(('runs/','template_','offline/','runtime/','user_settings'))
    if name.endswith('.py'):ast.parse(data.decode('utf-8'),feature_version=(3,11))
manifest={'version':__version__,'supported_from':'0.11.0','new_dependencies':[],
          'files':{n:hashlib.sha256(data).hexdigest() for n,data in payload.items()}}
archive=root/f'system_drop_v{__version__}_update.zip'
readme=f'''System Drop v{__version__} 업데이트

1. Manager와 결과 창을 닫습니다.
2. 이 ZIP 전체를 임시 폴더에 압축 해제합니다.
3. apply_update.bat을 실행합니다.
4. 기존 start_windows.bat이 있는 system_drop 폴더를 선택합니다.
5. 완료되면 기존 start_windows.bat을 실행합니다.

변경 파일은 기존 설치 backups 폴더에 먼저 백업합니다.
기존 라이브러리, 솔버, INP 템플릿, 사용자 설정, runs는 유지합니다.
v0.11.1 시작 오류 수정도 포함합니다. 새로운 라이브러리는 없습니다.

PowerShell을 실행할 수 없으면 payload 안의 파일과 폴더를
기존 start_windows.bat이 있는 폴더에 복사·병합하여 덮어쓰세요.
payload 폴더 자체를 복사하는 것이 아닙니다. 기존 파일은 먼저 백업하세요.

자세한 내용: payload/docs/CHANGES_{__version__}.md
'''
bat='@echo off\r\nsetlocal\r\ncd /d "%~dp0"\r\npowershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\\apply_update.ps1"\r\nset "result=%errorlevel%"\r\npause\r\nexit /b %result%\r\n'
with ZipFile(archive,'w',ZIP_DEFLATED) as z:
    for name,data in payload.items():z.writestr('payload/'+name,data)
    z.writestr('update_manifest.json',json.dumps(manifest,indent=2).encode('utf-8'))
    z.writestr('apply_update.bat',bat.encode('ascii'))
    z.writestr('tools/apply_update.ps1',(root/'tools/apply_update.ps1').read_bytes())
    z.writestr('README_UPDATE.txt',readme.encode('utf-8-sig'))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for name,expected in manifest['files'].items():assert hashlib.sha256(z.read('payload/'+name)).hexdigest()==expected
    assert not any('template_calculix_reference' in n for n in z.namelist())
print(json.dumps({'archive':str(archive),'payload_files':len(payload),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'integrity':'passed'},indent=2))
