﻿System Drop v0.11.1 - v0.11.0 오프라인 시작 오류 수정

1. 현재 실행 창을 닫으세요.
2. 이 ZIP을 별도 임시 폴더에 압축 해제하세요.
3. 압축을 푼 파일과 폴더를 기존 start_windows.bat이 있는 system_drop 폴더에 복사하고 덮어쓰세요.
   예: D:\ChatGpt\누적드랍\system_drop_v0.11.0_windows_offline\system_drop
4. runtime, system_drop, docs 폴더는 기존 폴더와 병합하세요. 기존 폴더 자체를 삭제하지 마세요.
5. 기존 start_windows.bat을 다시 실행하세요.

363MB 배포본을 다시 받지 않아도 됩니다. 기존 라이브러리를 삭제하거나 강제 재설치하지 않습니다.
솔버, 모델, runs, 해석 결과는 패치에 포함되지 않으며 변경하지 않습니다.

수정:
- 동봉 Python 격리 모드에서도 offline_setup.py 등 프로그램 모듈을 찾도록 명시적 경로 추가.
- GUI 자식 프로세스도 절대 경로 시작 파일을 통해 실행.
- 동봉 전용 Python _pth 설정이 누락/구버전이면 복구.
- 추가 시작 오류를 logs/startup_error.txt에 기록.

검증: Python 격리 모드에서 기존 오류 재현 후 수정 확인, 자동 테스트 174개 통과.
이 개발 환경은 Linux이므로 실제 Windows 실행 검증은 하지 못했습니다.
