# System Drop — 누적 낙하해석 GUI

Windows 로컬에서 Abaqus / CalculiX 입력과 순차 해석을 관리하는 **초기 개발 버전**입니다.
실제 계산과 GUI 흐름 검증을 분리합니다. 워크플로 테스트의 완료 표시는 물리 해석 완료를 뜻하지 않습니다.

현재 버전은 **v0.12.12**입니다. CPU 기본값/프리셋은 **4**이며 저장한 실행의 CPU 설정은 유지합니다.
솔버 표시명은 `CalculiX 2.23 (Open-Source)` / `Abaqus 2025`입니다.
표시명 변경은 설치된 Abaqus 버전을 검증하거나 변경하지 않으며 실행 명령은 상세 옵션에서 지정합니다.
관찰 로그는 고정 폭 글꼴과 일정한 숫자 자릿수를 사용합니다.

## v0.12.12 템플릿 제품 집합 정의 유지

CalculiX/Abaqus 모두 mesh의 PRODUCT_NODES / PRODUCT_ELEMENTS를 사용하며 별도 AUTO_PRODUCT_* 집합을 생성하거나 기존 제품 집합을 확장하지 않습니다. 누락된 집합은 템플릿 오류로 안내합니다.
[기존 정의 유지·누적 단계·검증](docs/CHANGES_0.12.12.md).

## v0.12.11 단계별 결과 파일명

CalculiX 완료 결과를 drop_01_drop.frd / drop_01_release.frd / drop_02_drop.frd처럼 저장합니다. DAT/STA/native 결과에도 같은 접두어를 적용하며 3개 INP 구조는 유지합니다.
[계산 중 파일명·완료 후 처리·누적 연결·검증](docs/CHANGES_0.12.11.md).

## v0.12.10 CalculiX 3파일 직접 실행

CalculiX도 main/material/mesh 3개 INP만 생성합니다. Manager의 최대 증분·종료 시간은 calculix_main.inp에 반영하고 ccx -i calculix_main으로 직접 실행합니다. 새 단계의 결과·재시작 파일도 calculix_main basename을 사용합니다.
[3파일 구조·시간 반영·이전 실행 재개·검증](docs/CHANGES_0.12.10.md).

## v0.12.9 CalculiX 실제 입력·시간 설정 검증 (진입 파일 방식은 v0.12.10에서 대체)

CalculiX 실행을 job.inp → calculix_main.inp로 연결하여 main에서 실제 시간 조건을 확인할 수 있습니다. INCLUDE를 펼친 입력을 GUI와 대조하고 두 솔버의 서로 다른 DYNAMIC 형식을 검사합니다.
[입력 파일 역할·시간 필드 차이·검증](docs/CHANGES_0.12.9.md).

## v0.12.8 CalculiX 출력량·변환 개선

매 계산 증분마다 결과를 기록하던 설정을 자동 기록 주기로 변경합니다. 상세 옵션에서 기록 주기와 단계별 최대 저장 프레임(기본 1,000)을 조절합니다. DAT 인덱싱 중 불필요한 응력 계산도 줄였습니다.
[적용 방법·기존 대용량 결과 재개·실제 테스트](docs/CHANGES_0.12.8.md).

## v0.12.7 Abaqus 제품 집합 재사용

기존 PRODUCT_NODES / PRODUCT_ELEMENTS를 사용하고 새 실행의 중복 AUTO_PRODUCT_* 집합은 생성하지 않습니다.
[집합 검증·보완 기준](docs/CHANGES_0.12.7.md).

## v0.12.6 Abaqus 3파일 입력·이동 가능한 결과 경로

새 Abaqus 실행은 main/material/mesh 세 파일로 생성하고 현재 프로그램의 runs를 새 결과 위치로 사용합니다.
[파일 구조·기존 실행 호환·적용 안내](docs/CHANGES_0.12.6.md).

## v0.12.5 Abaqus GUI 조건·출력 간격 반영

실제 job.inp의 종료 시간·최대 증분·Field/History 출력 간격을 GUI와 대조합니다.
[설정 확인·템플릿 갱신·검증](docs/CHANGES_0.12.5.md).

## v0.12.4 결과 변환 메모리 사용 개선

대용량 FRD/DAT를 한 번에 메모리에 올리지 않고, 검사 후 선택한 프레임을 순차 변환합니다.
99.9% 대신 결과 변환 진행률과 최종 검증 상태를 표시합니다.
[MemoryError 복구·검증 안내](docs/CHANGES_0.12.4.md).

## v0.12.3 Windows 솔버 실행 환경·진단 보완

동봉 Windows 환경의 강성 조립 스레드 설정을 반영하고 비정상 종료 진단 파일을 추가했습니다.
접근 위반의 원인은 아직 확정하지 못했으며 [검증 범위와 데스크탑 비교 절차](docs/CHANGES_0.12.3.md)를 참고하세요.

## v0.12.2 완료 결과창 경로 오류 수정

완료 버튼·전체 결과·예제 결과창을 현재 프로그램의 절대 시작 경로로 실행합니다.
프로그램을 이동하거나 이전 Python을 재사용해도 현재 소스를 찾도록 보완했습니다.
[원인과 적용 안내](docs/CHANGES_0.12.2.md).

## v0.12.1 시작 인수 오류 수정

GUI 진입 시 내부 `--gui` 인수를 제거하여 실제 GUI 인수 파서로 넘어가지 않게 수정했습니다.
[적용 안내](docs/CHANGES_0.12.1.md).

## v0.12 결과 창 표시·조작 개선

Max 주석 박스, 응력 이름·주응력, 세 자리 범위 입력, 재생 토글, 클래식 마우스,
음영 조절, 외곽선 및 흰색 배경을 적용했습니다. 라이브러리 추가 없는 작은 누적 패치로 제공합니다.
[변경 내용과 패치 적용](docs/CHANGES_0.12.md).

## v0.11 오프라인 · Abaqus 템플릿 · 결과 창

인터넷 없는 Windows 10/11 64비트 PC에는 **windows_offline.zip**을 사용하세요.
Python과 라이브러리 wheel을 동봉하고, 기존 환경 재사용 또는 전용 환경 설치를 안내합니다.
[오프라인 실행](docs/OFFLINE_WINDOWS.md).

Abaqus 입력의 INCLUDE/기본 PART·INSTANCE/주석·이어쓰기와 역할 매핑을 확장했습니다.
모든 임의 키워드 조합을 보장하지 않으며 미지원 구속/하중/Import는 사전 검사에서 알립니다.
[지원 범위](docs/TEMPLATE_COMPATIBILITY.md).

결과 창은 3개 옵션 탭, 원근 버튼, HyperView 스타일 Continuous/Discrete 컨투어,
바닥 색상, 두 화면 모드의 전환 프레임을 제공합니다. 안정화 예상 Frame도 표시합니다.
현재 샘플은 **Aluminum + Plastic 2파트 / C3D8 384개 / 585노드**입니다.
[전체 변경과 시험](docs/CHANGES_0.11.md).

## v0.10.1 누적 시간 반올림 오류 복구

13회차의 `결과 프레임 시간이 역순입니다`는 계산 완료 후 시간 표기를 비교하던 변환 오류입니다.
FRD/DAT의 반올림 시간과 native 종료 시간의 정밀도 차이를 허용 범위 안에서 정리합니다.
프레임/응력/변위를 정렬하거나 보간하지 않으며 원본 FRD와 native 파일을 유지합니다.

**새 버전 → 상세 옵션 → 이전 실행 폴더 열기 / 재개 → 기존 doe 폴더 → 자동 실행**으로 이어갑니다.
폴더 복사는 필수가 아닙니다. 버전별로 분리하려면 해당 doe 폴더 전체만 새 버전의 runs로 복사하세요.
완료 결과 검사를 통과하면 13회차 낙하는 재계산하지 않고 변환부터 재시도합니다.
검사 실패 시 자동 재계산을 중단하고 알립니다.
[원인·복구 절차·시험 범위](docs/CHANGES_0.10.1.md).

## v0.10 뷰어 렌더링 · 밝은 음영 · 영상 형식

프레임을 완성한 뒤 한 번만 렌더링하고, Max 표시를 native VTK의 선/글씨 한 쌍으로 바꿨습니다.
밝은 조명과 음영, 파트별 색상 버튼, 작은 화면 글씨를 제공합니다.
**프레임 간격**은 재생과 AVI/MP4/GIF 저장에 같이 적용합니다. 1은 전부, 2는 한 프레임씩 건너뜁니다.
MP4는 Qt의 기존 멀티미디어 코덱을 사용합니다. 외부 ffmpeg 설치는 필요하지 않습니다.
필요한 최소 환경은 PySide6 6.8.2 이상과 Pillow 9 이상입니다. 기존 호환 환경은 재사용합니다.

**기본 예제 목록은 로고 없는 BODY_1/2/3 모델로 교체했습니다.**
로고가 보이는 이전 검증 이미지/데이터는 과거 기록이며 현재 기본 템플릿이 아닙니다.
[뷰어 변경과 시험](docs/CHANGES_0.10.md).

## v0.9 시간 출력 · 파일 직접 선택 재생

시간 입력과 생성 INP는 `0.0000001` 처럼 소수로 표시합니다.
낙하 종료 시간 아래에 **예상 Frame : 60개** 를 표시합니다.
최대 증분을 출력 간격 기준으로도 사용하며, `0.00006 / 0.000001 = 60`입니다(0초 초기 프레임 제외).
CalculiX는 원본 FRD를 보존하고 변환 시 실제 결과에서 60프레임을 선택합니다.
Abaqus는 `TIME INTERVAL=0.000001`를 사용합니다.

결과 창의 **파일 선택 → 재생 목록 → 드랍만 선택 → 목록 적용 → 연속재생** 으로
안정화를 제외한 원하는 결과를 재생합니다. 여러 파일 선택과 드래그 순서 변경을 지원합니다.
감쇠 α는 상세 옵션으로 이동했습니다.
[사용법과 출력 시간 정밀도](docs/CHANGES_0.9.md).

## v0.8 안정화 개선 · BODY 3개 그룹

안정화 시작 시 질량 기준으로 강체 병진·회전 속도를 제거합니다. 형상·응력·소성 이력과
내부 진동 속도는 유지하고, 안정화 전용 질량비례 감쇠를 적용합니다.
**감쇠 α 기본 20 /s**를 GUI에서 조절할 수 있습니다. 새 바닥이나 강제 고정은 추가하지 않습니다.
다음 낙하에는 안정화용 감쇠를 해제하고 원래 낙하 설정을 복원합니다.

양 솔버 기본 템플릿은 로고/Shell/부착 Surface/Tie를 제거했습니다.
**BODY_1, BODY_2, BODY_3** 각각 두께 방향 2층, 전체 6층입니다.
경계 노드를 공유하며 총 **C3D8 2304개 / 제품 노드 2975개**입니다.
제품과 바닥의 충돌용 Surface는 유지합니다. **새 실행 폴더로 시작**하면 적용됩니다.
[전달 방식·감쇠·메쉬 구성](docs/STABILIZATION_v080.md), [변경과 시험 기록](docs/CHANGES_0.8.md).

## v0.7 누적 모션 · 영상 저장 · 재시작 오류 복구

결과 창 제목은 **PyVista (Open-Source)**입니다. 파트별 불투명도, 다른 낙하/안정화 단계 선택,
제품 중심 또는 바닥 고정 연속 재생, AVI 저장, 가는 회색 Max 화살표와 드래그 가능한 표시를 제공합니다.
상세 옵션 → 검증 예제 → **누적 모션 / 영상 예제**에서 바로 확인할 수 있습니다.
[뷰어 조작과 영상의 의미](docs/VIEWER_v070.md).

두 번째 낙하의 Windows `temporaryrestartfile cannot be renamed` 오류를 수정했습니다.
새 버전에서 **상세 옵션 → 이전 실행 폴더 열기 / 재개 → 기존 doe 폴더 → 자동 실행**으로 이어가세요.
남아 있는 `job.rout`의 최종 단계·시간·재료 이력이 유효하면 재계산 없이 결과를 복구합니다.
파일 크기만으로 완료 처리하지 않습니다. [복구 조건과 시험 범위](docs/RESTART_RECOVERY_v070.md).
기존 실행은 자신의 모델을 계속 사용하며, 이전 v0.7의 로고 크기 변경은 당시 새 실행에만 적용했습니다.
[변경/시험 기록](docs/CHANGES_0.7.md).

## v0.5.1 결과 변환 오류 복구

`Job finished` 다음에 배열 형상 오류가 났다면 기존 실행 폴더를 유지하세요.
새 버전 실행 → 상세 옵션 → **이전 실행 폴더 열기 / 재개** → 기존 **doe 폴더** 선택 → **자동 실행**.
완료 로그·입력·결과가 확인되면 낙하를 재계산하지 않고 변환부터 이어갑니다.
[오류 원인과 복구 조건](docs/CHANGES_0.5.2.md).

## v0.6 입력/메쉬/결과 보기

템플릿과 새 doe 입력은 `**====` / 번호 구획으로 정돈했습니다.
v0.6~0.7은 로고 Shell 모델을 사용했습니다. 현재 기본 메쉬는 위 v0.8의 3개 Solid 그룹입니다.
기존 진행 중 실행은 자신의 template_snapshot을 계속 사용하고 새 메쉬는 새 실행에 적용됩니다.

결과 창에는 평균화, Min/Max 고정, 재생/멈춤, 파트 표시/컨투어, Max 화살표가 있습니다.
[뷰어 계산 방식과 조작](docs/VIEWER_v060.md), [Abaqus 2025 정적 검토](docs/ABAQUS_REVIEW_2025.md)를 참고하세요.
새 결과에는 요소 IP 응력을 추가했습니다. 이전 절점 평균 결과는 Source로 표시합니다.
Abaqus 라이선스 실행은 수행하지 않았으며 회사 PC에서 datacheck가 필요합니다.

## Windows 실행

1. Python 3.10 이상이 있는 PC에서 압축을 해제하고 **`start_windows.bat`**를 실행합니다.
2. 현재 Python, 기존 `.venv`, 인접한 이전 버전의 `.venv`에서 사용 가능한 환경을 찾습니다.
3. 필요한 라이브러리가 모두 있으면 **pip를 실행하지 않고 바로 GUI를 엽니다.**
   누락되었거나 요구 버전보다 오래된 라이브러리만 설치하며, 환경을 다시 만들거나 전체 재설치하지 않습니다.
4. 별도 점검만 하려면 `install_windows.bat`를 실행합니다. 설치할 항목이 없으면 즉시 끝납니다.
5. `.exe`/`.com` GUI 실행 파일은 만들지 않습니다. 배치 파일이 Python 소스를 실행합니다.
   예전 `.cmd` 이름도 새 `.bat`로 연결됩니다.

**Windows 64비트 CalculiX 2.23과 필요한 DLL이 패키지에 포함되어 있습니다.**
별도 설치나 PATH 설정 없이 `solvers/calculix/bin/ccx_MT.exe`를 사용합니다.
실행에 필요한 폴더를 일부만 옮기지 말고 전체 압축을 해제하세요.
외부 버전을 쓰려면 **왼쪽 하단 상세 옵션 → CalculiX 솔버 경로**를 직접 입력하거나 …로 선택하세요.
선택한 경로는 프로그램을 닫을 때 `user_settings.json`에 저장합니다.
라이선스·다운로드 출처·해시는 [동봉 솔버 안내](solvers/calculix/README.md)에 있습니다.
Abaqus 실행에는 회사 PC의 Abaqus 설치가 필요합니다.

```text
CalculiX: "{solver}" -i {job}
Abaqus:   abaqus job={job} input={input} cpus={cpus} {oldjob} interactive
Viewer:   abaqus viewer database={odb}
ODB 변환: abaqus python {script} {odb} {output}
```

Python 환경에서 직접 실행할 수도 있습니다.

```console
python -m pip install -r requirements.txt
python -m system_drop.gui
```

## 누적 해석 실행

상세 옵션 → **누적 18방향 설정 적용** → 닫기 → **전체 자동 실행**.
Sequence 1/2/3 또는 Custom의 모든 낙하가 이전 안정화의 native 재료 상태에서 이어집니다.
낙하마다 제품 변형/소성/잔류응력을 유지하고 바닥·중력·새 낙하 속도를 갱신합니다.
18방향은 1 us 낙하의 짧은 실제 연결 시험으로 54개 작업 완료를 확인했습니다.
소성이 있는 제품의 다음 60 us 낙하와 1초 안정화도 별도로 완료했습니다.
[누적 연결, 수렴 기준과 실제 검증 범위](docs/CUMULATIVE_v050.md)를 확인하세요.

## 먼저 확인할 GUI 기능

**실제 해석 시험:** 상세 옵션 → **실제 Top Face 충돌 확인 설정 적용** → 전체 자동 실행.
확인된 예제 조건은 CPU 1, 높이 1000 mm, 갭 0.001 mm, 드랍 0.000060 s, 안정화 1 s입니다.
Linux 2.23에서 드랍 약 10분 17초, 안정화 약 17초에 정상 종료했습니다. PC별 시간은 다릅니다.
완료된 실제 결과는 상세 옵션의 **검증 예제 결과 보기**에서 재계산 없이 열 수 있습니다.
[시험 기록](docs/IMPACT_VALIDATION_v040.md).

왼쪽 하단 **상세 옵션 → 솔버 없이 실행 순서만 점검**을 선택하고 전체 자동 실행하세요.
Solver 실행 없이 시나리오 순서, Custom 중복 방향, 활성화 순서, 전체 게이지와 단계 버튼 진행률,
하이라이트, 일시정지·재개·취소·초기화, 로그, 완료 버튼의 PyVista 창을 확인할 수 있습니다.
이 모드는 형상을 변형시키거나 응력·소성을 계산하지 않습니다. 결과 창에도 이를 표시합니다.

기본 화면은 밝은 톤의 1080×720 크기이며, 템플릿/결과 위치/Viewer/초기 갭/솔버 경로는 **상세 옵션**에 있습니다.
드랍 횟수는 항상 표시합니다. 고정 시퀀스는 18회이며, `Custom`에서 횟수와 행별 방향을 조절합니다.
같은 방향을 여러 번 선택할 수 있습니다. 실행 버튼은 물결 진행률과 완료 소요 시간을 표시합니다.
드랍 높이와 간격은 소수점 3자리, 증분/시간은 6자리입니다. 작은 증분은 지수 표기로 보존합니다.
초기 증분은 화면에서 제거하고 템플릿 값을 사용합니다. 최대 증분 상한은 조절할 수 있습니다.
Abaqus/Explicit 자동 증분의 초기값은 솔버가 정합니다.
상세 옵션에서 Edge 각도(기본 30°)와 좌표계 기준 NSET를 확인할 수 있습니다.
방향 모식도는 바닥 고정·제품 회전으로 표현하며, 실제 해석은 제품의 현재 자세 기준으로 바닥/중력 방향을 설정합니다.
방향 셋업 미리보기는 760×540 창으로 열립니다.

## 계산이 정지처럼 보일 때

v0.5는 PID·경과 시간·CPU·실제 해석 시간·증분 번호를 표시합니다.
원본의 얇은 로고 Shell/tie 때문에 초기 안정 증분이 약 2.38e-9초이며,
0.02초에 약 840만 증분이 필요할 수 있습니다. 같은 모델의 2.5e-5초 자유비행 시험에
이 개발 환경에서 약 288초가 걸렸습니다. 작은 모델이어도 빠른 계산을 보장하지 않습니다.
[실측과 원인·구동 확인 방법](docs/DIAGNOSIS_0.3.1.md)을 참고하세요.

실제 Solver 모드와 워크플로 테스트는 실행 폴더의 `settings.json` / `checkpoint.json`으로 구분됩니다.
기존 실행을 초기화해도 결과는 삭제하지 않습니다. `이전 실행 폴더 열기 / 재개`로 체크포인트를 복구할 수 있습니다.
일시정지는 현재 단계를 끝낸 뒤 대기합니다. 즉시 취소는 솔버 프로세스 트리를 종료하고 해당 단계를 미완료로 남깁니다.
중단된 단계의 재개는 해당 단계를 처음부터 다시 실행하는 것이며, 증분 단위 hot restart는 아닙니다.

## 실제 Solver 지원 범위

| 기능 | 현재 상태 |
|---|---|
| 18방향 계산, 3개 시퀀스, Custom | 구현 및 자동 검사 |
| 전체 GUI 순서·로그·진행률·중지 | 구현 및 자동 검사 |
| PyVista 별도 창 | 구현, 형상·FRD 결과 창 검사 |
| CalculiX 첫 Explicit → 별도 Implicit 안정화 | **2.23에서 실제 Top Face 충돌과 native restart 연결 완료** |
| CalculiX 실제 충돌 및 1초 안정화 | **원래 C3D8/S4/tie 모델로 계산 완료, 응력·소성·반발 확인** |
| CalculiX 안정화 → 다음 낙하 | **2.23 native 소성/응력/변형 이력 연결 구현; 18방향 실제 연결 시험** |
| Abaqus 최초 낙하 입력 | 생성 구현, Abaqus 실행 미검증 |
| Abaqus Explicit ↔ Standard native Import | 생성 구현, Abaqus 실행 미검증 |
| ODB → VTU/JSON | Abaqus Python용 스크립트 제공, 실제 ODB 미검증 |
| Windows 실기기·Abaqus Viewer | 실행 경로 구현, 실기기 미검증 |

CalculiX의 다음 낙하 연결은 native 바닥 좌표와 새 낙하 속도를 갱신하고 원래 낙하 감쇠를 복원합니다.
다른 재료 상태를 그대로 보존하고 각 전달의 해시를 검사합니다.
짧은 18방향 연결 시험과 충분한 충돌 시간을 둔 소성 상태의 다음 낙하 시험은 구분합니다.
[검증 기록과 지원 버전](docs/CUMULATIVE_v050.md)을 참고하세요.
CalculiX 2.20에서는 이 예제의 Explicit 실행이 비정상 종료되어 2.23으로 검토했습니다.

과거 S4 모델은 CalculiX에서 3D로 확장되어 매우 작은 안정 증분이 필요할 수 있습니다. 현재 기본 템플릿은 C3D8만 사용합니다.
기본 템플릿은 `template_calculix`와 `template_abaqus` 두 폴더만 제공합니다. 참고용 템플릿 폴더는 배포하지 않습니다.
질량 스케일링은 자동 적용하지 않습니다. 1초 릴리즈가 잔류응력 안정화를 보증하지 않으므로 이력을 확인해야 합니다.

## 템플릿

```text
template_abaqus/                     template_calculix/
  abaqus_main.inp                     calculix_main.inp
  abaqus_material.inp                 calculix_material.inp
  abaqus_mesh.inp                     calculix_mesh.inp
```

각 main은 다른 두 파일을 include합니다. section, tie, 바닥·접촉 조건은 main에 한 번만 정의합니다.
자동화는 재료 파일을 그대로 복사하고 section/tie/접촉을 덧붙이지 않습니다.
`AUTO:BEGIN / AUTO:END` 주석으로 표시한 FLOOR, VELOCITY, DROP_STEP 블록만 갱신합니다.
main 자체는 기본 Top Face 단독 낙하 입력입니다. 릴리즈는 실행 결과의 native 상태를 사용해 별도 생성합니다.

HyperMesh 출력은 현재 **flat C3D8/S4 모델**만 지원합니다. Part/Assembly 및 다른 요소는 오류로 알립니다.
INCLUDE 대상은 선택한 템플릿 폴더 내부에 보관하세요. 상대 경로를 함께 복사합니다.
기존 자동화 블록·PRODUCT_CONTACT/FLOOR_SURFACE·FRAME 집합 이름은 유지해야 합니다.
새 부품은 mesh에 넣고 main에 section을 정의하면 전체 요소·노드 집합을 다시 구성합니다.
접촉 surface의 새 부품 포함 여부는 템플릿에서 정의해야 합니다.

현재 템플릿은 304×212×16 mm, C3D8 384개 / Aluminum·Plastic 2개 그룹 / 그룹당 두께 2층입니다.
임의 알루미늄 물성은 재료 시험 데이터가 아니며 실제 제품의 성능 예측에 사용할 수 없습니다.
shell midsurface offset 0을 전제로 바닥 간격에 두께를 반영합니다.
CalculiX 마찰 0은 `*FRICTION` 생략으로 표현합니다(계수 0은 입력 오류).

## 좌표계·조건

- Right +X / Top +Y / Front +Z / Rear −Z.
- Top은 로고 면, Bottom은 반대 면.
- `FRAME_ORIGIN` Front-Left, `FRAME_X` Front-Right, `FRAME_Y` Back-Left: 같은 상면의 한 노드씩.
- 두 벡터를 직교화하고 외적으로 Top을 계산합니다. 매 릴리즈 종료 형상에서 갱신합니다.
- Corner는 XZ 평면의 제품 대각선과 평행하게 낙하하며 두께 모서리가 접촉합니다.
- Edge는 넓은 면과 바닥이 30도입니다.
- 중력은 매 낙하 동안 전역 방향에 고정하며 강체 바닥은 중력 대상에서 제외합니다.
- 단위 mm–tonne–s–N, 중력 9810 mm/s², 초기속도 `sqrt(2*g*(height-gap))`.
- CalculiX 예제: 높이 1000 mm, 초기 갭 입력 0.001 mm, 드랍 0.000060 s. 첫 Top Face 시험 확인용.
- Abaqus와 CalculiX 참조 템플릿: 높이 1000 mm, 간격 1 mm, 드랍 0.02 s.
- 릴리즈 초기/최대 증분 0.01 s, 종료 1 s. 무중력·바닥 접촉 없음.
- CalculiX 릴리즈는 native restart와 `ALPHA=-0.3`을 사용합니다. 강체 운동 감쇠나 저주파 안정화를 보증하지 않습니다.

## 결과·로그

완료 버튼은 결과를 별도 프로세스로 엽니다. Viewer 오류나 닫기 동작은 해석을 정지시키지 않습니다.
Abaqus는 Viewer/PyVista를 선택하고, CalculiX와 셋업 미리보기는 PyVista를 사용합니다.
PyVista 변위 배율은 FRD/ODB 변위를 사용합니다. FRD shell 결과는 원래 노드의 평균값(`OUTPUT=2D`)이며,
ODB 응력은 요소별 Mises 평균을 표시합니다. Abaqus Viewer의 적분점/section point 결과와 구분하세요.

전체 게이지는 작업 진행률, 각 실행 버튼은 해당 단계의 실제 진행률을 표시합니다.
예상 실행 시간이나 물리 정확도를 나타내지 않습니다.
솔버 상태가 갱신되지 않으면 마지막 확인한 비율을 유지하고, 종료·결과 변환 검사를 통과해야 100%가 됩니다.

실행 폴더는 한국 날짜 기준 `doe_calculix_YYMMDD_r01` / `doe_abaqus_YYMMDD_r01`입니다.
설정·템플릿 사본·체크포인트·자동화 로그·단계별 솔버 로그·입력·결과를 보관합니다.

## 개발 검증

```console
python -m pip install pytest
python -m pytest -q
python tools/validate_calculix.py --ccx "C:\Solvers\CalculiX\ccx.exe"
python tools/validate_directions.py --ccx "C:\Solvers\CalculiX\ccx.exe"
```

검사 범위와 미검증 사항은 [docs/VALIDATION.md](docs/VALIDATION.md)를 참고하세요.
