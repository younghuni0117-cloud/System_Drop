from __future__ import annotations

from pathlib import Path
import argparse
import sys

from PySide6 import QtCore, QtGui, QtWidgets as W

from .deck import template_defaults,read_mesh
from .engine import Engine
from .model import ROOT, NAMES, SCENARIOS, STAGES, STAGE_LABELS, Settings,bundled_calculix
from .solver import command_args, popen, stage_folder, resolve_solver_command
from .output_schedule import decimal_text,frame_count
from .schematic import direction_icon
from .stage_button import StageButton


STYLE="""
QWidget { background:#f4f6f9; color:#243449; font-size:12px; }
QLabel#title { font-size:18px; font-weight:700; color:#243c58; }
QGroupBox { border:1px solid #d5dfe9; border-radius:5px; margin-top:9px; padding:9px 5px 5px; font-weight:600; }
QGroupBox::title { subcontrol-origin:margin; left:8px; padding:0 4px; color:#49627e; }
QLineEdit,QComboBox,QDoubleSpinBox,QSpinBox { background:white; border:1px solid #cbd5e0; border-radius:3px; padding:2px 4px; min-height:18px; }
QPushButton { background:#ffffff; border:1px solid #c9d5e1; border-radius:4px; padding:4px 8px; }
QPushButton:hover { background:#e8f1fb; border-color:#8fb5de; }
QPushButton:disabled { color:#9aa6b6; background:#f0f3f7; border-color:#dce3eb; }
QPushButton#primary { background:#2879b9; border-color:#246ba3; color:white; font-weight:600; }
QPushButton#stage { padding:1px 3px; border-radius:2px; }
QProgressBar { border:1px solid #c9d5e2; border-radius:4px; background:white; height:18px; text-align:center; font-weight:600; }
QProgressBar::chunk { background:#9ccbe9; border-radius:3px; }
QTableWidget { background:white; alternate-background-color:#f5f8fc; gridline-color:#e0e6ef; border:1px solid #ced9e5; }
QHeaderView::section { background:#e9eff6; color:#46607b; padding:4px; border:0; border-bottom:1px solid #ccd9e6; }
QTabWidget::pane { border:1px solid #d1dce7; }
QTabBar::tab { background:#edf1f6; padding:4px 12px; }
QTabBar::tab:selected { background:white; color:#286ca4; }
QPlainTextEdit { background:white; border:0; color:#3c4e62; font-size:11px; }
QScrollArea { border:0; }
QToolTip { color:#243449; background:#ffffff; border:1px solid #b5c8da; }
"""
STYLE += """
QSpinBox,QDoubleSpinBox { padding-right:19px; }
QSpinBox::up-button,QDoubleSpinBox::up-button {subcontrol-origin:border;subcontrol-position:top right;width:17px;height:12px;background:#e4ebf3;border-left:1px solid #c0cedd;border-bottom:1px solid #c0cedd;}
QSpinBox::down-button,QDoubleSpinBox::down-button {subcontrol-origin:border;subcontrol-position:bottom right;width:17px;height:12px;background:#e4ebf3;border-left:1px solid #c0cedd;}
QSpinBox::up-arrow,QDoubleSpinBox::up-arrow {image:url("@ASSETS@/arrow_up.svg");width:8px;height:5px;}
QSpinBox::down-arrow,QDoubleSpinBox::down-arrow {image:url("@ASSETS@/arrow_down.svg");width:8px;height:5px;}
QComboBox::drop-down {subcontrol-origin:border;subcontrol-position:top right;width:17px;border-left:1px solid #c0cedd;background:#e4ebf3;}
QComboBox::down-arrow {image:url("@ASSETS@/arrow_down.svg");width:8px;height:5px;}
""".replace("@ASSETS@",(ROOT/"assets").as_posix())


class TimeSpin(W.QDoubleSpinBox):
    """Plain decimal time values, including sub-microsecond increments."""
    def __init__(self,value):
        super().__init__();self.setDecimals(15);self.setRange(0,1e5);self.setValue(value)
        self.setMinimumWidth(80);self.setSizePolicy(W.QSizePolicy.Policy.Ignored,W.QSizePolicy.Policy.Fixed)
    def textFromValue(self,value):
        return decimal_text(value)
    def valueFromText(self,text):
        return 0. if text.strip()=="자동" else float(text)
    def validate(self,text,pos):
        try:
            value=float(text)
            state=QtGui.QValidator.State.Acceptable if self.minimum()<=value<=self.maximum() else QtGui.QValidator.State.Intermediate
        except ValueError: state=QtGui.QValidator.State.Intermediate
        return state,text,pos
    def stepBy(self,steps):
        step=max(abs(self.value())*.1,0.000000000000001)
        self.setValue(max(self.minimum(),min(self.maximum(),self.value()+steps*step)))


class Worker(QtCore.QThread):
    event=QtCore.Signal(str,object)
    def __init__(self,engine,automatic,parent=None):
        super().__init__(parent); self.engine=engine; self.automatic=automatic
        engine.emit=self.event.emit
    def run(self): self.engine.execute(self.automatic)


class Window(W.QMainWindow):
    def __init__(self,preferences_path=None):
        super().__init__()
        self.setWindowTitle("중형 NBPC System 누적 드랍 Simulation Manager")
        self.resize(1080,720)
        self.setMinimumSize(940,600)
        self.engine=None; self.worker=None; self.viewers=[]
        self.directions=list(SCENARIOS["18-Side Drop Sequence 1"])
        self.custom_directions=[1]
        self.direction_combos={}
        self.buttons={}; self.log_widgets={}; self.controls=[]; self.loading=False
        container=W.QWidget(); self.setCentralWidget(container)
        outer=W.QVBoxLayout(container); outer.setContentsMargins(10,8,10,8); outer.setSpacing(6)
        header=W.QHBoxLayout()
        title=W.QLabel(self.windowTitle()); title.setObjectName("title"); header.addWidget(title)
        header.addStretch()
        self.sequence_check=W.QCheckBox("솔버 없이 실행 순서만 점검")
        self.sequence_check.setToolTip("실제 Solver를 실행하지 않고 단계 순서와 결과 창 연결만 확인합니다.")
        self.controls.append(self.sequence_check)
        self.details_button=W.QPushButton("상세 옵션")
        outer.addLayout(header)
        outer.addSpacing(10)
        split=W.QSplitter(QtCore.Qt.Orientation.Horizontal); outer.addWidget(split,1)
        self.left_scroll=W.QScrollArea(); self.left_scroll.setWidgetResizable(True)
        self.left_scroll.setMinimumWidth(285); self.left_scroll.setMaximumWidth(335)
        self.left_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        left=W.QWidget(); left.setMinimumWidth(0)
        self.left_layout=W.QVBoxLayout(left); self.left_layout.setContentsMargins(0,0,4,0); self.left_layout.setSpacing(4)
        self.left_scroll.setWidget(left); split.addWidget(self.left_scroll)
        right=W.QWidget(); right_layout=W.QVBoxLayout(right); right_layout.setContentsMargins(3,0,0,0); right_layout.setSpacing(5); split.addWidget(right)
        split.setSizes([315,765]); split.setChildrenCollapsible(False)
        self.build_settings()
        self.details_button.clicked.connect(self.show_details)
        self.sequence_check.toggled.connect(self.mode_changed)
        compact=W.QWidget();toolbar=W.QHBoxLayout(compact);toolbar.setContentsMargins(0,0,0,0);toolbar.setSpacing(4);right_layout.addWidget(compact)
        self.start=W.QPushButton("▶ 자동 실행"); self.start.setObjectName("primary")
        self.pause=W.QPushButton("Ⅱ 일시정지"); self.cancel=W.QPushButton("전체 취소")
        self.reset=W.QPushButton("초기화")
        for b in (self.start,self.pause,self.cancel,self.reset):
            b.setMinimumWidth(0);b.setSizePolicy(W.QSizePolicy.Policy.Ignored,W.QSizePolicy.Policy.Fixed);toolbar.addWidget(b,3)
        self.start.clicked.connect(lambda:self.launch(True)); self.pause.clicked.connect(self.pause_run)
        self.cancel.clicked.connect(self.cancel_run); self.reset.clicked.connect(self.reset_run)
        self.overall=W.QProgressBar();self.overall.setRange(0,100000);self.overall.setValue(0);self.overall.setFormat('진행률 0.0%')
        self.overall.setMinimumWidth(180);toolbar.addWidget(self.overall,5)
        self.active=W.QLabel("대기 · 다음 실행 가능한 단계를 클릭하거나 전체 자동 실행하세요.");right_layout.addWidget(self.active)
        self.live=W.QLabel("");self.live.setWordWrap(True);self.live.setStyleSheet('color:#54718b;font-size:11px;')
        self.live.setToolTip('CPU는 호출 프로세스 기준이며 한 코어를 모두 쓰면 100%입니다. CPU 활동만으로 해석 시간 진행을 단정하지 않습니다.')
        right_layout.addWidget(self.live)
        self.mode_notice=W.QLabel("")
        self.mode_notice.setWordWrap(True); self.mode_notice.hide(); right_layout.addWidget(self.mode_notice)
        vertical=W.QSplitter(QtCore.Qt.Orientation.Vertical); right_layout.addWidget(vertical,1)
        self.table=W.QTableWidget(0,5); self.table.setHorizontalHeaderLabels(["No.","방향","1. 방향 셋업","2. 드랍해석","3. 안정화해석"])
        self.table.setIconSize(QtCore.QSize(36,22))
        self.table.verticalHeader().hide(); self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(W.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(W.QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(1,W.QHeaderView.ResizeMode.Interactive)
        self.table.setColumnWidth(1,205)
        for c in (2,3,4): self.table.horizontalHeader().setSectionResizeMode(c,W.QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0,36);self.table.verticalHeader().setMinimumSectionSize(19)
        vertical.addWidget(self.table)
        log_panel=W.QWidget(); lp=W.QVBoxLayout(log_panel); lp.setContentsMargins(0,4,0,0)
        self.tabs=W.QTabWidget(); lp.addWidget(self.tabs)
        for name in ("전체","자동화","솔버",".sta","오류"):
            widget=W.QPlainTextEdit(); widget.setReadOnly(True); widget.setMaximumBlockCount(6000);widget.setMinimumHeight(35)
            widget.setFont(QtGui.QFontDatabase.systemFont(QtGui.QFontDatabase.SystemFont.FixedFont))
            self.log_widgets[name]=widget; self.tabs.addTab(widget,name)
        vertical.addWidget(log_panel);vertical.setStretchFactor(0,1);vertical.setStretchFactor(1,0);vertical.setSizes([460,95])
        self.statusBar().showMessage("템플릿 로드 중")
        self.load_template_defaults()
        self.preferences_path=None if preferences_path is False else Path(preferences_path) if preferences_path else ROOT/"user_settings.json"
        if self.preferences_path and self.preferences_path.exists():
            try:
                self.apply_settings(Settings.read(self.preferences_path))
                self.log("자동화","이전 사용자 설정을 불러왔습니다.")
            except Exception as exc: self.log("오류",f"사용자 설정 읽기 실패: {exc}")
        self.refresh_table()
        self.viewer_timer=QtCore.QTimer(self); self.viewer_timer.timeout.connect(self.poll_viewers); self.viewer_timer.start(1000)

    def group(self,title):
        group=W.QGroupBox(title); layout=W.QFormLayout(group); layout.setFieldGrowthPolicy(W.QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        layout.setContentsMargins(6,10,6,5); layout.setHorizontalSpacing(6); layout.setVerticalSpacing(4)
        self.left_layout.addWidget(group); return layout

    def edit(self,text):
        widget=W.QLineEdit(text); widget.setMinimumWidth(0)
        widget.setSizePolicy(W.QSizePolicy.Policy.Ignored,W.QSizePolicy.Policy.Fixed)
        self.controls.append(widget); return widget

    def number(self,value,minimum,maximum,decimals=4):
        widget=W.QDoubleSpinBox(); widget.setDecimals(decimals); widget.setRange(minimum,maximum); widget.setValue(value)
        widget.setMinimumWidth(70)
        widget.setSizePolicy(W.QSizePolicy.Policy.Ignored,W.QSizePolicy.Policy.Fixed)
        self.controls.append(widget); return widget

    def pathrow(self,widget,callback):
        wrapper=W.QWidget(); layout=W.QHBoxLayout(wrapper); layout.setContentsMargins(0,0,0,0)
        layout.addWidget(widget); button=W.QPushButton("…"); button.setMaximumWidth(28); button.clicked.connect(callback)
        layout.addWidget(button); self.controls.append(button); return wrapper

    def build_settings(self):
        defaults=Settings()
        f=self.group("해석 설정")
        self.solver=W.QComboBox(); self.solver.addItem("CalculiX 2.23 (Open-Source)","calculix"); self.solver.addItem("Abaqus 2025","abaqus"); self.controls.append(self.solver)
        f.addRow("Solver",self.solver)
        self.cpus=W.QSpinBox(); self.cpus.setRange(1,1024); self.cpus.setValue(defaults.cpus); self.controls.append(self.cpus); f.addRow("CPU",self.cpus)
        self.scenario=W.QComboBox(); self.scenario.addItems(SCENARIOS); self.controls.append(self.scenario); f.addRow("시나리오",self.scenario)
        for combo in (self.solver,self.scenario):
            combo.setMinimumWidth(0); combo.setSizePolicy(W.QSizePolicy.Policy.Ignored,W.QSizePolicy.Policy.Fixed)
        self.custom_count=W.QSpinBox(); self.custom_count.setRange(1,1000); self.controls.append(self.custom_count)
        self.custom_count_label=W.QLabel("드랍 횟수"); f.addRow(self.custom_count_label,self.custom_count)
        self.custom_count.valueChanged.connect(self.change_custom_count)
        self.solver.currentIndexChanged.connect(self.change_solver)
        self.scenario.currentIndexChanged.connect(self.change_sequence)
        self.details_direction_group=W.QGroupBox("방향 설정")
        f=W.QFormLayout(self.details_direction_group)
        self.edge_angle=self.number(30,.1,89.9,1);f.addRow("Edge 각도 (°)",self.edge_angle)
        self.edge_angle.setToolTip("제품의 넓은 면과 바닥면 사이 각도. Face/Corner에는 영향을 주지 않습니다.")
        self.edge_angle.valueChanged.connect(lambda:self.refresh_table() if hasattr(self,"table") else None)
        check=W.QPushButton("좌표계 기준점 확인");check.clicked.connect(self.check_frame);f.addRow(check)
        f=self.group("드랍 해석 셋업")
        self.drop_height=self.number(1000,.001,1e7,3); f.addRow("드랍 높이 (mm)",self.drop_height)
        self.drop_dt=TimeSpin(1e-7);self.drop_dt.hide()
        self.drop_max_dt=TimeSpin(1e-6);self.drop_max_dt.setSpecialValueText("자동");self.controls.append(self.drop_max_dt);f.addRow("최대 증분 (s)",self.drop_max_dt)
        self.drop_max_dt.setToolTip('조절 가능한 상한입니다. 실제 Explicit 증분은 안정 조건에 따라 이 값보다 더 작게 결정됩니다.')
        self.drop_time=TimeSpin(.02); self.drop_time.setRange(0.000000000001,1000);self.controls.append(self.drop_time); f.addRow("종료 시간 (s)",self.drop_time)
        self.expected_frames=W.QLabel();self.expected_frames.setStyleSheet("color:#54718b;font-size:11px;");f.addRow(self.expected_frames)
        self.expected_frames.setToolTip("최대 증분을 결과 저장 시간 간격으로 사용합니다. 0초 초기 프레임은 제외하며 마지막 짧은 구간도 1개로 셉니다. 솔버의 실제 적분 증분과는 별개입니다.")
        self.drop_time.valueChanged.connect(self.update_expected_frames)
        self.drop_max_dt.valueChanged.connect(self.update_expected_frames)
        self.update_expected_frames()
        f=self.group("안정화 해석 셋업")
        self.release_dt=TimeSpin(.01);self.release_dt.setRange(0.000000000001,1000);self.controls.append(self.release_dt); f.addRow("초기 증분 (s)",self.release_dt)
        self.release_max=TimeSpin(.01);self.release_max.setRange(0.000000000001,1000);self.controls.append(self.release_max); f.addRow("최대 증분 (s)",self.release_max)
        self.release_time=TimeSpin(1);self.release_time.setRange(0.000000000001,100000);self.controls.append(self.release_time); f.addRow("종료 시간 (s)",self.release_time)
        self.expected_release_frames=W.QLabel();self.expected_release_frames.setStyleSheet('color:#54718b;font-size:11px;');f.addRow(self.expected_release_frames)
        self.expected_release_frames.setToolTip('최대 증분 기준 예상치입니다. Implicit 자동 증분으로 실제 출력 프레임은 늘어날 수 있습니다.')
        self.release_time.valueChanged.connect(self.update_expected_release_frames);self.release_max.valueChanged.connect(self.update_expected_release_frames);self.update_expected_release_frames()
        self.left_layout.addStretch()
        self.all_results=W.QPushButton('해석 결과 - PyVista (Open-Source)');self.all_results.clicked.connect(self.open_all_results)
        self.left_layout.addWidget(self.all_results)
        self.left_layout.addWidget(self.details_button)
        self.details=W.QDialog(self); self.details.setWindowTitle("상세 옵션"); self.details.resize(710,600)
        detail_outer=W.QVBoxLayout(self.details);detail_scroll=W.QScrollArea();detail_scroll.setWidgetResizable(True)
        detail_scroll.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOff);detail_outer.addWidget(detail_scroll,1)
        detail_content=W.QWidget();detail_scroll.setWidget(detail_content);detail_layout=W.QVBoxLayout(detail_content)
        f=W.QFormLayout();f.setFieldGrowthPolicy(W.QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow);f.setVerticalSpacing(6);detail_layout.addLayout(f)
        detail_layout.addWidget(self.details_direction_group)
        self.release_damping=self.number(20,0,100000,3);f.addRow("안정화 감쇠 α (1/s)",self.release_damping)
        self.release_damping.setToolTip("안정화 전용 C=αM. 기본 20 /s. 강체 병진·회전 속도는 안정화 시작 시 제거합니다.")
        self.template=self.edit(defaults.template); f.addRow("템플릿",self.pathrow(self.template,self.choose_template))
        self.template.editingFinished.connect(self.load_template_defaults)
        self.template_check=W.QPushButton('Abaqus 템플릿 검사 / 매핑');self.template_check.clicked.connect(self.inspect_template);f.addRow(self.template_check)
        self.output=self.edit(defaults.output_root); f.addRow("결과 위치",self.pathrow(self.output,self.choose_output))
        self.viewer=W.QComboBox(); self.viewer.addItems(["PyVista","Abaqus Viewer"]); f.addRow("결과 Viewer",self.viewer)
        self.gap=self.number(1,0,1e6,3);f.addRow("초기 갭 (mm)",self.gap)
        explanation=W.QLabel("해석 시작 시 제품 접촉면과 바닥 사이 거리입니다.\n이 거리만큼 중력으로 이동하므로 초기속도는 √[2g(드랍 높이−갭)]로 보정합니다.")
        explanation.setWordWrap(True);f.addRow(explanation)
        self.ccx_path=self.edit(str(bundled_calculix()));path_row=self.pathrow(self.ccx_path,self.choose_calculix)
        self.ccx_browse=path_row.findChild(W.QPushButton);f.addRow("CalculiX 솔버 경로",path_row)
        self.ccx_command=self.edit(defaults.calculix_command)
        f.addRow("CalculiX 명령",self.ccx_command)
        self.abq_command=self.edit(defaults.abaqus_command); f.addRow("Abaqus",self.abq_command)
        self.viewer_command=self.edit(defaults.viewer_command); f.addRow("Viewer 명령",self.viewer_command)
        self.abq_python=self.edit(defaults.abaqus_python); f.addRow("ODB 변환",self.abq_python)
        help_label=W.QLabel("{solver}는 위 솔버 경로입니다. 기본값은 패키지에 포함한 Windows x64 솔버입니다.\n실행 순서 점검은 실제 솔버·응력 계산 없이 GUI 순서만 확인하는 개발 기능입니다."); help_label.setWordWrap(True); f.addRow(help_label)
        f.addRow(self.sequence_check)
        self.impact_preset=W.QPushButton('실제 Top Face 충돌 확인 설정 적용')
        self.impact_preset.setToolTip('CalculiX, CPU 4, 높이 1000 mm, 갭 0.001 mm, 종료 0.000060 s, Custom 1회로 설정합니다.')
        self.impact_preset.clicked.connect(self.apply_impact_preset);self.controls.append(self.impact_preset);detail_layout.insertWidget(0,self.impact_preset)
        self.cumulative_preset=W.QPushButton('누적 18방향 설정 적용')
        self.cumulative_preset.setToolTip('CalculiX / Sequence 1 / 높이 1000 mm / 갭 0.001 mm / 낙하 0.000060 s / 안정화 1 s. 방향별 평가 시간은 검토하세요.')
        self.cumulative_preset.clicked.connect(self.apply_cumulative_preset)
        self.controls.append(self.cumulative_preset);detail_layout.insertWidget(0,self.cumulative_preset)
        example_row=W.QHBoxLayout();self.example_stage=W.QComboBox();self.example_stage.addItems([
            '2파트 Al/Plastic · 첫 낙하','2파트 Al/Plastic · 첫 안정화','2파트 Al/Plastic · 낙하만 연속','2파트 Al/Plastic · 누적 전체'])
        example_open=W.QPushButton('검증 예제 결과 보기');example_open.clicked.connect(self.open_example)
        example_row.addWidget(self.example_stage);example_row.addWidget(example_open);detail_layout.addLayout(example_row)
        buttons=W.QHBoxLayout()
        save=W.QPushButton("설정 저장"); load=W.QPushButton("설정 열기")
        buttons.addWidget(save); buttons.addWidget(load); detail_layout.addLayout(buttons)
        save.clicked.connect(self.save_settings); load.clicked.connect(self.load_settings)
        self.controls.extend([load])
        restore=W.QPushButton("이전 실행 폴더 열기 / 재개"); detail_layout.addWidget(restore); self.controls.append(restore); restore.clicked.connect(self.restore_run)
        close=W.QPushButton("닫기"); close.clicked.connect(self.details.hide); detail_outer.addWidget(close)

    def update_expected_release_frames(self):
        count=frame_count(self.release_time.value(),self.release_max.value())
        self.expected_release_frames.setText(f'예상 Frame : {count:,}개' if count is not None else '예상 Frame : 자동')

    def inspect_template(self):
        from .template_dialog import TemplateDialog
        dialog=TemplateDialog(self,Path(self.template.text()));dialog.exec();self.load_template_defaults()

    def open_all_results(self):
        from .timeline import collect_stages,read_json
        folder=self.engine.run if self.engine and self.engine.run else None
        if folder is None:
            selected=W.QFileDialog.getExistingDirectory(self,'전체 결과를 볼 doe 폴더',self.output.text())
            if not selected:return
            folder=Path(selected)
        if not collect_stages(folder):W.QMessageBox.information(self,'결과 보기','아직 완료된 해석 결과가 없습니다.');return
        args=[sys.executable,'-m','system_drop.viewer',str(folder)]
        if read_json(folder/'checkpoint.json',{}).get('workflow'):args.append('--workflow')
        try:
            logfile=(folder/'viewer.log').open('ab');process=popen(args,ROOT,logfile)
            self.viewers.append((process,logfile,folder));self.log('자동화','PyVista 전체 결과 창 열기 — 진행 중 해석은 계속됩니다.')
        except Exception as exc:self.log('오류',str(exc))

    def update_expected_frames(self):
        count=frame_count(self.drop_time.value(),self.drop_max_dt.value())
        self.expected_frames.setText(f"예상 Frame : {count:,}개" if count is not None else "예상 Frame : 자동")

    def show_details(self):
        self.details.show(); self.details.raise_(); self.details.activateWindow()

    def apply_impact_preset(self):
        if self.engine is not None:
            W.QMessageBox.information(self,'충돌 확인 설정','기존 실행을 초기화한 뒤 적용하세요.');return
        self.solver.setCurrentIndex(self.solver.findData('calculix'));self.scenario.setCurrentText('Custom')
        self.custom_directions=[1];self.directions=[1];self.refresh_table()
        self.drop_height.setValue(1000);self.gap.setValue(.001);self.drop_time.setValue(.000060);self.cpus.setValue(4)
        self.sequence_check.setChecked(False)
        self.log('자동화','실제 Top Face 충돌 확인 설정: 높이 1000 mm / 갭 0.001 mm / 0.000060 s / CPU 4. 최종 평가용 시간은 방향별로 검토하세요.')

    def apply_cumulative_preset(self):
        if self.engine is not None:
            W.QMessageBox.information(self,'누적 설정','기존 실행을 초기화한 뒤 적용하세요.');return
        self.solver.setCurrentIndex(self.solver.findData('calculix'))
        self.scenario.setCurrentText('18-Side Drop Sequence 1')
        self.drop_height.setValue(1000);self.gap.setValue(.001);self.drop_time.setValue(.000060);self.cpus.setValue(4)
        self.release_dt.setValue(.01);self.release_max.setValue(.01);self.release_time.setValue(1)
        self.sequence_check.setChecked(False)
        self.log('자동화','누적 18방향 실제 해석 설정: 이전 안정화 native 이력을 다음 낙하에 연결합니다. 방향별 평가 시간과 계산 소요 시간은 검토하세요.')

    def open_example(self):
        folders=['two_material/drop_01','two_material/release_01','two_material','two_material']
        folder=ROOT/'examples'/folders[self.example_stage.currentIndex()]
        try:
            if not (folder/'results/frames.json').exists() and not (folder/'sequence.json').exists():raise FileNotFoundError('검증 예제 파일이 없습니다. 전체 패키지를 사용하세요.')
            logfile=(folder/'viewer.log').open('ab')
            args=[sys.executable,'-m','system_drop.viewer',str(folder),'--example']
            if self.example_stage.currentIndex()==2:args.append('--drop-only')
            process=popen(args,ROOT,logfile)
            self.viewers.append((process,logfile,folder));self.log('자동화','완료된 Linux 검증 예제 결과를 엽니다. 현재 해석은 계속 진행됩니다.')
        except Exception as exc:self.log('오류',f'검증 예제 열기 실패: {exc}')

    def choose_calculix(self):
        path,_=W.QFileDialog.getOpenFileName(self,"CalculiX 실행 파일 선택",str(ROOT),"CalculiX (ccx*.exe ccx*.bat ccx*.cmd ccx*);;모든 파일 (*)")
        if path:
            self.ccx_path.setText(path)
            self.log("자동화",f"CalculiX 실행 파일 지정: {path}")

    def check_frame(self):
        try:
            mesh=read_mesh(Path(self.template.text())/f"{self.solver.currentData()}_mesh.inp")
            points=mesh.reference_points()
            text="\n".join(f"{name}: {point.round(6).tolist()}" for name,point in zip(("FRAME_ORIGIN","FRAME_X","FRAME_Y"),points))
            from .model import frame
            frame(*points)
            self.log("자동화",text);W.QMessageBox.information(self,"초기 모델 좌표계 기준점",text+"\n안정화 해석 후에는 변형된 기준점 좌표로 방향을 갱신합니다.")
        except Exception as exc:W.QMessageBox.warning(self,"기준점 확인",str(exc))

    def log(self,channel,text):
        for name in ("전체",channel):
            widget=self.log_widgets.get(name)
            if widget:
                bar=widget.verticalScrollBar(); position=bar.value()
                widget.appendPlainText(text)
                bar.setValue(bar.maximum())

    def busy(self): return self.worker is not None and self.worker.isRunning()

    def change_solver(self):
        if self.loading: return
        self.template.setText(str(ROOT/f"template_{self.solver.currentData()}"))
        if self.solver.currentData()=="calculix": self.viewer.setCurrentText("PyVista")
        self.viewer.setEnabled(self.solver.currentData()=="abaqus")
        self.load_template_defaults()

    def change_sequence(self):
        if self.loading: return
        custom=self.scenario.currentText()=="Custom"
        self.directions=list(self.custom_directions if custom else SCENARIOS[self.scenario.currentText()])
        self.refresh_table()

    def change_custom_count(self,count):
        if self.loading or self.scenario.currentText()!="Custom": return
        values=self.custom_directions[:count]
        values.extend([values[-1] if values else 1]*(count-len(values)))
        self.custom_directions=values; self.directions=list(values); self.refresh_table()

    def change_custom_direction(self,row,direction):
        if self.loading or self.engine is not None: return
        self.custom_directions[row]=direction; self.directions[row]=direction

    def mode_changed(self):
        workflow=self.sequence_check.isChecked()
        self.mode_notice.setVisible(workflow)
        self.mode_notice.setText("시퀀스 체크 · 실제 Solver 실행 및 응력 계산 없음")
        self.mode_notice.setStyleSheet("color:#9b6c17;")

    def choose_template(self):
        value=W.QFileDialog.getExistingDirectory(self,"템플릿 폴더",self.template.text())
        if value: self.template.setText(value); self.load_template_defaults()

    def choose_output(self):
        value=W.QFileDialog.getExistingDirectory(self,"결과 저장 폴더",self.output.text())
        if value: self.output.setText(value)

    def load_template_defaults(self):
        if self.loading: return
        try:
            solver=self.solver.currentData()
            path=Path(self.template.text())/f"{solver}_main.inp"
            values=template_defaults(path); self.drop_time.setValue(values["drop_time"])
            if 'gap' in values:self.gap.setValue(values['gap'])
            self.drop_dt.setValue(values["drop_dt"]);self.drop_max_dt.setValue(values["drop_max_dt"])
            self.drop_dt.setSpecialValueText("자동")
            self.drop_dt.setEnabled(solver=="calculix")
            self.drop_dt.setToolTip("Abaqus/Explicit 자동 증분에서는 초기 증분을 솔버가 계산합니다. 최대 증분만 지정할 수 있습니다." if solver=="abaqus" else "템플릿의 초기 증분입니다. 안정 시간 증분에 따라 솔버가 더 작게 계산할 수 있습니다.")
            self.log("자동화",f"템플릿 로드: {path}\n낙하 종료 시간 {decimal_text(values['drop_time'])} s / 재료·section·tie·접촉은 템플릿 사용")
            self.statusBar().showMessage("템플릿 로드 완료")
        except Exception as exc:
            self.log("오류",f"템플릿 읽기 실패: {exc}"); self.statusBar().showMessage("템플릿 확인 필요")

    def settings(self):
        initial=self.drop_dt.value();maximum=self.drop_max_dt.value()
        if self.solver.currentData()=='calculix' and maximum>0:initial=min(initial,maximum)
        return Settings(solver=self.solver.currentData(),scenario=self.scenario.currentText(),directions=list(self.directions),
            template=self.template.text(),output_root=self.output.text(),height=self.drop_height.value(),gap=self.gap.value(),
            drop_time=self.drop_time.value(),release_dt=self.release_dt.value(),release_max_dt=self.release_max.value(),release_time=self.release_time.value(),release_damping=self.release_damping.value(),
            drop_dt=initial,drop_max_dt=maximum,edge_angle=self.edge_angle.value(),
            cpus=self.cpus.value(),calculix_command=self.ccx_command.text(),abaqus_command=self.abq_command.text(),
            calculix_path="" if self.ccx_path.text()==str(bundled_calculix()) else self.ccx_path.text(),
            viewer=self.viewer.currentText(),viewer_command=self.viewer_command.text(),abaqus_python=self.abq_python.text())

    def apply_settings(self,s):
        self.loading=True
        self.solver.setCurrentIndex(self.solver.findData(s.solver))
        self.scenario.setCurrentText(s.scenario); self.directions=list(s.directions)
        if s.scenario=="Custom": self.custom_directions=list(s.directions)
        for widget,value in ((self.template,s.template),(self.output,s.output_root),(self.ccx_command,s.calculix_command),
                              (self.abq_command,s.abaqus_command),(self.viewer_command,s.viewer_command),(self.abq_python,s.abaqus_python)):
            widget.setText(value)
        self.ccx_path.setText(s.calculix_path or str(bundled_calculix()))
        for widget,value in ((self.drop_height,s.height),(self.gap,s.gap),(self.drop_time,s.drop_time),(self.release_dt,s.release_dt),
                              (self.release_max,s.release_max_dt),(self.release_time,s.release_time),(self.release_damping,s.release_damping),(self.cpus,s.cpus),
                              (self.drop_dt,s.drop_dt if s.solver=="calculix" else 0),(self.drop_max_dt,s.drop_max_dt),(self.edge_angle,s.edge_angle)):
            widget.setValue(value)
        self.viewer.setCurrentText(s.viewer if s.solver=="abaqus" else "PyVista")
        self.viewer.setEnabled(s.solver=="abaqus"); self.loading=False
        self.refresh_table()

    def save_settings(self):
        path,_=W.QFileDialog.getSaveFileName(self,"설정 저장",str(ROOT/"settings.json"),"JSON (*.json)")
        if path:
            try: self.settings().save(Path(path))
            except Exception as exc: W.QMessageBox.warning(self,"저장 실패",str(exc))

    def load_settings(self):
        path,_=W.QFileDialog.getOpenFileName(self,"설정 열기",str(ROOT),"JSON (*.json)")
        if path:
            try: self.apply_settings(Settings.read(Path(path)))
            except Exception as exc: W.QMessageBox.warning(self,"읽기 실패",str(exc))

    def restore_run(self):
        path=W.QFileDialog.getExistingDirectory(self,"이전 doe 실행 폴더",self.output.text())
        if path:
            try:
                self.engine=Engine.restore(path)
                self.apply_settings(self.engine.settings)
                self.sequence_check.setChecked(self.engine.workflow)
                self.refresh_table(); self.update_controls()
                self.log("자동화",f"실행 복구: {path}. 중단된 단계는 재실행합니다.")
            except Exception as exc: self.engine=None; W.QMessageBox.warning(self,"복구 실패",str(exc))

    def refresh_table(self):
        custom=self.scenario.currentText()=="Custom"
        self.custom_count.setVisible(True);self.custom_count_label.setVisible(True)
        blocker=QtCore.QSignalBlocker(self.custom_count); self.custom_count.setValue(len(self.directions)); del blocker
        self.table.setRowCount(len(self.directions)); self.buttons={}; self.direction_combos={}
        icons={d:direction_icon(d,self.edge_angle.value()) for d in set(self.directions)}
        for i,d in enumerate(self.directions):
            self.table.setRowHeight(i,23)
            number=W.QTableWidgetItem(f"{i+1:02d}");number.setTextAlignment(QtCore.Qt.AlignmentFlag.AlignCenter);self.table.setItem(i,0,number)
            self.table.removeCellWidget(i,1)
            item=W.QTableWidgetItem(icons[d],NAMES[d-1]);item.setToolTip(NAMES[d-1]+" · 붉은 화살표는 낙하 방향, 노란 면은 바닥입니다.\n모식도는 바닥 고정 표현이며 실제 해석은 제품의 현재 자세를 기준으로 바닥·중력 방향을 설정합니다.")
            self.table.setItem(i,1,item)
            if custom:
                combo=W.QComboBox()
                for n,name in enumerate(NAMES,1):combo.addItem(direction_icon(n,self.edge_angle.value()),name)
                combo.setIconSize(QtCore.QSize(36,22));combo.setCurrentIndex(d-1)
                combo.setSizePolicy(W.QSizePolicy.Policy.Ignored,W.QSizePolicy.Policy.Fixed)
                combo.currentIndexChanged.connect(lambda value,row=i:self.change_custom_direction(row,value+1))
                self.table.setCellWidget(i,1,combo); self.direction_combos[i]=combo
            for j,stage in enumerate(STAGES):
                button=StageButton(); button.setObjectName("stage")
                button.clicked.connect(lambda checked=False,i=i,s=stage:self.stage_clicked(i,s))
                self.table.setCellWidget(i,j+2,button); self.buttons[(i,stage)]=button
        self.update_controls()

    def update_controls(self):
        busy=self.busy(); locked=self.engine is not None
        for widget in self.controls: widget.setEnabled(not busy and not locked)
        for widget in (self.ccx_path,self.ccx_command,self.abq_command,self.abq_python,self.cpus):
            widget.setEnabled(not busy)
        self.custom_count.setEnabled(not busy and not locked and self.scenario.currentText()=='Custom')
        for combo in self.direction_combos.values(): combo.setEnabled(not busy and not locked)
        self.ccx_browse.setEnabled(not busy)
        self.drop_dt.setEnabled(not busy and not locked and self.solver.currentData()=="calculix")
        self.viewer.setEnabled(self.solver.currentData()=="abaqus")
        self.start.setEnabled(not busy and (not self.engine or self.engine.next_stage() is not None))
        self.start.setText("▶ 자동 실행")
        self.pause.setEnabled(busy); self.cancel.setEnabled(busy); self.reset.setEnabled(not busy)
        next_stage=self.engine.next_stage() if self.engine else (0,"setup")
        for key,button in self.buttons.items():
            i,stage=key
            status=self.engine.records[i][stage] if self.engine else "pending"
            percent=self.engine.fractions.get(key,0) if self.engine else 0
            elapsed=self.engine.durations.get(key) if self.engine else None
            button.set_stage(status,percent,elapsed,key==next_stage)
            button.setEnabled(status=="done" or (not busy and key==next_stage))

    def stage_clicked(self,index,stage):
        if self.engine and self.engine.records[index][stage]=="done": self.open_result(index,stage)
        else: self.launch(False)

    def launch(self,automatic):
        if self.busy(): return
        try:
            if not self.engine:
                settings=self.settings(); settings.validate()
                workflow=self.sequence_check.isChecked()
                settings.validate_runtime_scope(automatic,workflow)
                if not workflow and automatic:
                    self.preflight_solver(settings)
                self.refresh_table()
                self.engine=Engine(settings,workflow)
            else:
                self.engine.settings.validate_runtime_scope(automatic,self.engine.workflow)
                for name,value in (("calculix_command",self.ccx_command.text()),("abaqus_command",self.abq_command.text()),
                                   ("abaqus_python",self.abq_python.text()),("cpus",self.cpus.value()),
                                   ("calculix_path","" if self.ccx_path.text()==str(bundled_calculix()) else self.ccx_path.text())):
                    setattr(self.engine.settings,name,value)
                if self.engine.run: self.engine.settings.save(self.engine.run/"settings.json")
                if not self.engine.workflow and self.engine.next_stage() and self.engine.next_stage()[1]!="setup":
                    self.preflight_solver(self.engine.settings)
                    if self.engine.run: self.engine.settings.save(self.engine.run/"settings.json")
            self.worker=Worker(self.engine,automatic,self)
            self.worker.event.connect(self.on_event)
            self.worker.finished.connect(self.finished)
            self.worker.start(); self.update_controls()
        except Exception as exc:
            self.log("오류",str(exc)); W.QMessageBox.warning(self,"실행 준비 확인",str(exc)); self.update_controls()

    def preflight_solver(self,settings):
        template=settings.calculix_command if settings.solver=="calculix" else settings.abaqus_command
        args=command_args(template,job="job",input="job.inp",cpus=settings.cpus,previous_job="",solver=settings.calculix_path or str(bundled_calculix()))
        resolved=resolve_solver_command(args,settings.solver)
        if resolved[0]!=args[0]:
            self.log("자동화",f"사용할 Solver 실행 파일: {resolved[0]}")

    def on_event(self,name,data):
        if name=="log": self.log(data["channel"],data["text"])
        elif name=="progress":
            value=data['overall'];self.overall.setValue(round(value*1000));self.overall.setFormat(f"진행률 {value:.1f}%")
            key=data['index'],data['stage']
            button=self.buttons.get(key)
            if button:
                state=self.engine.records[key[0]][key[1]] if self.engine else 'running'
                elapsed=self.engine.durations.get(key) if self.engine and state=='done' else data.get('elapsed')
                button.set_stage(state,data['current'],elapsed)
            self.active.setText(f"Drop {data['index']+1:02d} · {NAMES[self.directions[data['index']]-1]} · {STAGE_LABELS[data['stage']]}")
        elif name=="telemetry":
            cpu=f"{data['cpu_percent']:04.1f}%" if data['cpu_percent'] is not None else '확인 불가'
            sim=f"{data['sim_time']:.5e}s" if data['sim_time'] is not None else '아직 미출력'
            inc=f" | 증분 {data['increment']:,}" if data['increment'] is not None else ''
            self.live.setText(f"PID {data['pid']} | 경과 {data['elapsed']:.0f}초 | CPU {cpu} (1코어=100%) | t={sim}{inc}")
        elif name=='processing':
            self.live.setText('솔버 종료 · 결과 파일 변환/검증 중')
        elif name=="status":
            self.update_controls()
            if data["status"]=="running": self.table.scrollToItem(self.table.item(data["index"],1))
        elif name=="error":
            self.statusBar().showMessage("실행 중단 · 오류 로그를 확인하세요.")
            self.tabs.setCurrentWidget(self.log_widgets["오류"])

    def finished(self):
        if self.worker: self.worker.deleteLater()
        self.worker=None; self.update_controls()
        if self.engine and self.engine.run: self.statusBar().showMessage(str(self.engine.run))
        if self.engine and self.engine.next_stage() is None:self.live.setText('전체 작업 완료 · 각 버튼에 실제 소요 시간을 표시합니다.')
        elif self.engine:
            next_stage=self.engine.next_stage()
            statuses=[status for row in self.engine.records for status in row.values()]
            if 'failed' in statuses:self.live.setText('실행 종료 · 오류 로그를 확인하세요.')
            elif 'interrupted' in statuses:self.live.setText('중지 완료 · 중단한 단계부터 재시도할 수 있습니다.')
            else:self.live.setText('대기 · 다음 활성 단계 또는 자동 실행을 선택하세요.')

    def pause_run(self):
        if self.engine:
            self.engine.stop_after.set(); self.log("자동화","일시정지 예약: 현재 단계 완료 후 대기합니다.")

    def cancel_run(self):
        dialog=W.QMessageBox(self); dialog.setWindowTitle("전체 취소")
        dialog.setText("중지 방식을 선택하세요. 기존 결과는 보존합니다.")
        after=dialog.addButton("현재 단계 후 종료",W.QMessageBox.ButtonRole.AcceptRole)
        now=dialog.addButton("즉시 종료",W.QMessageBox.ButtonRole.DestructiveRole)
        dialog.addButton("돌아가기",W.QMessageBox.ButtonRole.RejectRole); dialog.exec()
        if dialog.clickedButton()==after: self.pause_run()
        elif dialog.clickedButton()==now:
            self.engine.cancel_now.set(); self.engine.stop_after.set(); self.log("자동화","즉시 종료 요청")

    def reset_run(self):
        if self.busy(): return
        self.engine=None
        self.overall.setValue(0);self.overall.setFormat('진행률 0.0%')
        self.active.setText("초기화 완료 · 기존 결과 보존 / 다음 실행은 새 회차")
        self.live.clear()
        self.refresh_table(); self.statusBar().showMessage("새 실행 준비")

    def open_result(self,index,stage):
        folder=stage_folder(self.engine.run,index,"drop" if stage=="setup" else stage)
        try:
            if stage!="setup" and not self.engine.workflow and self.engine.settings.solver=="abaqus" and self.viewer.currentText()=="Abaqus Viewer":
                args=command_args(self.viewer_command.text(),odb=str(folder/"job.odb"))
            else:
                args=[sys.executable,"-m","system_drop.viewer",str(folder)]
                if stage=="setup": args.append("--setup")
                if self.engine.workflow: args.append("--workflow")
            logfile=(folder/"viewer.log").open("ab")
            process=popen(args,ROOT,logfile)
            self.viewers.append((process,logfile,folder))
            self.log("자동화",f"결과 창 열기: Drop {index+1:02d} / {STAGE_LABELS[stage]} — 해석은 계속 진행합니다.")
        except Exception as exc: self.log("오류",f"결과 창 실행 실패: {exc}")

    def poll_viewers(self):
        remaining=[]
        for process,file,folder in self.viewers:
            if process.poll() is None: remaining.append((process,file,folder))
            else:
                file.close()
                if process.returncode: self.log("오류",f"Viewer 종료 코드 {process.returncode}: {folder/'viewer.log'}")
        self.viewers=remaining

    def closeEvent(self,event):
        if self.busy():
            W.QMessageBox.information(self,"해석 실행 중","일시정지 또는 전체 취소 후 프로그램을 닫으세요.")
            event.ignore(); return
        try:
            if self.preferences_path: self.settings().save(self.preferences_path)
        except OSError as exc: self.log("오류",f"사용자 설정 저장 실패: {exc}")
        event.accept()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--screenshot",type=Path)
    args=parser.parse_args()
    app=W.QApplication(sys.argv)
    app.setStyle("Fusion"); app.setStyleSheet(STYLE)
    app.setFont(QtGui.QFont("Malgun Gothic" if sys.platform=="win32" else "Noto Sans CJK KR",9))
    window=Window(); window.show()
    if args.screenshot:
        def capture():
            window.grab().save(str(args.screenshot)); app.quit()
        QtCore.QTimer.singleShot(300,capture)
    return app.exec()


if __name__=="__main__":
    raise SystemExit(main())
