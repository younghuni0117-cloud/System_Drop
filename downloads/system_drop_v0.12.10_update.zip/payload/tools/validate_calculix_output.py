"""Compare real CCX output strides without changing the integration settings."""
from pathlib import Path
import argparse,json,os,sys,time,subprocess
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.calculix_files import result_path
from system_drop.split_input import execution_input
from system_drop.model import ROOT,Settings
from system_drop.engine import Engine
from system_drop.solver import setup_drop
from system_drop.results import convert_frd,read_state,validate_physical_state
from system_drop.restart import NativeRestart
from system_drop.deck import read_mesh

parser=argparse.ArgumentParser()
parser.add_argument('--ccx',required=True)
parser.add_argument('--output',type=Path,default=ROOT/'artifacts/output0128')
args=parser.parse_args()
root=args.output;root.mkdir(parents=True,exist_ok=True)
ccx=str(Path(args.ccx).resolve())
env=dict(os.environ,OMP_NUM_THREADS='1',CCX_NPROC_RESULTS='1',CCX_NPROC_STIFFNESS='1')
reports=[];native=[]
for mode,frequency in [('every_increment',1),('automatic',0)]:
    settings=Settings(directions=[1],output_root=str(root/mode),drop_time=.000006,drop_max_dt=.000001,ccx_output_frequency=frequency)
    engine=Engine(settings);engine.initialize();folder=setup_drop(settings,engine.run,0,engine.log)
    start=time.monotonic()
    with (folder/'solver.log').open('w') as log:
        result=subprocess.run([ccx,'-i',execution_input(folder,'calculix').stem],cwd=folder,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=180)
    assert result.returncode==0 and '*ERROR' not in (folder/'solver.log').read_text()
    state=NativeRestart.read(result_path(folder,'rout'));native.append(state)
    mesh=read_mesh(folder/'calculix_mesh.inp');plan=json.loads((folder/'output_plan.json').read_text())
    converted=time.monotonic()
    convert_frd(result_path(folder,'frd'),mesh,folder/'results',output_schedule={k:plan[k] for k in ('period','interval','allow_sparse')}|{'max_frames':plan['max_saved_frames'],'offset':0.,'end_time':float(state.doubles('ttime')[0])})
    conversion_seconds=time.monotonic()-converted
    validate_physical_state(read_state(folder/'results/state.json'),mesh)
    reports.append({'mode':mode,'frequency':plan['frequency'],'folder':str(folder),'frd_bytes':(result_path(folder,'frd')).stat().st_size,'dat_bytes':(result_path(folder,'dat')).stat().st_size,'frames':len(json.loads((folder/'results/frames.json').read_text())),'conversion_seconds':conversion_seconds,'solver_seconds':converted-start})
checks={}
for key in ('co','vold','veold','sti','xstate','ttime'):
    a=native[0].doubles(key);b=native[1].doubles(key)
    np.testing.assert_allclose(a,b,rtol=0,atol=0)
    checks[key]={'identical':True,'values':a.size}
before=sum(reports[0][k] for k in ('frd_bytes','dat_bytes'));after=sum(reports[1][k] for k in ('frd_bytes','dat_bytes'))
report={'success':True,'solver':'CalculiX 2.23','platform':sys.platform,'cases':reports,'native_records':checks,'raw_bytes_reduction_percent':100*(1-after/before),'scope':'Short actual Top Face impact; output-only change; no full-duration/Windows performance claim.'}
(root/'summary.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
