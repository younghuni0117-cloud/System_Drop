from system_drop.deck import expanded_lines
from dataclasses import replace
import json
import numpy as np
import pytest
from system_drop.model import Settings,ROOT
from system_drop.calculix_output import output_plan,configure_calculix_output
from system_drop.output_schedule import select_frame_indices
from system_drop.solver import setup_drop
from system_drop.engine import Engine


def test_auto_recording_reduces_long_run_volume_without_changing_integration():
    s=Settings(drop_time=.02,drop_max_dt=.000001)
    plan=output_plan(s,'drop')
    assert plan['frequency']==200
    assert plan['max_saved_frames']==1000
    assert plan['target_frames']==1000
    deck='*DYNAMIC, EXPLICIT=2\n0.0000001, 0.02, 0.000000000001, 0.000001\n*NODE FILE, FREQUENCY=1, FREQUENCYF=1\nU,V\n*EL FILE,FREQUENCY=1\nS,PEEQ\n*EL PRINT,ELSET=PRODUCT_ELEMENTS,FREQUENCY=1\nS\n*NODE PRINT,NSET=FRAME_ORIGIN,FREQUENCY=1\nU,V\n*RESTART, WRITE, FREQUENCY=1\n'
    out=configure_calculix_output(deck,s,'drop')
    assert '0.0000001, 0.02, 0.000000000001, 0.000001' in out
    assert out.count('FREQUENCY=200')==4 and 'FREQUENCYF=' not in out
    assert '*RESTART, WRITE, FREQUENCY=1' in out
    assert configure_calculix_output(out,s,'drop')==out
    assert output_plan(replace(s,ccx_output_frequency=100),'drop')['frequency']==100
    assert output_plan(replace(s,ccx_output_frequency=1),'drop')['frequency']==1


def test_sparse_output_keeps_real_frames_and_final_state_without_duplicates():
    times=[.000003,.000006]
    indices,targets=select_frame_indices(times,.000006,.000001,allow_sparse=True,max_frames=1000)
    assert indices==[0,1] and len(targets)==2
    indices,_=select_frame_indices(np.linspace(.00000001,.02,10000),.02,.000001,allow_sparse=True,max_frames=1000)
    assert len(indices)==len(set(indices))==1000 and indices[-1]==9999
    with pytest.raises(ValueError):select_frame_indices(times,.000006,.000001)
    with pytest.raises(ValueError):select_frame_indices(times,.000007,.000001,allow_sparse=True)


def test_all_record_requests_receive_same_stride_in_new_drop(tmp_path):
    s=Settings(output_root=str(tmp_path),directions=[1],ccx_output_frequency=50)
    e=Engine(s);e.initialize();folder=setup_drop(s,e.run,0,e.log)
    text='\n'.join(expanded_lines(folder/'calculix_main.inp'));plan=json.loads((folder/'output_plan.json').read_text())
    assert plan['frequency']==50
    assert text.count('FREQUENCY=50')==4
    assert '*RESTART, WRITE, FREQUENCY=1' in text
    assert 'S, PEEQ' in text and '*EL PRINT, GLOBAL=YES' in text


def test_old_settings_files_get_safe_output_defaults(tmp_path):
    path=tmp_path/'settings.json';path.write_text(json.dumps({'cpus':4}))
    settings=Settings.read(path)
    assert settings.ccx_output_frequency==0 and settings.ccx_max_frames==1000
    settings.validate()
    with pytest.raises(ValueError):replace(settings,ccx_max_frames=0).validate()
