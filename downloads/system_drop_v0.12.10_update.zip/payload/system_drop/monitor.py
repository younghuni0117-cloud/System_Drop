"""Read actual process CPU time and solver files using only the standard library."""
from .calculix_files import result_path
from pathlib import Path
import math
import os
import re
import time

NUMBER=r"[-+]?(?:\d+\.?\d*|\.\d+)(?:[EeDd][-+]?\d+)?"


def cpu_seconds(pid):
    try:
        if os.name=="nt":
            import ctypes
            from ctypes import wintypes
            kernel=ctypes.WinDLL("kernel32",use_last_error=True)
            kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
            kernel.OpenProcess.restype=wintypes.HANDLE
            kernel.GetProcessTimes.argtypes=[wintypes.HANDLE,*([ctypes.POINTER(wintypes.FILETIME)]*4)]
            kernel.GetProcessTimes.restype=wintypes.BOOL
            kernel.CloseHandle.argtypes=[wintypes.HANDLE]
            handle=kernel.OpenProcess(0x1000,False,pid)
            if not handle:return None
            stamps=[wintypes.FILETIME() for _ in range(4)]
            try:
                if not kernel.GetProcessTimes(handle,*(ctypes.byref(x) for x in stamps)):return None
                return sum((x.dwHighDateTime<<32)+x.dwLowDateTime for x in stamps[2:])*1e-7
            finally:kernel.CloseHandle(handle)
        fields=Path(f"/proc/{pid}/stat").read_text().rsplit(")",1)[1].split()
        return (int(fields[11])+int(fields[12]))/os.sysconf("SC_CLK_TCK")
    except (OSError,ValueError,IndexError,AttributeError):return None


def tail_text(path,limit=131072):
    try:
        with Path(path).open('rb') as stream:
            stream.seek(max(0,Path(path).stat().st_size-limit))
            return stream.read().decode(errors='replace')
    except OSError:return ''


def dat_time(text):
    # FRD/STA may be empty in Explicit. NODE PRINT gives actual time in .dat.
    found=re.findall(r"\band\s+time\s+("+NUMBER+r")",text,re.I)
    return float(found[-1].replace('D','E').replace('d','e')) if found else None


def stable_increment(text):
    found=re.findall(r"(?:stable\s+time\s+increment\s*:|SELECTED\s+time\s+increment[^:\n]*:)\s*("+NUMBER+r")",text,re.I)
    return float(found[-1]) if found else None


def dat_increment(text):
    found=re.findall(r"\bINCREMENT\s+(\d+)",text,re.I)
    return int(found[-1]) if found else None


class SolverMonitor:
    def __init__(self,pid,folder,solver='calculix'):
        self.pid=pid;self.folder=Path(folder);self.started=time.monotonic()
        self.solver=solver
        self.previous_wall=self.started;self.previous_cpu=cpu_seconds(pid)
        self.last_sim=None;self.last_advance=self.started
        self.last_signature=None;self.last_write=self.started
        self.rate_anchor=None

    def sample(self,duration,offset=0):
        now=time.monotonic();cpu=cpu_seconds(self.pid)
        percent=None
        if cpu is not None and self.previous_cpu is not None and now-self.previous_wall>=.05:
            percent=max(0.,100*(cpu-self.previous_cpu)/(now-self.previous_wall))
        self.previous_cpu=cpu;self.previous_wall=now
        text=tail_text(self.folder/'solver.log')
        dat=tail_text(result_path(self.folder,'dat'))
        sim=dat_time(dat);increment=dat_increment(dat)
        candidates=[(sim,increment)] if sim is not None else []
        for line in reversed(tail_text(result_path(self.folder,'frd')).splitlines()):
            if line.startswith('  100C'):
                try:candidates.append((float(line[12:24]),None));break
                except ValueError:pass
        if self.solver=='calculix':
            for line in tail_text(result_path(self.folder,'sta')).splitlines():
                cols=line.split()
                if len(cols)>=7 and all(x.isdigit() for x in cols[:4]):
                    try:candidates.append((float(cols[4]),int(cols[1])))
                    except ValueError:pass
        sim,increment=max(candidates,key=lambda x:(x[0],x[1] is not None)) if candidates else (None,None)
        step=max(0,sim-offset) if sim is not None else None
        signature=[]
        for name in ('solver.log',*(result_path(self.folder,e).name for e in ('dat','frd','sta','cvg'))):
            try:
                stat=(self.folder/name).stat();signature.append((name,stat.st_size,stat.st_mtime_ns))
            except OSError:pass
        if signature!=self.last_signature:self.last_signature=signature;self.last_write=now
        advanced=step is not None and (self.last_sim is None or step>self.last_sim)
        if advanced:
            self.last_sim=step;self.last_advance=now
            if self.rate_anchor is None:self.rate_anchor=(now,step)
        dt=stable_increment(text)
        eta=None
        if self.rate_anchor and self.last_sim is not None:
            wall=self.last_advance-self.rate_anchor[0];delta=self.last_sim-self.rate_anchor[1]
            if wall>=5 and delta>0:eta=max(0,duration-self.last_sim)*wall/delta
        if advanced:state='해석 시간 진행 확인'
        elif percent is not None and percent>=1:state='CPU 활동 중 · 다음 해석 시간 출력 대기'
        elif now-self.last_advance>=30:state='진행 근거 없음 · 대기/정체 여부 확인 필요'
        else:state='초기화 또는 출력 대기'
        if self.solver!='calculix':state='호출 프로세스 관찰 · 하위 솔버는 .sta 확인'
        return {'pid':self.pid,'elapsed':now-self.started,'cpu_percent':percent,'cpu_seconds':cpu,
                'sim_time':self.last_sim,'dt':dt,'estimated_increments':math.ceil(duration/dt) if dt and dt>0 else None,
                'increment':increment,'mean_dt':self.last_sim/increment if self.last_sim is not None and increment else None,
                'output_age':now-self.last_write,'state':state,'eta_seconds':eta,
                'percent':min(99.9,100*self.last_sim/duration) if self.last_sim is not None else None}


def observation_line(data,duration):
    """Fixed-width numeric columns; process activity is not solver progress."""
    cpu=f"{data['cpu_percent']:04.1f}%" if data['cpu_percent'] is not None else '--.-%'
    from .output_schedule import decimal_text
    sim=decimal_text(data['sim_time']) if data['sim_time'] is not None else '-----------'
    return (f"PID {data['pid']:7d} | 경과 {data['elapsed']:6.0f}초 | "
            f"CPU {cpu:>6} (1코어=100%) | 해석 시간 {sim:>18} / {decimal_text(duration):>18} s")
