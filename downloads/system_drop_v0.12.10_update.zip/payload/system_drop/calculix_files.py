"""CalculiX basename: new main decks and unchanged historical job-based runs."""
from pathlib import Path


def basename(folder):
    folder=Path(folder)
    if (folder/'job.inp').exists():return 'job'
    if any((folder/('calculix_main.'+ext)).exists() for ext in ('inp','rin','rout')):return 'calculix_main'
    return 'job'


def result_path(folder,extension):
    return Path(folder)/(basename(folder)+'.'+extension.lstrip('.'))


def command_for_input(args,path):
    """Manager owns the input basename even in an old hard-coded command."""
    args=list(args);stem=Path(path).stem
    if '-i' in args:
        i=args.index('-i')
        if i+1==len(args):args.append(stem)
        else:args[i+1]=stem
    else:
        position=next((i for i,a in enumerate(args[1:],1) if a in ('job','job.inp','calculix_main','calculix_main.inp')),None)
        if position is not None:args[position]=stem
        else:args.extend(['-i',stem])
    return args
