from __future__ import annotations
from .calculix_files import result_path

from pathlib import Path
import json
import os
import re
import shlex
import shutil
import subprocess
import numpy as np

from .deck import block, read_mesh, id_lines, contact_allowances
from .model import ROOT, Settings, NAMES, frame, drop_direction, impact_velocity, floor_geometry,bundled_calculix
from .results import grid_from_mesh, read_state
from .inp_format import format_inp
from .output_schedule import decimal_text,configure_output
from .calculix_output import configure_calculix_output
from .split_input import publish_abaqus_input,execution_input,product_sets,publish_calculix_input


def resolve_solver_command(args,solver):
    executable=os.path.expandvars(os.path.expanduser(args[0]))
    path=Path(executable)
    found=str(bundled_calculix()) if solver=="calculix" and executable in ("ccx","ccx.exe","ccx_MT.exe") and bundled_calculix().is_file() else (
        str(path.resolve()) if path.is_file() else shutil.which(executable))
    if not found and not path.is_absolute() and len(path.parts)>1 and (ROOT/path).is_file():
        found=str((ROOT/path).resolve())
    if not found:
        label="CalculiX" if solver=="calculix" else "Abaqus"
        raise FileNotFoundError(
            f"{label} 실행 파일을 찾을 수 없습니다: {args[0]}\n"
            "입력 파일 오류가 아니라 Solver 경로 설정 문제입니다.\n"
            "패키지의 solvers/calculix/bin/ccx_MT.exe와 DLL을 함께 압축 해제했는지 확인하세요.\n"
            "상세 옵션의 CalculiX 솔버 경로에서 실행 파일을 지정할 수 있습니다."
            if solver=="calculix" else f"{label} 실행 파일을 찾을 수 없습니다: {args[0]}\n상세 옵션에서 실행 명령을 설정하세요.")
    return [str(found),*args[1:]]


def command_args(template: str, **values):
    """Expand argument tokens, never interpolate into a shell command.

    On Windows .bat/.cmd launchers are explicitly invoked through cmd.exe with
    list2cmdline quoting. Commands with shell operators are intentionally unsupported.
    """
    values.setdefault("solver",str(bundled_calculix()))
    tokens = shlex.split(template, posix=False if os.name == "nt" else True)
    result = []
    for token in tokens:
        token = token.strip('"') if os.name=="nt" else token
        if token == "{oldjob}":
            if values.get("previous_job"):
                result.append("oldjob="+str(values["previous_job"]))
            continue
        expanded = token.format(**values)
        if expanded:
            result.append(expanded)
    if not result:
        raise ValueError("실행 명령이 비어 있습니다.")
    return result


def popen(args, cwd, stdout, env=None):
    actual = args
    if os.name == "nt":
        executable = shutil.which(args[0]) or args[0]
        if Path(executable).suffix.lower() in (".bat", ".cmd"):
            actual = [os.environ.get("COMSPEC","cmd.exe"), "/d", "/s", "/c",
                      subprocess.list2cmdline([executable,*args[1:]])]
    kwargs = {"creationflags":subprocess.CREATE_NEW_PROCESS_GROUP} if os.name=="nt" else {"start_new_session":True}
    try:
        return subprocess.Popen(actual,cwd=cwd,stdout=stdout,stderr=subprocess.STDOUT,env=env,**kwargs)
    except OSError as exc:
        if getattr(exc,"winerror",None)==193:
            raise RuntimeError("실행 파일 형식 또는 CPU 아키텍처가 맞지 않습니다. Windows용 64비트 Solver 실행 파일을 선택하세요.") from exc
        if getattr(exc,"winerror",None)==126:
            raise RuntimeError("Solver 실행에 필요한 DLL이 없습니다. Solver 배포 폴더의 DLL을 함께 유지하세요.") from exc
        raise


def stage_folder(run, index, stage):
    return Path(run)/f"{stage}_{index+1:02d}"


def snapshot_template(settings, run):
    source = Path(settings.template).resolve()
    dest = Path(run)/"template_snapshot"
    if dest.exists():
        return dest
    # Freeze nested and external INCLUDE dependencies into a self-contained copy.
    shutil.copytree(source,dest)
    from .deck import include_path,logical_lines,keyword
    import hashlib
    copied={};active=set()
    def freeze(path):
        path=path.resolve()
        if path in active:raise ValueError('순환 INCLUDE: '+str(path))
        if path in copied:return copied[path]
        target=dest/path.relative_to(source) if path.is_relative_to(source) else dest/'__included__'/(hashlib.sha256(str(path).encode()).hexdigest()[:12]+'_'+path.name)
        active.add(path);target.parent.mkdir(parents=True,exist_ok=True);out=[]
        for line in logical_lines(path.read_text(encoding='utf-8-sig').splitlines()):
            if line.strip().upper().startswith('*INCLUDE,'):
                dependency=freeze(include_path(path.parent,str(keyword(line)[1]['INPUT'])))
                relative=os.path.relpath(dependency,target.parent).replace('\\','/')
                out.append('*INCLUDE, INPUT="'+relative+'"')
            else:out.append(line)
        target.write_text('\n'.join(out)+'\n',encoding='utf-8');active.remove(path);copied[path]=target;return target
    for part in ('main','material','mesh'):freeze(source/f'{settings.solver}_{part}.inp')
    if settings.solver=='abaqus':
        from .template_adapter import adapt_abaqus
        report=adapt_abaqus(dest)
        (dest/'template_adaptation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    return dest


def setup_drop(settings: Settings, run, index, log, workflow=False):
    template = snapshot_template(settings,run)
    main = template/f"{settings.solver}_main.inp"
    mesh = read_mesh(template/f"{settings.solver}_mesh.inp")
    folder = stage_folder(run,index,"drop")
    folder.mkdir(exist_ok=True)
    for source in template.iterdir():
        if source.is_dir(): shutil.copytree(source,folder/source.name,dirs_exist_ok=True)
        else: shutil.copy2(source,folder/source.name)
    coords = mesh.product_nodes
    native = None
    if index:
        prior = stage_folder(run,index-1,"release")/"results"/"state.json"
        if not prior.exists(): raise ValueError("이전 릴리즈 상태가 없습니다.")
        coords = read_state(prior)["coordinates"]
        if settings.solver == 'calculix' and not workflow:
            from .restart import NativeRestart
            source = result_path(stage_folder(run,index-1,'release'),'rout')
            native = NativeRestart.read(source)
            coords = native.physical_coordinates(mesh.product_nodes)
            log('자동화','이전 안정화 native restart의 정밀 변형 좌표 사용; 소성/응력 이력 유지')
    log("자동화", "현재 형상에서 FRAME_ORIGIN / FRAME_X / FRAME_Y 읽기")
    rotation = frame(*mesh.reference_points(coords))
    local = np.array(list(coords.values())) @ rotation
    width,depth = float(np.ptp(local[:,0])),float(np.ptp(local[:,2]))
    direction = drop_direction(settings.directions[index],rotation,width,depth,settings.edge_angle)
    velocity = impact_velocity(settings.height,settings.gap,direction)
    if native is not None:
        # Actual expanded shell surface includes plastic thickness/warping;
        # do not add the original shell thickness a second time.
        surface_coords=native.physical_coordinates(native.product_labels(mesh))
        surface=floor_geometry(list(surface_coords.values()),direction,settings.gap)
    else:
        allowances=contact_allowances(mesh,coords,main,direction)
        surface = floor_geometry(list(coords.values()),direction,settings.gap,allowances)
    log("자동화", f"바닥 배치: 초기 간격 {settings.gap:g} mm, 낙하 벡터 {direction.round(6).tolist()}")
    log("자동화", f"초기속도 XYZ {velocity.round(4).tolist()} mm/s; 중력 XYZ {(9810*direction).round(4).tolist()}")
    from .floor import floor_text
    base=max(max(mesh.nodes),max(mesh.elements))+100
    text = main.read_text(encoding="utf-8-sig")
    description=f'System Drop | {NAMES[settings.directions[index]-1]} | height {settings.height:g} mm | gap {settings.gap:g} mm | period {decimal_text(settings.drop_time)} s'
    text=re.sub(r'(?mi)^(\*HEADING[^\n]*\n)System Drop[^\n]*',lambda m:m[1]+description,text,count=1)
    text=re.sub(r'(?mi)^\*\* SYSTEM_DROP_DEFAULT_GAP=.*$',f'** SYSTEM_DROP_DEFAULT_GAP={settings.gap:.12g}',text)
    text = block(text,"FLOOR",floor_text(settings.solver,surface,base))
    # Create reserved complete-product sets from actual mesh, including newly added elsets.
    allsets = ("*NSET, NSET=AUTO_PRODUCT_NODES\n"+id_lines(mesh.product_nodes)+
               "\n*ELSET, ELSET=AUTO_PRODUCT_ELEMENTS\n"+id_lines(mesh.product_elements)+"\n")
    if settings.solver=='abaqus':
        mesh_file=folder/'abaqus_mesh.inp'
        mesh_file.write_text(format_inp(product_sets(mesh_file.read_text(encoding='utf-8-sig'),mesh)),encoding='utf-8')
        allsets=''
    node_set='PRODUCT_NODES' if settings.solver=='abaqus' else 'AUTO_PRODUCT_NODES'
    element_set='PRODUCT_ELEMENTS' if settings.solver=='abaqus' else 'AUTO_PRODUCT_ELEMENTS'
    shell_nodes=sorted({n for kind,c in mesh.product_elements.values() if kind in ('S3','S4','S4R','S8R') for n in c})
    if settings.solver=='abaqus' and shell_nodes:
        allsets+='*NSET, NSET=AUTO_SHELL_NODES\n'+id_lines(shell_nodes)+'\n'
    vel = "*INITIAL CONDITIONS, TYPE=VELOCITY\n"+"\n".join(f"{node_set}, {i+1}, {v:.12g}" for i,v in enumerate(velocity))
    if settings.solver=='abaqus' and shell_nodes:vel+='\n'+ '\n'.join(f'AUTO_SHELL_NODES, {i}, 0.' for i in (4,5,6))
    text = block(text,"VELOCITY",allsets+vel)
    # Preserve contact, section and tie definitions byte-for-byte; replace only the managed step.
    original_step = re.search(r"(?ms)^\*\* AUTO:BEGIN DROP_STEP\s*\n(.*?)^\*\* AUTO:END DROP_STEP",text)
    if not original_step: raise ValueError("DROP_STEP 블록이 없습니다.")
    step = original_step.group(1)
    from .template_adapter import set_dynamic_times
    step=set_dynamic_times(step,drop_time_line(settings),solver=settings.solver)
    if settings.solver=='abaqus' and not re.search(r'(?mi)^\*RESTART[^\n]*\bWRITE\b',step):
        step=re.sub(r'(?mi)^\*END STEP', '*RESTART, WRITE, NUMBER INTERVAL=1\n*END STEP',step,count=1)
    step,count = re.subn(r"(?mi)^\s*PRODUCT_ELEMENTS\s*,\s*GRAV[^\n]*",
        element_set+", GRAV, 9810., "+", ".join(f"{x:.12g}" for x in direction),step)
    if count != 1: raise ValueError("템플릿에 PRODUCT_ELEMENTS GRAV 행 한 개가 필요합니다.")
    # Cheap actual-time observations without waiting for a complete FRD frame.
    if settings.solver=='calculix':step=observation_output(step)
    step=(configure_calculix_output(step,settings,'drop',folder,log) if settings.solver=='calculix' else
          configure_output(step,settings.solver,settings.drop_time,settings.drop_max_dt))
    text=block(text,"DROP_STEP",step)
    if settings.solver=='calculix':publish_calculix_input(folder,text)
    else:(folder/"job.inp").write_text(format_inp(text),encoding="utf-8")
    preview = folder/"preview"
    preview.mkdir(exist_ok=True)
    grid_from_mesh(mesh,coords).save(preview/"product.vtu")
    import pyvista as pv
    pv.PolyData(surface,faces=[4,0,1,2,3]).save(preview/"floor.vtp")
    metadata = {"solver":settings.solver,"center":((np.min(np.array(list(coords.values())),axis=0)+np.max(np.array(list(coords.values())),axis=0))*.5).tolist(),"direction":direction.tolist(),"velocity":velocity.tolist(),"gravity":(9810*direction).tolist(),
                "rotation":rotation.tolist(),"origin":mesh.reference_points(coords)[0].tolist(),
                "floor":surface.tolist(),"floor_base":base,"gap":settings.gap,"height":settings.height,"workflow_only":workflow}
    (folder/"setup.json").write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    if index and not workflow:
        prepare_bridge(settings,run,index,"drop",folder,log)
    if settings.solver=='abaqus':
        if (folder/'job.inp').exists():publish_abaqus_input(folder)
        from .input_settings import verify_abaqus_settings
        verify_abaqus_settings(folder,settings)
        log('자동화',f'실제 실행 입력: {execution_input(folder,settings.solver)}; 종료 {decimal_text(settings.drop_time)} s / 최대 증분 {decimal_text(settings.drop_max_dt)} s. Field·History 및 input_settings.json 확인.')
    if settings.solver=='calculix':
        publish_calculix_input(folder)
        from .input_settings import verify_calculix_settings
        verify_calculix_settings(folder,settings)
        log('자동화',f'실제 입력: calculix_main.inp; 종료 {decimal_text(settings.drop_time)} s / 최대 증분 {decimal_text(settings.drop_max_dt)} s; input_settings.json 검증 완료')
    log("자동화","입력·방향 미리보기 생성 완료. 재료 / section / tie / 접촉 정의 유지.")
    return folder


def observation_output(text):
    if '*NODE PRINT' in text.upper():return text
    explicit=bool(re.search(r'(?mi)^\*DYNAMIC[^\n]*\bEXPLICIT',text))
    point=re.search(r'(?mi)^\*(?:NODE FILE|EL FILE)[^\n]*\bTIME POINTS\s*=\s*(\w+)',text)
    if point:
        diagnostic=f"*NODE PRINT, NSET=FRAME_ORIGIN, TIME POINTS={point[1]}\nU, V\n"
        return re.sub(r"(?mi)^\*END STEP",lambda m:diagnostic+m.group(),text,count=1)
    match=re.search(r'(?mi)^\*(?:NODE FILE|EL FILE)[^\n]*\bFREQUENCY\s*=\s*(\d+)',text)
    frequency=min(int(match[1]),500) if match else (500 if explicit else 1)
    diagnostic=f"** Runtime observation: structural output frequency is shared across requests.\n*NODE PRINT, NSET=FRAME_ORIGIN, FREQUENCY={frequency}\nU, V\n"
    return re.sub(r"(?mi)^\*END STEP",lambda m:diagnostic+m.group(),text,count=1)


def drop_time_line(settings):
    maximum=decimal_text(settings.drop_max_dt) if settings.drop_max_dt else ""
    if settings.solver=="abaqus":return f", {decimal_text(settings.drop_time)}, , {maximum}"
    return f"{decimal_text(settings.drop_dt)}, {decimal_text(settings.drop_time)}, 0.000000000001, {maximum}"


def prepare_release(settings,run,index,log):
    folder=stage_folder(run,index,"release")
    folder.mkdir(exist_ok=True)
    drop=stage_folder(run,index,"drop")
    if settings.solver=="calculix":
        restart=result_path(drop,'rout')
        if not restart.exists(): raise ValueError(f"CalculiX native restart가 없습니다: {restart}")
        from .stabilization import prepare_native_release
        mesh=read_mesh(Path(run)/'template_snapshot/calculix_main.inp')
        report=prepare_native_release(restart,result_path(folder,'rin'),mesh,settings.release_damping)
        report['damping_alpha_s_inverse']=settings.release_damping
        (folder/'stabilization_transfer.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        log('자동화',f'강체 속도 제거: 병진 {np.round(report["removed_translation_mm_s"],6).tolist()} mm/s, 회전 {np.round(report["removed_angular_rad_s"],6).tolist()} rad/s; 운동에너지 {report["kinetic_before_Nmm"]:.6g} → {report["kinetic_after_Nmm"]:.6g} N mm')
        text=f"""** Native restart: stress/plastic history retained; rigid velocity removed.
*RESTART, READ
*STEP, NLGEOM, INC=1000000
*DYNAMIC, ALPHA=-0.3
{decimal_text(settings.release_dt)}, {decimal_text(settings.release_time)}, 0.0000000001, {decimal_text(settings.release_max_dt)}
** Free-body stabilization: 1 N reference, 0.005 N residual tolerance.
** Same force tolerance for near-zero-force and ordinary field branches.
*CONTROLS, PARAMETERS=FIELD
0.005, 0.01, , 1., 0.02, 0.005, 0.001, 1.e-8
*MODEL CHANGE, TYPE=CONTACT PAIR, REMOVE
PRODUCT_CONTACT, FLOOR_SURFACE
*DLOAD, OP=NEW
AUTO_PRODUCT_ELEMENTS, GRAV, 0., 0., 1., 0.
*RESTART, WRITE, FREQUENCY=1
*NODE FILE, OUTPUT=2D, FREQUENCY=1
U, V
*EL FILE, OUTPUT=2D, FREQUENCY=1
S, PEEQ
*EL PRINT, GLOBAL=YES, ELSET=AUTO_PRODUCT_ELEMENTS, FREQUENCY=1
S
*END STEP
"""
        text=configure_calculix_output(text,settings,'release',folder,log)
        publish_calculix_input(folder,text)
        from .input_settings import verify_calculix_settings
        verify_calculix_settings(folder,settings,'release')
        log("자동화","CalculiX native restart 릴리즈 생성: 중력 0, 바닥 접촉 제거, 강체 속도 제거, 질량비례 감쇠 + HHT 수치 감쇠")
    else:
        prepare_bridge(settings,run,index,"release",folder,log)
    return folder


def prepare_bridge(settings,run,index,stage,folder,log):
    """Native Abaqus import preserves history; no stress-only reconstruction."""
    if settings.solver=="calculix":
        if stage != 'drop' or index < 1:
            raise ValueError('CalculiX next-drop bridge requires a previous stabilization.')
        from .restart import prepare_next_impact
        metadata=json.loads((folder/'setup.json').read_text(encoding='utf-8'))
        previous=result_path(stage_folder(run,index-1,'release'),'rout')
        mesh=read_mesh(Path(run)/'template_snapshot/calculix_mesh.inp')
        audit=prepare_next_impact(previous,result_path(folder,'rin'),mesh,metadata['floor'],metadata['velocity'])
        (folder/'transfer.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
        from .restart import NativeRestart
        first=result_path(stage_folder(run,0,'drop'),'rout')
        if first.exists():baseline=NativeRestart.read(first).doubles('xmodal')[:2]
        else:
            baseline=[0.,0.]
            from .deck import expanded_lines,keyword
            for line in expanded_lines(Path(run)/'template_snapshot/calculix_main.inp'):
                if line.upper().startswith('*DAMPING,'):
                    _,params=keyword(line);baseline=[float(params.get('ALPHA',0)),float(params.get('BETA',0))]
        incoming=NativeRestart.read(result_path(folder,'rin'));damping=incoming.doubles('xmodal').copy()
        if not np.array_equal(damping[:2],baseline):
            damping[:2]=baseline;incoming.replace('xmodal',damping);incoming.write(result_path(folder,'rin'))
            audit['changed_records'].append('xmodal');audit['restored_drop_damping']=list(map(float,baseline))
            (folder/'transfer.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
        frequency=500 if any(kind=='S4' for kind,_ in mesh.product_elements.values()) else 5
        text=f'''** Cumulative impact: native state retained; only floor and launch velocity updated.
*RESTART, READ
*STEP, NLGEOM, INC=100000000
*DYNAMIC, EXPLICIT=2
{drop_time_line(settings)}
*MODEL CHANGE, TYPE=CONTACT PAIR, ADD
PRODUCT_CONTACT, FLOOR_SURFACE
*DLOAD, OP=NEW
AUTO_PRODUCT_ELEMENTS, GRAV, 9810., {', '.join(f'{v:.12g}' for v in metadata['direction'])}
*RESTART, WRITE, FREQUENCY=1
*NODE FILE, OUTPUT=2D, FREQUENCY={frequency}
U, V
*EL FILE, OUTPUT=2D, FREQUENCY={frequency}
S, PEEQ, ENER
*EL PRINT, GLOBAL=YES, ELSET=AUTO_PRODUCT_ELEMENTS, FREQUENCY={frequency}
S
*END STEP
'''
        text=observation_output(text)
        text=configure_calculix_output(text,settings,'drop',folder,log)
        publish_calculix_input(folder,text)
        from .input_settings import verify_calculix_settings
        verify_calculix_settings(folder,settings)
        log('자동화',f"누적 상태 연결 완료: step {audit['source_step']}의 변형/응력/소성 이력 보존 검증; 바닥 재배치, 초기속도 갱신, 접촉 재활성화")
        return
    previous=stage_folder(run,index,"drop") if stage=="release" else stage_folder(run,index-1,"release")
    state=read_state(previous/"results"/"state.json")
    template=Path(run)/"template_snapshot"
    mesh=read_mesh(template/"abaqus_mesh.inp")
    from .deck import expanded_lines,keyword
    # Import carries nodes, elements, section/material history. Recreate named sets,
    # surfaces and ties once; no section or material cards are duplicated.
    definitions=[]
    take=False
    for line in expanded_lines(template/"abaqus_mesh.inp"):
        if line.startswith("*") and not line.startswith("**"):
            card,_=keyword(line)
            take=card in ("*NSET","*ELSET","*SURFACE")
        if take: definitions.append(line)
    original=list(expanded_lines(template/"abaqus_main.inp"))
    from .assembly import blocks,card
    ties=[];contact=[];amplitudes=[];in_contact=False
    model_top={'*NODE','*ELEMENT','*NSET','*ELSET','*SURFACE','*SOLID SECTION','*SHELL SECTION','*MATERIAL','*BOUNDARY','*INITIAL CONDITIONS','*RIGID BODY','*AMPLITUDE','*TIE','*STEP'}
    for b in blocks(original):
        c=card(b)
        if c=='*STEP':break
        if c=='*SURFACE INTERACTION':in_contact=True
        elif c in model_top:in_contact=False
        if c=='*TIE':ties.extend(b)
        if c=='*AMPLITUDE':amplitudes.extend(b)
        if in_contact:contact.extend(b)
    pairs=[]
    for b in blocks(original):
        if card(b)=='*CONTACT PAIR':pairs.append(b)
    if len(pairs)>1:raise ValueError('복수 CONTACT PAIR의 누적 Import는 별도 검토가 필요합니다. 단일 바닥 접촉 또는 general contact 템플릿으로 준비하세요.')
    pair=pairs[0] if pairs else None
    interaction=keyword(pair[0])[1].get('INTERACTION','FLOOR_CONTACT') if pair else 'FLOOR_CONTACT'
    general=[]
    general_cards={'*CONTACT','*CONTACT INCLUSIONS','*CONTACT EXCLUSIONS','*CONTACT PROPERTY ASSIGNMENT'}
    for b in blocks(original):
        if card(b) in general_cards:general.append(b)
    if not pair and not general:raise ValueError('바닥 접촉 정의가 없습니다.')
    contact_step=[line for b in general for line in b] if general else list(pair)
    import_sets=[]
    for line in original:
        if line.upper().startswith(('*SOLID SECTION','*SHELL SECTION')):
            _,params=keyword(line)
            if params.get('ELSET')!='FLOOR_ELEMENTS':import_sets.append(str(params['ELSET']))
    if not import_sets:raise ValueError('Abaqus import에 필요한 제품 section ELSET이 없습니다.')
    lines=["*HEADING","System Drop | native material-state import | verify on target Abaqus version",
           "*IMPORT, UPDATE=YES, STATE=YES","\n".join(dict.fromkeys(import_sets)),product_sets("\n".join(definitions),mesh),*amplitudes,*ties]
    shell_nodes=sorted({n for kind,c in mesh.product_elements.values() if kind in ('S3','S4','S4R','S8R') for n in c})
    if shell_nodes:lines.extend(['*NSET, NSET=AUTO_SHELL_NODES',id_lines(shell_nodes)])
    if stage=="drop":
        from .floor import floor_text
        metadata=json.loads((folder/"setup.json").read_text(encoding="utf-8"))
        lines.extend([floor_text("abaqus",np.array(metadata["floor"]),metadata["floor_base"]),*[c for c in contact if not c.startswith("*CONTACT PAIR") and c!="PRODUCT_CONTACT, FLOOR_SURFACE"],
                      "*BOUNDARY","FLOOR_REF, 1, 6",
                      "*INITIAL CONDITIONS, TYPE=VELOCITY"])
        lines.extend(f"PRODUCT_NODES, {i+1}, {v:.12g}" for i,v in enumerate(metadata["velocity"]))
        if shell_nodes:lines.extend(f'AUTO_SHELL_NODES, {i}, 0.' for i in (4,5,6))
        lines.extend(["*STEP, NAME=DROP, NLGEOM=YES","*DYNAMIC, EXPLICIT",drop_time_line(settings),
                      *contact_step,"*DLOAD","PRODUCT_ELEMENTS, GRAV, 9810., "+", ".join(map(str,metadata["direction"])),
                      "*RESTART, WRITE, NUMBER INTERVAL=1"])
    else:
        if general:
            # Standard contact property assignment is MODEL data. Remove floor
            # references because stabilization has no physical floor.
            kept=[];has_inclusions=False
            for b in general:
                c=card(b);params=keyword(b[0])[1]
                rows=[row for row in b[1:] if 'FLOOR_SURFACE' not in row.upper()]
                if c=='*CONTACT':kept.append('*CONTACT');continue
                if c=='*CONTACT INCLUSIONS' and ('ALL EXTERIOR' in params or any(row.strip() and not row.strip().startswith('**') for row in rows)):has_inclusions=True
                if rows or 'ALL EXTERIOR' in params:kept.extend([b[0],*rows])
            if has_inclusions:lines.extend([*contact,*kept])
        velocities=state["velocities"]
        if not set(mesh.product_nodes).issubset(velocities):
            raise ValueError("Abaqus 릴리즈 속도 전달에 필요한 제품 노드의 V 출력이 누락됐습니다.")
        if any(len(velocities[n])<6 for n in shell_nodes):
            raise ValueError('Abaqus S4 안정화에는 회전 속도 VR 출력도 필요합니다. ODB의 V/VR 출력을 확인하세요.')
        from .stabilization import template_masses,remove_rigid_velocity,abaqus_dashpots
        masses=template_masses(mesh,template/'abaqus_main.inp');labels=sorted(mesh.product_nodes)
        remaining,report=remove_rigid_velocity([state['coordinates'][n] for n in labels],
                            [velocities[n][:3] for n in labels],[masses[n] for n in labels])
        report['damping_alpha_s_inverse']=settings.release_damping
        (folder/'stabilization_transfer.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        lines.extend(abaqus_dashpots(mesh,masses,settings.release_damping))
        lines.append("*INITIAL CONDITIONS, TYPE=VELOCITY")
        for n,velocity in zip(labels,remaining):
            lines.extend(f"{n}, {i+1}, {v:.12g}" for i,v in enumerate(velocity))
            if n in shell_nodes:
                rotation=np.asarray(velocities[n][3:6])-report['removed_angular_rad_s']
                lines.extend(f'{n}, {i+4}, {v:.12g}' for i,v in enumerate(rotation))
        lines.extend(["*STEP, NAME=RELEASE, NLGEOM=YES, INC=100000",
                      "*DYNAMIC, APPLICATION=QUASI-STATIC",
                      f"{decimal_text(settings.release_dt)}, {decimal_text(settings.release_time)}, 0.0000000001, {decimal_text(settings.release_max_dt)}",
                      "*RESTART, WRITE, FREQUENCY=1"])
    lines.extend(["*OUTPUT, FIELD, NUMBER INTERVAL=20","*NODE OUTPUT","U, V, UR, VR",
                  "*ELEMENT OUTPUT","S, PE, PEEQ","*OUTPUT, HISTORY, FREQUENCY=10",
                  "*ENERGY OUTPUT","ALLKE, ALLIE, ALLAE","*END STEP"])
    text="\n".join(lines)+"\n"
    if stage=="drop":text=configure_output(text,"abaqus",settings.drop_time,settings.drop_max_dt)
    (folder/"job.inp").write_text(format_inp(text),encoding="utf-8")
    publish_abaqus_input(folder)
    log("자동화",f"Abaqus native Import 입력 생성: {stage}; 재료 상태 유지. 실제 Abaqus 실행은 이 환경에서 미검증.")


def progress_from_sta(text,solver,duration,stage="drop"):
    latest=None
    for line in text.splitlines():
        columns=line.split()
        try:
            if solver=="calculix" and len(columns)>=7 and all(x.isdigit() for x in columns[:4]):
                latest=float(columns[5])  # step time, not accumulated total time
            elif solver=="abaqus" and stage=="release" and len(columns)>=9 and columns[0].isdigit():
                latest=float(columns[7])
            elif solver=="abaqus" and stage=="drop" and len(columns)>=7 and columns[0].isdigit():
                # Explicit .sta: increment, step time, total time, cpu time, ...
                latest=float(columns[1])
        except ValueError:
            continue
    return None if latest is None else max(0.0,min(99.9,100*latest/duration))


def completed_successfully(folder,solver,log_text):
    upper=log_text.upper()
    if any(s in upper for s in ("*ERROR", "ANALYSIS HAS NOT BEEN COMPLETED", "EXITED WITH AN ERROR")):
        return False
    if solver=="calculix":
        return "JOB FINISHED" in upper and (result_path(folder,'frd')).exists() and (result_path(folder,'rout')).exists()
    return ("COMPLETED SUCCESSFULLY" in upper or "ANALYSIS COMPLETED" in upper) and (folder/"job.odb").exists()
