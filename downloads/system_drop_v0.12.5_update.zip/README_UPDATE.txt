﻿System Drop v0.12.5 업데이트

1. Manager와 결과 창을 닫습니다.
2. 이 ZIP 전체를 임시 폴더에 압축 해제합니다.
3. apply_update.bat을 실행합니다.
4. 기존 start_windows.bat이 있는 system_drop 폴더를 선택합니다.
5. 완료되면 기존 start_windows.bat을 실행합니다.

변경 파일은 기존 설치 backups 폴더에 먼저 백업합니다.
기존 라이브러리, 솔버, INP 템플릿, 사용자 설정, runs는 유지합니다.
v0.11.1 시작 오류 수정도 포함합니다. 새로운 라이브러리는 없습니다.

PowerShell을 실행할 수 없으면 payload 안의 파일과 폴더를
기존 start_windows.bat이 있는 폴더에 복사·병합하여 덮어쓰세요.
payload 폴더 자체를 복사하는 것이 아닙니다. 기존 파일은 먼저 백업하세요.

자세한 내용: payload/docs/CHANGES_0.12.5.md
