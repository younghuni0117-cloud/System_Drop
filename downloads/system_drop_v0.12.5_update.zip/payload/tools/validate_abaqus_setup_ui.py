from pathlib import Path
import sys,time,json,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6 import QtWidgets
from system_drop.gui import Window,STYLE
from system_drop.model import ROOT
app=QtWidgets.QApplication([]);app.setStyleSheet(STYLE)
w=Window(preferences_path=False);w.solver.setCurrentIndex(w.solver.findData('abaqus'));w.scenario.setCurrentText('Custom');w.output.setText(str(ROOT/'artifacts/abaqus0125_ui'))
w.drop_time.setValue(.001);w.drop_max_dt.setValue(.00001);w.show();w.launch(False)
end=time.monotonic()+30
while w.worker is not None and time.monotonic()<end:app.processEvents();time.sleep(.02)
assert w.worker is None and w.engine.records[0]['setup']=='done'
folder=w.engine.run/'drop_01';report=json.loads((folder/'input_settings.json').read_text())
assert report['passed'] and report['actual']['period_s']==.001 and report['actual']['maximum_increment_s']==.00001
assert all(float(r['TIME INTERVAL'])==.00001 for r in report['actual']['output_requests'])
before=hashlib.sha256((folder/'job.inp').read_bytes()).hexdigest()
try:w.preflight_solver(w.engine.settings)
except FileNotFoundError:missing=True
else:missing=False
assert missing and before==hashlib.sha256((folder/'job.inp').read_bytes()).hexdigest()
w.grab().save(str(ROOT/'artifacts/abaqus0125_ui.png'));w.close()
summary={'success':True,'real_qt_setup':True,'abaqus_installed':False,'missing_solver_does_not_modify_generated_input':True,'run':str(folder.parent),'settings':report}
(ROOT/'artifacts/abaqus0125_ui_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
