"""Read back the actual Abaqus execution deck without invoking a solver."""
from pathlib import Path
import json,math
from .deck import logical_lines,keyword
from .template_adapter import dynamic_data_index


def verify_abaqus_settings(folder,settings):
    folder=Path(folder);lines=list(logical_lines((folder/'job.inp').read_text(encoding='utf-8-sig').splitlines()))
    cards=[keyword(l) for l in lines if l.strip().startswith('*') and not l.strip().startswith('**')]
    dynamic=[p for name,p in cards if name=='*DYNAMIC' and 'EXPLICIT' in p]
    if len(dynamic)!=1:raise ValueError('최종 job.inp에는 낙하 Explicit 절차가 정확히 한 개 있어야 합니다.')
    values=lines[dynamic_data_index(lines)].split(',');values+=['']*(4-len(values))
    period=float(values[1]);maximum=float(values[3] or 0.)
    outputs=[p for name,p in cards if name=='*OUTPUT' and ('FIELD' in p or 'HISTORY' in p)]
    equal=lambda a,b:math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-15)
    errors=[]
    if not equal(period,settings.drop_time):errors.append('종료 시간 불일치')
    if not equal(maximum,settings.drop_max_dt):errors.append('최대 증분 불일치')
    if settings.drop_max_dt>0:
        for mode in ('FIELD','HISTORY'):
            requests=[p for p in outputs if mode in p]
            if not requests or any(not equal(float(p.get('TIME INTERVAL',0)),settings.drop_max_dt) for p in requests):errors.append(mode+' 출력 간격 불일치')
    report={'passed':not errors,'actual_input':'job.inp','template_copy':'abaqus_main.inp (reference only)',
            'expected':{'period_s':settings.drop_time,'maximum_increment_s':settings.drop_max_dt},
            'actual':{'period_s':period,'maximum_increment_s':maximum,'output_requests':outputs},'errors':errors}
    (folder/'input_settings.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'README_INPUT.txt').write_text('실제 실행 입력은 job.inp입니다.\nabaqus_main.inp는 복사한 템플릿이며 실행 조건이 다를 수 있습니다.\nGUI 반영값과 검증 결과는 input_settings.json에서 확인하세요.\n',encoding='utf-8-sig')
    if errors:raise ValueError('Abaqus 입력 설정 검증 실패: '+'; '.join(errors))
    return report
