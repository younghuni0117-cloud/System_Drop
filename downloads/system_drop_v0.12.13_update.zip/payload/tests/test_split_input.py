from pathlib import Path
from types import SimpleNamespace
import json
from system_drop.model import ROOT,Settings
from system_drop.engine import Engine
from system_drop.solver import setup_drop,prepare_release
from system_drop.deck import expanded_lines,read_mesh
from system_drop.split_input import execution_input
from system_drop.abaqus_audit import audit_abaqus


def test_abaqus_first_and_import_steps_have_three_connected_inputs(tmp_path):
    s=Settings(solver='abaqus',template=str(ROOT/'template_abaqus'),directions=[1,2],drop_dt=0,drop_time=.001,drop_max_dt=.00001,output_root=str(tmp_path))
    e=Engine(s);e.initialize();folder=setup_drop(s,e.run,0,e.log)
    names={p.name for p in folder.glob('*.inp')}
    assert names=={'abaqus_main.inp','abaqus_material.inp','abaqus_mesh.inp'}
    assert not (folder/'job.inp').exists()
    for deck in (folder/'abaqus_main.inp',folder/'abaqus_mesh.inp'):
        assert 'AUTO_PRODUCT_' not in deck.read_text()
    assert 'NSET=PRODUCT_NODES' not in (folder/'abaqus_main.inp').read_text()
    assert 'PRODUCT_NODES, 1,' in (folder/'abaqus_main.inp').read_text()
    assert read_mesh(folder/'abaqus_main.inp').product_elements
    assert json.loads((folder/'input_settings.json').read_text())['actual_input']=='abaqus_main.inp'
    (folder/'results').mkdir();mesh=read_mesh(e.run/'template_snapshot/abaqus_mesh.inp')
    state={'coordinates':mesh.product_nodes,'velocities':{n:[0,0,0] for n in mesh.product_nodes}}
    (folder/'results/state.json').write_text(json.dumps(state))
    release=prepare_release(s,e.run,0,e.log)
    assert {p.name for p in release.glob('*.inp')}==names
    assert '*IMPORT, UPDATE=YES, STATE=YES' in '\n'.join(expanded_lines(release/'abaqus_main.inp'))
    assert audit_abaqus(release/'abaqus_main.inp')['passed']
    (release/'results').mkdir();(release/'results/state.json').write_text(json.dumps(state))
    second=setup_drop(s,e.run,1,e.log)
    assert {p.name for p in second.glob('*.inp')}==names
    assert json.loads((second/'input_settings.json').read_text())['passed']
    assert audit_abaqus(second/'abaqus_main.inp')['passed']
    for stage in (release,second):
        text='\n'.join(expanded_lines(stage/'abaqus_main.inp'))
        assert 'AUTO_PRODUCT_' not in text
        assert text.count('*NSET, NSET=PRODUCT_NODES')==1
        assert text.count('*ELSET, ELSET=PRODUCT_ELEMENTS')==1


def test_legacy_execution_inputs_are_not_rewritten(tmp_path):
    (tmp_path/'job.inp').write_text('old run input')
    (tmp_path/'abaqus_main.inp').write_text('old template copy')
    assert execution_input(tmp_path,'abaqus').name=='job.inp'
    assert execution_input(tmp_path,'calculix').name=='job.inp'


def test_abaqus_process_is_submitted_with_main_input_filename(tmp_path,monkeypatch):
    s=Settings(solver='abaqus',template=str(ROOT/'template_abaqus'),directions=[1],drop_dt=0,output_root=str(tmp_path))
    e=Engine(s);e.execute(automatic=False);calls=[]
    monkeypatch.setattr('system_drop.engine.resolve_solver_command',lambda args,solver:args)
    def popen(args,cwd,stdout,env):
        calls.append(args)
        return SimpleNamespace(pid=99999999,poll=lambda:1,wait=lambda:1)
    monkeypatch.setattr('system_drop.engine.popen',popen)
    e.execute(automatic=False)
    assert any(arg=='input=abaqus_main.inp' for arg in calls[0])


def test_existing_product_sets_are_preserved_and_incomplete_sets_are_not_rewritten():
    import pytest
    from system_drop.split_input import product_sets
    source=(ROOT/'template_abaqus/abaqus_mesh.inp').read_text()
    mesh=read_mesh(ROOT/'template_abaqus/abaqus_mesh.inp')
    assert product_sets(source,mesh)==source
    mesh.nsets['PRODUCT_NODES']=[next(iter(mesh.product_nodes))]
    with pytest.raises(ValueError,match='PRODUCT_NODES'):
        product_sets(source,mesh)
    assert (ROOT/'template_abaqus/abaqus_mesh.inp').read_text()==source
