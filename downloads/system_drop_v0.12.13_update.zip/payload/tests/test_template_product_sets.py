from pathlib import Path
import shutil
import pytest
from system_drop.assembly import blocks,card
from system_drop.deck import keyword,read_mesh,expanded_lines
from system_drop.model import Settings,ROOT
from system_drop.engine import Engine
from system_drop.solver import setup_drop


def template(tmp_path,solver,broken=None,marker_free=False):
    source=tmp_path/'template';shutil.copytree(ROOT/f'template_{solver}',source)
    path=source/f'{solver}_mesh.inp';mesh=read_mesh(path);out=[]
    for b in blocks(path.read_text().splitlines()):
        c=card(b);p=keyword(b[0])[1] if c else {}
        if p.get('NSET')=='PRODUCT_NODES':
            if broken=='missing_nodes':continue
            b=['*NSET, NSET=PRODUCT_NODES, GENERATE',f'{min(mesh.product_nodes)}, {max(mesh.product_nodes)}, 1'] if broken!='partial_nodes' else ['*NSET, NSET=PRODUCT_NODES','1']
        elif p.get('ELSET')=='PRODUCT_ELEMENTS' and c=='*ELSET':
            if broken=='missing_elements':continue
            b=['*ELSET, ELSET=PRODUCT_ELEMENTS','BODY_1'] if broken=='partial_elements' else ['*ELSET, ELSET=PRODUCT_ELEMENTS','BODY_1, BODY_2']
        out.extend(b)
    path.write_text('\n'.join(out)+'\n')
    if marker_free:
        main=source/f'{solver}_main.inp';main.write_text('\n'.join(l for l in main.read_text().splitlines() if not l.startswith('** AUTO:'))+'\n')
    return source


@pytest.mark.parametrize('solver',['calculix','abaqus'])
def test_original_mesh_and_nested_generated_set_definitions_are_used_unchanged(tmp_path,solver):
    source=template(tmp_path,solver);mesh_path=source/f'{solver}_mesh.inp';original=mesh_path.read_bytes()
    s=Settings(solver=solver,template=str(source),directions=[1],output_root=str(tmp_path/'runs'))
    e=Engine(s);e.initialize();folder=setup_drop(s,e.run,0,e.log)
    assert (folder/f'{solver}_mesh.inp').read_bytes()==original
    main=(folder/f'{solver}_main.inp').read_text()
    assert 'AUTO_PRODUCT_' not in main and 'AUTO_SHELL_' not in main
    assert '*NSET, NSET=PRODUCT_NODES' not in main and '*ELSET, ELSET=PRODUCT_ELEMENTS' not in main
    assert 'PRODUCT_NODES, 1,' in main and 'PRODUCT_ELEMENTS, GRAV' in main
    if solver=='calculix':assert 'ELSET=PRODUCT_ELEMENTS' in main
    assert mesh_path.read_bytes()==original


@pytest.mark.parametrize('solver',['calculix','abaqus'])
@pytest.mark.parametrize('broken',['missing_nodes','missing_elements','partial_nodes','partial_elements'])
def test_missing_or_partial_template_sets_are_reported_without_auto_repair(tmp_path,solver,broken):
    source=template(tmp_path,solver,broken);before={p.name:p.read_bytes() for p in source.glob('*.inp')}
    s=Settings(solver=solver,template=str(source),directions=[1],output_root=str(tmp_path/'runs'))
    with pytest.raises(ValueError,match='PRODUCT_'):Engine(s).initialize()
    assert before=={p.name:p.read_bytes() for p in source.glob('*.inp')}


def test_marker_free_abaqus_keeps_template_generate_and_nested_set_rules(tmp_path):
    source=template(tmp_path,'abaqus',marker_free=True)
    s=Settings(solver='abaqus',template=str(source),directions=[1],output_root=str(tmp_path/'runs'))
    e=Engine(s);e.initialize();folder=setup_drop(s,e.run,0,e.log)
    text=(folder/'abaqus_mesh.inp').read_text()
    assert '*NSET, NSET=PRODUCT_NODES, GENERATE' in text
    assert '*ELSET, ELSET=PRODUCT_ELEMENTS\nBODY_1, BODY_2' in text
    assert text.count('*NSET, NSET=PRODUCT_NODES')==1 and text.count('*ELSET, ELSET=PRODUCT_ELEMENTS')==1
