from pathlib import Path
from types import SimpleNamespace
import hashlib,json,zipfile
import pytest
import offline_setup as off


def fixture(root):
    base=root/'offline';(base/'wheels').mkdir(parents=True)
    archive=base/'python.zip'
    with zipfile.ZipFile(archive,'w') as z:z.writestr('python.exe',b'Windows Python placeholder for setup tests')
    wheel=base/'wheels/pkg.whl';wheel.write_bytes(b'local wheel test bytes')
    report={'python_archive':'python.zip','pins':{'numpy':'1.26.4'},'files':{str(p.relative_to(base)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (archive,wheel)}}
    (base/'manifest.json').write_text(json.dumps(report));return base


def test_only_local_wheels_and_only_missing_packages_are_requested(tmp_path):
    fixture(tmp_path);calls=[]
    def run(args,**kwargs):calls.append(args);return SimpleNamespace(returncode=0)
    assert off.install(tmp_path,'python.exe',['numpy>=1.24'],run)==0
    assert calls==[['python.exe',str(tmp_path/'tools/install_local_wheels.py'),'numpy==1.26.4']]
    script=(Path(__file__).parents[1]/'tools/install_local_wheels.py').read_text()
    assert '--no-index' in script and '--find-links' in script
    assert '--upgrade' not in script and '--force-reinstall' not in script


def test_missing_or_corrupt_copy_is_reported_before_install(tmp_path):
    base=fixture(tmp_path);off.verify(tmp_path)
    (base/'wheels/pkg.whl').write_bytes(b'corrupt')
    with pytest.raises(RuntimeError,match='손상'):off.verify(tmp_path)
    (base/'wheels/pkg.whl').unlink()
    with pytest.raises(RuntimeError,match='누락'):off.verify(tmp_path)


def test_portable_python_uses_relative_site_packages_and_project_paths(tmp_path):
    fixture(tmp_path);exe=off.prepare_python(tmp_path)
    assert exe.exists()
    content=(exe.parent/'python311._pth').read_text()
    assert '../..' in content and 'Lib/site-packages' in content and 'import site' in content
    assert off.prepare_python(tmp_path)==exe


def test_complete_environment_never_runs_pip_or_reinstalls(tmp_path,monkeypatch):
    monkeypatch.setattr(off,'install',lambda *args:(_ for _ in ()).throw(AssertionError('No install expected')))
    monkeypatch.setattr(off,'runtime_check',lambda *args:SimpleNamespace(returncode=0))
    assert off.guide(tmp_path,'python.exe',[])==0


def test_setup_guide_retries_until_install_succeeds(tmp_path,monkeypatch):
    attempts=[]
    def install(*args):attempts.append(1);return 1 if len(attempts)==1 else 0
    monkeypatch.setattr(off,'install',install)
    monkeypatch.setattr(off,'runtime_check',lambda *args:SimpleNamespace(returncode=0))
    monkeypatch.setattr(off.sys,'stdin',SimpleNamespace(isatty=lambda:True))
    monkeypatch.setattr('builtins.input',lambda *args:'r')
    assert off.guide(tmp_path,'python.exe',['numpy>=1.24'])==0
    assert len(attempts)==2


def failed_check(message):
    return SimpleNamespace(returncode=1,stdout='CHECK_MODULE=PIL.Image\n',stderr=message)


def test_runtime_install_is_offered_once_and_never_repeats_package_install(tmp_path,monkeypatch):
    calls=[];prompts=[];answers=iter(['v','q'])
    monkeypatch.setattr(off,'runtime_check',lambda *args:failed_check('DLL load failed while importing _imaging'))
    monkeypatch.setattr(off,'install',lambda *args:calls.append('pip') or 0)
    monkeypatch.setattr(off,'install_vc_runtime',lambda *args:calls.append('vc') or 0)
    monkeypatch.setattr(off.sys,'stdin',SimpleNamespace(isatty=lambda:True))
    monkeypatch.setattr('builtins.input',lambda prompt:prompts.append(prompt) or next(answers))
    assert off.guide(tmp_path,'python.exe',['numpy>=1.24'])==1
    assert calls==['pip','vc']
    assert '[V]' in prompts[0] and '[V]' not in prompts[1]
    assert '[P]' in prompts[0]


def test_runtime_reboot_code_stops_retry_loop(tmp_path,monkeypatch,capsys):
    monkeypatch.setattr(off,'runtime_check',lambda *args:failed_check('DLL load failed while importing _imaging'))
    monkeypatch.setattr(off,'install_vc_runtime',lambda *args:3010)
    monkeypatch.setattr(off.sys,'stdin',SimpleNamespace(isatty=lambda:True))
    monkeypatch.setattr('builtins.input',lambda prompt:'v')
    assert off.guide(tmp_path,'python.exe',[])==3010
    assert 'Windows 재시작' in capsys.readouterr().out


def test_non_dll_failures_do_not_recommend_runtime_install(tmp_path,monkeypatch):
    prompts=[]
    monkeypatch.setattr(off,'runtime_check',lambda *args:failed_check('ModuleNotFoundError: missing_package'))
    monkeypatch.setattr(off.sys,'stdin',SimpleNamespace(isatty=lambda:True))
    monkeypatch.setattr('builtins.input',lambda prompt:prompts.append(prompt) or 'q')
    # failed_check names PIL.Image but its actual error is a missing package.
    assert off.guide(tmp_path,'python.exe',[])==1
    assert '[V]' not in prompts[0]


def test_optional_multimedia_error_does_not_block_manager(tmp_path,monkeypatch,capsys):
    monkeypatch.setattr(off,'runtime_check',lambda *args:SimpleNamespace(returncode=0,stdout='OPTIONAL_WARNING=QtMultimedia DLL error\nIMPORT_OK\n'))
    assert off.guide(tmp_path,'python.exe',[])==0
    assert 'MP4' in capsys.readouterr().out


@pytest.mark.parametrize('code,kind',[(0,'installed'),(3010,'reboot'),(1641,'reboot'),(1638,'already_installed'),(0x80070666,'already_installed'),(1602,'failed')])
def test_runtime_exit_codes_are_distinguished(code,kind):
    assert off.vc_exit_kind(code)==kind


def test_check_uses_consistent_qt_environment_and_records_failed_module(tmp_path,monkeypatch):
    calls=[]
    monkeypatch.setenv('QT_API','pyqt5');monkeypatch.setenv('QT_PLUGIN_PATH','other_app')
    def run(args,**kwargs):
        calls.append((args,kwargs));return failed_check('DLL load failed while importing _imaging')
    monkeypatch.setattr(off.subprocess,'run',run)
    off.runtime_check('python.exe',tmp_path)
    report=json.loads((tmp_path/'logs/runtime_import_check.json').read_text())
    assert report['failed_module']=='PIL.Image'
    assert calls[0][1]['env']['QT_API']=='pyside6' and 'QT_PLUGIN_PATH' not in calls[0][1]['env']
    assert "'PIL.Image'" in calls[0][0][-1] and "'PIL._imaging'" in calls[0][0][-1]


def test_pillow_repair_is_offered_once_without_other_package_reinstallation(tmp_path,monkeypatch):
    answers=iter(['p','q']);calls=[];prompts=[]
    monkeypatch.setattr(off,'runtime_check',lambda *args:failed_check('DLL load failed while importing _imaging'))
    monkeypatch.setattr(off,'repair_pillow',lambda *args:calls.append('pillow') or {'changed_files':['PIL/_imaging.pyd']})
    monkeypatch.setattr(off,'install',lambda *args:(_ for _ in ()).throw(AssertionError('Do not reinstall packages')))
    monkeypatch.setattr(off.sys,'stdin',SimpleNamespace(isatty=lambda:True))
    monkeypatch.setattr('builtins.input',lambda prompt:prompts.append(prompt) or next(answers))
    assert off.guide(tmp_path,'python.exe',[])==1
    assert calls==['pillow'] and '[P]' in prompts[0] and '[P]' not in prompts[1]
