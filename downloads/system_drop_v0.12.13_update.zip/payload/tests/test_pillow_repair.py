from pathlib import Path
import hashlib,json,zipfile
import pytest
from tools.repair_pillow import repair


def data(root):
    portable=root/'runtime/python311';portable.mkdir(parents=True);exe=portable/'python.exe';exe.write_bytes(b'fixture')
    wheel=root/'offline/wheels/pillow-11.1.0-cp311-cp311-win_amd64.whl';wheel.parent.mkdir(parents=True)
    with zipfile.ZipFile(wheel,'w') as z:
        z.writestr('PIL/_imaging.cp311-win_amd64.pyd',b'expected binary')
        z.writestr('PIL/__init__.py',b'expected package')
        z.writestr('pillow-11.1.0.dist-info/RECORD','wheel installation record')
        z.writestr('pillow-11.1.0.dist-info/METADATA','Name: pillow\nVersion: 11.1.0\n')
    (root/'offline/manifest.json').write_text(json.dumps({'pins':{'pillow':'11.1.0'},'files':{wheel.relative_to(root/'offline').as_posix():hashlib.sha256(wheel.read_bytes()).hexdigest()}}))
    return exe,portable/'Lib/site-packages',wheel


def test_only_damaged_pillow_files_are_repaired_and_second_check_does_not_write(tmp_path):
    exe,site,wheel=data(tmp_path);(site/'PIL').mkdir(parents=True)
    broken=site/'PIL/_imaging.cp311-win_amd64.pyd';broken.write_bytes(b'corrupt')
    other=site/'numpy.py';other.write_text('unrelated library')
    record=site/'pillow-11.1.0.dist-info/RECORD';record.parent.mkdir();record.write_text('pip-generated installation record')
    result=repair(tmp_path,exe)
    assert broken.read_bytes()==b'expected binary' and other.read_text()=='unrelated library'
    assert (Path(result['backup'])/'PIL/_imaging.cp311-win_amd64.pyd').read_bytes()==b'corrupt'
    assert record.read_text()=='pip-generated installation record'
    before=broken.stat().st_mtime_ns
    assert repair(tmp_path,exe)['changed_files']==[] and broken.stat().st_mtime_ns==before


def test_corrupt_wheel_or_system_python_is_never_used_for_repair(tmp_path):
    exe,site,wheel=data(tmp_path)
    with pytest.raises(RuntimeError,match='시스템 Python'):repair(tmp_path,tmp_path/'global/python.exe')
    wheel.write_bytes(b'corrupt')
    with pytest.raises(RuntimeError,match='해시'):repair(tmp_path,exe)
    assert not site.exists()


def test_different_pillow_versions_are_not_mixed(tmp_path):
    exe,site,wheel=data(tmp_path);metadata=site/'pillow-12.0.dist-info/METADATA';metadata.parent.mkdir(parents=True)
    metadata.write_text('Name: Pillow\nVersion: 12.0\n')
    with pytest.raises(RuntimeError,match='버전'):repair(tmp_path,exe)
    assert not (site/'PIL').exists()
