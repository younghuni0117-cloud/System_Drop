@echo off
setlocal
cd /d "%~dp0"
if exist "runtime\python311\python.exe" (
    "runtime\python311\python.exe" bootstrap_windows.py --diagnose
) else (
    python bootstrap_windows.py --diagnose
)
pause
