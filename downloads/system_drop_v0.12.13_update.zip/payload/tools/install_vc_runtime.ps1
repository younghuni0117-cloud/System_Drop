$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$installer = Join-Path $root 'offline\vc_redist.x64.exe'
$manifest = Get-Content -LiteralPath (Join-Path $root 'offline\manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if ((Get-FileHash -LiteralPath $installer -Algorithm SHA256).Hash.ToLower() -ne $manifest.files.'vc_redist.x64.exe') { throw 'VC runtime installer checksum mismatch' }
$logdir = Join-Path $root 'logs'
New-Item -ItemType Directory -Force -Path $logdir | Out-Null
$log = Join-Path $logdir 'vc_runtime_install.log'
$process = Start-Process -FilePath $installer -ArgumentList '/install','/passive','/norestart','/log',('"'+$log+'"') -Wait -PassThru -Verb RunAs
exit $process.ExitCode
