"""Short real CCX test of direct three-INP input and native cumulative linkage."""
from pathlib import Path
import argparse,json,sys,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from system_drop.model import Settings,ROOT
from system_drop.engine import Engine
from system_drop.restart import NativeRestart
from system_drop.calculix_files import result_path,stage_basename
p=argparse.ArgumentParser();p.add_argument('--ccx',required=True);p.add_argument('--output',type=Path,default=ROOT/'artifacts/three0130');args=p.parse_args()
s=Settings(directions=[1,2],scenario='Custom',drop_time=.000001,drop_max_dt=.0000005,release_time=.000001,release_dt=.0000001,release_max_dt=.0000005,output_root=str(args.output),calculix_path=str(Path(args.ccx).resolve()),cpus=1)
events=[];e=Engine(s,emit=lambda name,data:events.append((name,data)));start=time.monotonic();e.execute()
r={'success':e.next_stage() is None,'scope':'Short direct CalculiX main, 3-INP, two-impact/native stabilization test','platform':sys.platform,'run':str(e.run),'elapsed_seconds':time.monotonic()-start,'records':e.records,'errors':[d['text'] for n,d in events if n=='error'],'stages':[]}
if r['success']:
    for name in ('drop_01','release_01','drop_02','release_02'):
        folder=e.run/name;names=sorted(p.name for p in folder.glob('*.inp'));assert names==['calculix_main.inp','calculix_material.inp','calculix_mesh.inp']
        assert not (folder/'job.inp').exists()
        text=(folder/'calculix_main.inp').read_text()
        assert 'AUTO_PRODUCT_' not in text and 'ELSET=PRODUCT_ELEMENTS' in text
        report=json.loads((folder/'input_settings.json').read_text());assert report['passed'] and report['actual_input']=='calculix_main.inp'
        assert result_path(folder,'rout').exists() and result_path(folder,'frd').exists()
        assert result_path(folder,'frd').stem==stage_basename(folder)
        assert not (folder/'calculix_main.frd').exists()
        r['stages'].append({'folder':name,'inp_files':names,'input_report':report,'output_base':result_path(folder,'rout').stem})
    a=NativeRestart.read(result_path(e.run/'release_01','rout'));b=NativeRestart.read(result_path(e.run/'drop_02','rin'));assert a.history_hashes()==b.history_hashes();r['native_history_preserved']=True
    r['final_total_time']=float(NativeRestart.read(result_path(e.run/'release_02','rout')).doubles('ttime')[0]);assert abs(r['final_total_time']-.000004)<1e-14
args.output.mkdir(parents=True,exist_ok=True);(args.output/'summary.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));assert r['success'],r['errors']
