"""Repair only damaged/missing files of the bundled portable Pillow, offline."""
from pathlib import Path
from datetime import datetime
import hashlib,json,zipfile


def repair(root,interpreter):
    root=Path(root).resolve();portable=root/'runtime/python311'
    if Path(interpreter).resolve()!=portable/'python.exe':
        raise RuntimeError('Pillow 복구는 프로그램에 동봉된 Python 3.11에만 적용합니다. 시스템 Python은 변경하지 않습니다.')
    data=json.loads((root/'offline/manifest.json').read_text(encoding='utf-8'))
    expected=next(v for k,v in data['pins'].items() if k.lower()=='pillow')
    matches=list((root/'offline/wheels').glob(f'pillow-{expected}-cp311-cp311-win_amd64.whl'))
    if len(matches)!=1:raise RuntimeError('동봉 Python 3.11 x64용 Pillow wheel을 찾지 못했습니다.')
    wheel=matches[0];relative=wheel.relative_to(root/'offline').as_posix()
    if hashlib.sha256(wheel.read_bytes()).hexdigest()!=data['files'].get(relative):
        raise RuntimeError('동봉 Pillow wheel 해시가 다릅니다. 이 파일을 복구 원본으로 사용하지 않습니다.')
    site=portable/'Lib/site-packages';site.mkdir(parents=True,exist_ok=True)
    for metadata in site.glob('*.dist-info/METADATA'):
        rows=metadata.read_text(encoding='utf-8',errors='replace').splitlines()
        if any(l.strip().lower()=='name: pillow' for l in rows):
            installed=next((l.split(':',1)[1].strip() for l in rows if l.startswith('Version:')),'')
            if installed!=expected:raise RuntimeError(f'현재 Pillow {installed}와 동봉 버전 {expected}가 다릅니다. 서로 다른 버전 파일을 섞지 않도록 자동 복구를 중단합니다.')
    backup=root/'backups'/('pillow_repair_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    changed=[]
    try:
        with zipfile.ZipFile(wheel) as archive:
            for info in archive.infolist():
                name=info.filename
                if info.is_dir() or name==f'pillow-{expected}.dist-info/RECORD':continue
                if not (name.startswith('PIL/') or name.startswith(f'pillow-{expected}.dist-info/')):continue
                target=(site/name).resolve()
                if not target.is_relative_to(site.resolve()):raise RuntimeError('Pillow wheel 파일 경로가 올바르지 않습니다.')
                payload=archive.read(info)
                if target.exists() and hashlib.sha256(target.read_bytes()).digest()==hashlib.sha256(payload).digest():continue
                saved=backup/name;existed=target.exists()
                if existed:saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(target.read_bytes())
                target.parent.mkdir(parents=True,exist_ok=True)
                temp=target.with_name(target.name+'.repair_pending')
                try:temp.write_bytes(payload);temp.replace(target)
                finally:temp.unlink(missing_ok=True)
                changed.append((target,saved,existed))
    except Exception:
        for target,saved,existed in reversed(changed):
            if existed:target.write_bytes(saved.read_bytes())
            else:target.unlink(missing_ok=True)
        raise
    report={'wheel':relative,'version':expected,'changed_files':[str(t.relative_to(site)) for t,_,_ in changed],
            'backup':str(backup) if changed else None,'other_packages_changed':False,
            'note':'Matching files are not rewritten. No pip, network, system Python or other package changes.'}
    (root/'logs').mkdir(exist_ok=True)
    (root/'logs/pillow_repair.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report
