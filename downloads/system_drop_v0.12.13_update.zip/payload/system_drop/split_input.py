"""Keep Abaqus run decks as main/material/mesh includes; retain old-run support."""
from pathlib import Path
from .assembly import blocks,card
from .inp_format import format_inp
from .deck import keyword,id_lines


def validate_product_sets(mesh):
    """Template owns product membership. Never generate, expand or repair sets."""
    for name,existing,labels in (('PRODUCT_NODES',mesh.nsets,mesh.product_nodes),
                                 ('PRODUCT_ELEMENTS',mesh.elsets,mesh.product_elements)):
        if name not in existing:
            raise ValueError(f'템플릿 mesh.inp에 {name} 집합이 없습니다. 기존 제품 전체 집합을 정의하세요. Manager는 집합을 자동 생성하지 않습니다.')
        actual=set(existing[name]);expected=set(labels)
        if actual!=expected:
            raise ValueError(f'템플릿 mesh.inp의 {name} 범위를 확인하세요: 제품 누락 {len(expected-actual)}개 / 제품 외 {len(actual-expected)}개. Manager는 기존 집합을 확장하거나 덮어쓰지 않습니다.')


def product_sets(text,mesh):
    validate_product_sets(mesh)
    return text



def execution_input(folder,solver):
    folder=Path(folder)
    if not (folder/'job.inp').exists() and (folder/f'{solver}_main.inp').exists():return folder/f'{solver}_main.inp'
    return folder/'job.inp'


def publish_abaqus_input(folder):
    folder=Path(folder);staging=folder/'job.inp';text=staging.read_text(encoding='utf-8-sig')
    if any(card(b)=='*IMPORT' for b in blocks(text.splitlines())):
        mesh=[];main=[];in_step=False
        geometry={'*IMPORT','*NODE','*ELEMENT','*NSET','*ELSET','*SURFACE'}
        for block in blocks(text.splitlines()):
            c=card(block)
            if c=='*STEP':in_step=True
            (mesh if not in_step and c in geometry else main).extend(block)
        # Material/section state belongs to the imported native model. Do not
        # redefine it, or redefine imported nodes/elements in the mesh include.
        (folder/'abaqus_material.inp').write_text('** Material and section history retained by *IMPORT, STATE=YES.\n** No material redefinition is required for this continuation.\n',encoding='utf-8')
        (folder/'abaqus_mesh.inp').write_text(format_inp('\n'.join(mesh)+'\n'),encoding='utf-8')
        # Keep HEADING and its data first; include import/sets before main model properties.
        head=next((i for i,l in enumerate(main) if l.strip().startswith('*') and not l.strip().startswith('**') and l.strip().upper()!='*HEADING'),len(main))
        main[head:head]=['*INCLUDE, INPUT=abaqus_material.inp','*INCLUDE, INPUT=abaqus_mesh.inp']
        text='\n'.join(main)+'\n'
    (folder/'abaqus_main.inp').write_text(format_inp(text),encoding='utf-8')
    staging.unlink()
    return folder/'abaqus_main.inp'


CALCULIX_ENTRY='** SYSTEM_DROP_ENTRY=calculix_main.inp'


def calculix_model_input(folder):
    folder=Path(folder);job=folder/'job.inp'
    if not job.exists() or CALCULIX_ENTRY in job.read_text(encoding='utf-8-sig'):
        return folder/'calculix_main.inp'
    return job


def publish_calculix_input(folder,text=None):
    """Publish three connected INPs, without a job.inp entry or duplicate deck."""
    folder=Path(folder);job=folder/'job.inp';main=folder/'calculix_main.inp'
    if text is not None or job.exists():
        if text is None:text=calculix_model_input(folder).read_text(encoding='utf-8-sig')
        native=any(card(b)=='*RESTART' and 'READ' in keyword(b[0])[1] for b in blocks(text.splitlines()))
        if native:
            for kind in ('material','mesh'):
                (folder/f'calculix_{kind}.inp').write_text(f'** {kind.title()} state retained by native calculix_main.rin.\n** No redefinition in a restart continuation.\n',encoding='utf-8')
            text='*INCLUDE, INPUT=calculix_material.inp\n*INCLUDE, INPUT=calculix_mesh.inp\n'+text
        main.write_text(format_inp(text),encoding='utf-8')
        if job.exists():job.unlink()
    # Migrate only an uncalculated prepared stage; completed runs never call here.
    if (folder/'job.rin').exists() and not (folder/'calculix_main.rin').exists():
        (folder/'job.rin').replace(folder/'calculix_main.rin')
    return main
