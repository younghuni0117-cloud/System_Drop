"""Offline Windows x64 setup guide. Standard library only, no network fallback."""
from pathlib import Path
import hashlib,importlib.util,json,os,re,subprocess,sys,zipfile


def manifest(root):return json.loads((Path(root)/'offline/manifest.json').read_text(encoding='utf-8'))


def verify(root):
    root=Path(root);data=manifest(root)
    for name,expected in data['files'].items():
        path=root/'offline'/name
        if not path.is_file():raise RuntimeError('오프라인 파일 누락: '+name)
        h=hashlib.sha256()
        with path.open('rb') as stream:
            for part in iter(lambda:stream.read(1024*1024),b''):h.update(part)
        if h.hexdigest()!=expected:raise RuntimeError('오프라인 파일 손상: '+name+' (압축파일을 다시 복사/해제하세요.)')
    return data


def prepare_python(root):
    root=Path(root);target=root/'runtime/python311';exe=target/'python.exe'
    if not exe.exists():
        data=manifest(root);archive=root/'offline'/data['python_archive']
        if hashlib.sha256(archive.read_bytes()).hexdigest()!=data['files'][data['python_archive']]:raise RuntimeError('동봉 Python 압축파일 해시가 다릅니다.')
        target.mkdir(parents=True,exist_ok=True)
        with zipfile.ZipFile(archive) as z:
            for entry in z.namelist():
                if not (target/entry).resolve().is_relative_to(target.resolve()):raise RuntimeError('잘못된 Python 압축 경로')
            z.extractall(target)
    (target/'Lib/site-packages').mkdir(parents=True,exist_ok=True)
    (target/'python311._pth').write_text('python311.zip\n.\nLib\nLib/site-packages\n../..\nimport site\n',encoding='utf-8')
    return exe


def install(root,interpreter,missing,run=subprocess.run):
    root=Path(root);data=verify(root);pins=data['pins']
    names=[r.split('>=')[0].lower().replace('-','_') for r in missing]
    requirements=[name+'=='+version for name,version in pins.items() if name.lower().replace('-','_') in names]
    known={r.split('==')[0].lower().replace('-','_') for r in requirements}
    if any(name not in known for name in names):raise RuntimeError('동봉 패키지 목록에 없는 항목: '+', '.join(names))
    print('[3/4] 동봉 wheel에서 필요한 항목만 설치합니다. 인터넷에 접속하지 않습니다.',flush=True)
    return run([str(interpreter),str(root/'tools/install_local_wheels.py'),*requirements],cwd=str(root)).returncode


def runtime_environment():
    # Use the same Qt backend/plugin environment as the actual GUI launch.
    env=os.environ.copy();env['QT_API']='pyside6'
    env.pop('QT_PLUGIN_PATH',None);env.pop('QT_QPA_PLATFORM_PLUGIN_PATH',None)
    if os.name=='nt':env['QT_QPA_PLATFORM']='windows'
    return env


def vc_runtime_status():
    if os.name!='nt':return {'platform':'not_windows'}
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\Microsoft\VisualStudio\14.0\VC\Runtimes\x64',0,winreg.KEY_READ|winreg.KEY_WOW64_64KEY) as key:
            return {'installed':bool(winreg.QueryValueEx(key,'Installed')[0]),'version':winreg.QueryValueEx(key,'Version')[0]}
    except (OSError,ValueError):return {'installed':None,'note':'No VC x64 registry entry found; this alone does not identify the failed DLL.'}


def runtime_check(interpreter,root):
    code=r"""
import importlib,importlib.metadata,importlib.util,json,os,platform,struct,sys,traceback
from pathlib import Path
print('PYTHON_INFO='+json.dumps({'executable':sys.executable,'version':sys.version,'bits':8*struct.calcsize('P'),'platform':platform.platform()},ensure_ascii=True),flush=True)
for name in ('numpy','PIL.Image','PIL._imaging','matplotlib','qtpy','PySide6.QtWidgets','vtk','pyvista','pyvistaqt'):
    print('CHECK_MODULE='+name,flush=True)
    try:importlib.import_module(name)
    except Exception:
        traceback.print_exc()
        if name.startswith('PIL') and os.name=='nt':
            import ctypes
            for dll in ('VCRUNTIME140.dll','ucrtbase.dll',f'python{sys.version_info.major}{sys.version_info.minor}.dll'):
                try:ctypes.WinDLL(dll);print('DLL_PROBE='+dll+' OK',flush=True)
                except OSError as exc:print('DLL_PROBE='+dll+' '+str(exc),flush=True)
            spec=importlib.util.find_spec('PIL')
            if spec and spec.submodule_search_locations:
                for folder in spec.submodule_search_locations:
                    for file in Path(folder).glob('_imaging*.pyd'):
                        print('PIL_EXTENSION='+str(file),flush=True)
                        try:ctypes.WinDLL(str(file));print('DLL_PROBE=_imaging load OK',flush=True)
                        except OSError as exc:print('DLL_PROBE=_imaging '+str(exc),flush=True)
        sys.exit(1)
    print('MODULE_OK='+name,flush=True)
# QtMultimedia is used only when exporting MP4. It must not block Manager,
# the viewer, AVI or GIF if its codec DLL/API is unavailable.
try:
    module=importlib.import_module('PySide6.QtMultimedia')
    if not hasattr(module,'QVideoFrameInput'):raise RuntimeError('QVideoFrameInput requires PySide6 6.8.2 or newer')
except Exception as exc:
    print('OPTIONAL_WARNING=QtMultimedia (MP4): '+str(exc),flush=True)
    traceback.print_exc(file=sys.stdout)
print('IMPORT_OK',flush=True)
"""
    check=subprocess.run([str(interpreter),'-X','utf8','-c',code],cwd=str(root),env=runtime_environment(),capture_output=True,text=True,encoding='utf-8',errors='replace')
    stdout=check.stdout or '';stderr=check.stderr or ''
    checks=re.findall(r'^CHECK_MODULE=(.+)$',stdout,re.M);oks=re.findall(r'^MODULE_OK=(.+)$',stdout,re.M)
    report={'interpreter':str(interpreter),'return_code':check.returncode,
            'failed_module':checks[-1] if checks and checks[-1] not in oks else None,
            'vc_runtime':vc_runtime_status(),'qt_backend':'pyside6',
            'optional_warnings':re.findall(r'^OPTIONAL_WARNING=(.+)$',stdout,re.M),
            'stdout':stdout,'stderr':stderr}
    logs=Path(root)/'logs';logs.mkdir(exist_ok=True)
    (logs/'runtime_import_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (logs/'runtime_import_check.txt').write_text(json.dumps({k:v for k,v in report.items() if k not in ('stdout','stderr')},ensure_ascii=False,indent=2)+'\n'+stdout+'\n'+stderr,encoding='utf-8')
    return check


def install_vc_runtime(root):
    return subprocess.run(['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File',str(Path(root)/'tools/install_vc_runtime.ps1')]).returncode


def vc_exit_kind(code):
    value=int(code)&0xffffffff
    if value==0:return 'installed'
    if value in (3010,1641):return 'reboot'
    if value in (1638,0x80070666):return 'already_installed'
    return 'failed'


def repair_pillow(root,interpreter):
    spec=importlib.util.spec_from_file_location('system_drop_pillow_repair',Path(root)/'tools/repair_pillow.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    return helper.repair(root,interpreter)


def guide(root,interpreter,missing):
    root=Path(root);(root/'logs').mkdir(exist_ok=True);vc_attempted=False;pillow_attempted=False
    while True:
        try:
            print('[2/4] 오프라인 환경과 필요한 패키지 확인',flush=True)
            if not missing:print('[3/4] 라이브러리가 이미 있어 설치를 생략합니다.',flush=True)
            code=install(root,interpreter,missing) if missing else 0
            if code:raise RuntimeError('로컬 패키지 설치 실패 (종료 코드 '+str(code)+')')
            missing=[]  # A later import failure must not reinstall successful wheels.
            print('[4/4] 실제 라이브러리 불러오기 검사',flush=True)
            check=runtime_check(interpreter,root)
            if check.returncode:
                raise RuntimeError('라이브러리 검사 종료 코드 '+str(check.returncode)+'\n'+getattr(check,'stdout','')+'\n'+getattr(check,'stderr',''))
            if 'OPTIONAL_WARNING=' in getattr(check,'stdout',''):
                print('주의: MP4용 QtMultimedia를 불러오지 못했습니다. Manager/결과보기/AVI/GIF는 계속 사용할 수 있습니다. logs/runtime_import_check.txt를 확인하세요.',flush=True)
            print('준비 완료. Manager를 실행합니다.',flush=True);return 0
        except Exception as exc:
            message=str(exc);(root/'logs/offline_setup_error.txt').write_text(message,encoding='utf-8')
            print('\n오프라인 준비를 완료하지 못했습니다:\n'+message,flush=True)
            pillow_error='_imaging' in message or 'PIL.Image' in message
            if pillow_error:print('Pillow 이미지 DLL(_imaging) 오류입니다. VC++를 이미 설치했다면 반복 설치하지 말고 P로 동봉 Pillow 파일을 먼저 검사하세요.',flush=True)
            dll_error=any(token in message.lower() for token in ('dll','0xc0000135','-1073741515','procedure could not be found'))
            if dll_error and not vc_attempted:
                print('DLL 오류입니다. VC++ 설치만으로 해결되지 않을 수도 있습니다. 설치 상태: '+str(vc_runtime_status()),flush=True)
            else:
                print('VC++ 반복 설치로 해결할 수 있다고 판단할 근거가 없습니다. logs/offline_setup_error.txt 및 logs/runtime_import_check.txt를 확인하세요.',flush=True)
            if not sys.stdin.isatty():return 1
            prompt='[R] 검사 다시 시도 / '+('[P] 동봉 Pillow 파일 검사·복구 / ' if pillow_error and not pillow_attempted else '')+('[V] VC++ x64 설치(이번 실행 1회) / ' if dll_error and not vc_attempted else '')+'[Q] 종료: '
            answer=input(prompt).strip().lower()
            if answer=='q':return 1
            if answer=='p' and pillow_error and not pillow_attempted:
                pillow_attempted=True
                try:
                    report=repair_pillow(root,interpreter)
                    print(f"Pillow 검사 완료: 누락·변경 파일 {len(report['changed_files'])}개 복구. 다른 라이브러리는 변경하지 않았습니다.",flush=True)
                    if not report['changed_files']:print('Pillow 파일은 동봉 wheel과 같습니다. DLL 의존성/실행 환경 문제를 logs/runtime_import_check.txt에서 확인해야 합니다.',flush=True)
                except Exception as repair_error:print('Pillow 복구 중단: '+str(repair_error),flush=True)
                continue
            if answer=='v' and dll_error and not vc_attempted:
                vc_attempted=True
                try:result=install_vc_runtime(root)
                except OSError as install_error:
                    print('VC++ 설치 실행 실패: '+str(install_error),flush=True);continue
                kind=vc_exit_kind(result)
                (root/'logs/vc_runtime_result.json').write_text(json.dumps({'exit_code':result,'status':kind,'runtime':vc_runtime_status()},ensure_ascii=False,indent=2),encoding='utf-8')
                if kind=='reboot':
                    print('VC++ 설치가 완료됐으며 Windows 재시작이 필요합니다. 작업을 저장하고 재시작한 뒤 start_windows.bat을 실행하세요. 반복 설치하지 마세요.',flush=True);return 3010
                if kind=='already_installed':print('동일하거나 더 최신 VC++ 런타임이 이미 설치되어 있습니다. 라이브러리를 한 번 더 검사합니다.',flush=True)
                elif kind=='installed':print('VC++ 설치 완료. 라이브러리를 한 번 더 검사합니다.',flush=True)
                else:print(f'VC++ 설치가 완료되지 않았습니다. 종료 코드 {result} (0x{int(result)&0xffffffff:08X}). logs/vc_runtime_install.log를 확인하세요.',flush=True)
