from pathlib import Path
import pytest
from system_drop.calculix_files import stage_basename,publish_stage_results,result_path


@pytest.mark.parametrize('folder,expected',[('drop_01','drop_01_drop'),('release_01','drop_01_release'),('drop_02','drop_02_drop'),('release_03','drop_03_release'),('drop_100','drop_100_drop')])
def test_stage_names_have_padded_drop_number(folder,expected):
    assert stage_basename(folder)==expected


def test_publication_keeps_three_inputs_and_native_input_while_pairing_dat_frd(tmp_path):
    folder=tmp_path/'release_02';folder.mkdir()
    for name in ('main','material','mesh'):(folder/f'calculix_{name}.inp').write_text('model')
    (folder/'calculix_main.rin').write_bytes(b'incoming native state')
    for ext in ('frd','dat','sta','rout'):(folder/f'calculix_main.{ext}').write_bytes(ext.encode()*100)
    mapping=publish_stage_results(folder)
    assert len(mapping)==4 and mapping['calculix_main.frd']=='drop_02_release.frd'
    for ext in ('frd','dat','sta','rout'):
        assert result_path(folder,ext).name==f'drop_02_release.{ext}'
        assert result_path(folder,ext).read_bytes()==ext.encode()*100
        assert not (folder/f'calculix_main.{ext}').exists()
    assert len(list(folder.glob('*.inp')))==3 and result_path(folder,'rin').name=='calculix_main.rin'
    assert publish_stage_results(folder)=={}


def test_rename_failure_rolls_back_without_losing_solver_output(tmp_path,monkeypatch):
    folder=tmp_path/'drop_01';folder.mkdir()
    for ext in ('frd','dat'):(folder/f'calculix_main.{ext}').write_text(ext)
    rename=Path.rename
    def fail(self,target):
        if self.name=='calculix_main.frd':raise PermissionError('simulate locked Windows file')
        return rename(self,target)
    monkeypatch.setattr(Path,'rename',fail)
    with pytest.raises(PermissionError):publish_stage_results(folder)
    assert (folder/'calculix_main.dat').read_text()=='dat' and (folder/'calculix_main.frd').read_text()=='frd'
    assert not list(folder.glob('drop_01_drop.*'))


def test_existing_results_are_never_overwritten_by_new_names(tmp_path):
    folder=tmp_path/'drop_01';folder.mkdir()
    (folder/'calculix_main.frd').write_text('new')
    (folder/'drop_01_drop.frd').write_text('existing')
    with pytest.raises(FileExistsError):publish_stage_results(folder)
    assert (folder/'drop_01_drop.frd').read_text()=='existing'
    assert (folder/'calculix_main.frd').read_text()=='new'

    (folder/'job.inp').write_text('legacy entry')
    assert result_path(folder,'frd').name=='job.frd'
