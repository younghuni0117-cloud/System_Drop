"""CalculiX basename: new main decks and unchanged historical job-based runs."""
from pathlib import Path


def basename(folder):
    folder=Path(folder)
    if (folder/'job.inp').exists():return 'job'
    if any((folder/('calculix_main.'+ext)).exists() for ext in ('inp','rin','rout')):return 'calculix_main'
    return 'job'


def result_path(folder,extension):
    folder=Path(folder);extension=extension.lstrip('.')
    stage=stage_basename(folder)
    named=folder/(stage+'.'+extension) if stage else None
    if extension!='rin' and not (folder/'job.inp').exists() and named is not None and named.exists():return named
    return folder/(basename(folder)+'.'+extension)


def command_for_input(args,path):
    """Manager owns the input basename even in an old hard-coded command."""
    args=list(args);stem=Path(path).stem
    if '-i' in args:
        i=args.index('-i')
        if i+1==len(args):args.append(stem)
        else:args[i+1]=stem
    else:
        position=next((i for i,a in enumerate(args[1:],1) if a in ('job','job.inp','calculix_main','calculix_main.inp')),None)
        if position is not None:args[position]=stem
        else:args.extend(['-i',stem])
    return args


def stage_basename(folder):
    import re
    match=re.fullmatch(r'(drop|release)_(\d+)',Path(folder).name)
    return f'drop_{int(match[2]):02d}_{match[1]}' if match else None


def publish_stage_results(folder):
    """Rename completed outputs with rollback; INPs and incoming RIN stay."""
    folder=Path(folder);target=stage_basename(folder)
    if not target or (folder/'job.inp').exists():return {}
    pairs=[]
    for ext in ('dat','frd','sta','cvg','msg','rout','eig','12d'):
        source=folder/('calculix_main.'+ext);dest=folder/(target+'.'+ext)
        if not source.exists():continue
        if dest.exists():raise FileExistsError(f'결과 파일 이름 충돌: {dest}')
        pairs.append((source,dest))
    moved=[]
    try:
        for source,dest in pairs:source.rename(dest);moved.append((source,dest))
    except OSError:
        for source,dest in reversed(moved):dest.rename(source)
        raise
    return {source.name:dest.name for source,dest in moved}
