from pathlib import Path
from types import SimpleNamespace
import pytest
import bootstrap_windows as boot


def test_no_missing_packages_never_calls_pip():
    def fail(*args,**kwargs): raise AssertionError("pip must not run")
    assert boot.ensure_requirements(Path("python.exe"),[],run=fail)==0


def test_install_only_missing_packages_without_upgrade_or_reinstall():
    commands=[]
    def run(args,**kwargs):
        commands.append(args);return SimpleNamespace(returncode=0)
    assert boot.ensure_requirements(Path("python.exe"),["pyvistaqt>=0.11"],run=run)==0
    assert commands==[["python.exe","-m","pip","install","pyvistaqt>=0.11"]]


def test_reuses_complete_existing_environment_instead_of_installing(monkeypatch):
    paths=[Path("current/python.exe"),Path("old_version/.venv/python.exe")]
    monkeypatch.setattr(boot,"candidate_interpreters",lambda root:iter(paths))
    selected,missing=boot.select_interpreter(Path("project"),probe=lambda p:["PySide6>=6.6"] if p==paths[0] else [])
    assert selected==paths[1] and missing==[]


def test_virtualenv_interpreter_symlink_is_not_resolved_to_base_python(tmp_path,monkeypatch):
    base=tmp_path/"base_python";base.write_text("binary")
    venv=tmp_path/".venv/bin/python";venv.parent.mkdir(parents=True)
    try: venv.symlink_to(base)
    except OSError: pytest.skip("Symlink permission not available")
    monkeypatch.delenv("SYSTEM_DROP_PYTHON",raising=False)
    monkeypatch.setattr(boot.sys,"executable",str(venv))
    assert next(boot.candidate_interpreters(tmp_path))==venv


def test_isolated_python_can_import_local_offline_helper_from_another_directory(tmp_path):
    import subprocess, sys, shutil
    project=tmp_path/'누적 드랍'/'system_drop'
    project.mkdir(parents=True)
    source=Path(boot.__file__)
    shutil.copy2(source,project/source.name)
    shutil.copy2(source.with_name('offline_setup.py'),project/'offline_setup.py')
    code="import runpy,sys; runpy.run_path(sys.argv[1],run_name='isolated_bootstrap'); import offline_setup; print(offline_setup.__file__)"
    result=subprocess.run([sys.executable,'-I','-c',code,str(project/source.name)],cwd=tmp_path,capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    assert str(project/'offline_setup.py') in result.stdout


def test_isolated_gui_child_resolves_moved_project_without_pth_or_pythonpath(tmp_path):
    import subprocess, sys, shutil
    project=tmp_path/'누적 드랍'/'system_drop'
    package=project/'system_drop'
    package.mkdir(parents=True)
    (package/'__init__.py').write_text('')
    (package/'gui.py').write_text("print('ISOLATED_GUI_FOUND')")
    shutil.copy2(Path(boot.__file__),project/'bootstrap_windows.py')
    result=subprocess.run([sys.executable,'-I',str(project/'bootstrap_windows.py'),'--gui'],cwd=tmp_path,capture_output=True,text=True)
    assert result.returncode==0,result.stderr+result.stdout
    assert 'ISOLATED_GUI_FOUND' in result.stdout


def test_portable_path_repair_preserves_already_installed_packages(tmp_path,monkeypatch):
    target=tmp_path/'runtime/python311'
    packages=target/'Lib/site-packages'
    packages.mkdir(parents=True)
    installed=packages/'installed_package.py'
    installed.write_text('KEEP=1')
    pth=target/'python311._pth'
    pth.write_text('python311.zip\n.\nimport site\n')
    monkeypatch.setattr(boot.sys,'executable',str(target/'python.exe'))
    monkeypatch.setattr(boot.sys,'path',list(boot.sys.path))
    boot.configure_portable_paths(tmp_path)
    assert '../..' in pth.read_text()
    assert 'Lib/site-packages' in pth.read_text()
    assert str(packages) in boot.sys.path
    assert installed.read_text()=='KEEP=1'
    before=pth.stat().st_mtime_ns
    boot.configure_portable_paths(tmp_path)
    assert pth.stat().st_mtime_ns==before


def test_path_repair_does_not_modify_system_or_virtual_environment(tmp_path,monkeypatch):
    target=tmp_path/'runtime/python311'
    target.mkdir(parents=True)
    pth=target/'python311._pth'
    pth.write_text('unchanged')
    monkeypatch.setattr(boot.sys,'executable',str(tmp_path/'other/python.exe'))
    boot.configure_portable_paths(tmp_path)
    assert pth.read_text()=='unchanged'
